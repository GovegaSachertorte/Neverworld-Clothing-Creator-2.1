bl_info = {"name":"Neverworld Clothing Creator" ,"author":"Neverworld / OpenAI","version":(1, 0, 29),"blender":(4,5,0),"location":"View3D > Sidebar > Neverworld","description":"Garment design, control rings, cloth simulation and finishing","category":"Mesh"}
import bpy, math
from mathutils import Vector, Matrix
from mathutils.bvhtree import BVHTree
from bpy.app.handlers import persistent
from bpy.props import PointerProperty, FloatProperty, IntProperty, EnumProperty, BoolProperty
from bpy_extras.io_utils import ExportHelper

PREFIX='NWCS_'
def body_bounds(obj):
    pts=[obj.matrix_world @ Vector(v) for v in obj.bound_box]
    return min(p.z for p in pts),max(p.z for p in pts),sum(p.x for p in pts)/8,sum(p.y for p in pts)/8

def ring_at(z, center, radius_x, radius_y, n, name, coll, axis='Z', thickness=.003):
    curve=bpy.data.curves.new(name+'Curve','CURVE');curve.dimensions='3D'
    spline=curve.splines.new('POLY');spline.points.add(n-1)
    for i,pt in enumerate(spline.points):
        a=2*math.pi*i/n
        if axis=='Z': xyz=(radius_x*math.cos(a),radius_y*math.sin(a),0)
        else: xyz=(0,radius_x*math.cos(a),radius_y*math.sin(a))
        pt.co=(*xyz,1)
    spline.use_cyclic_u=True
    curve.bevel_depth=thickness;curve.bevel_resolution=3;curve.resolution_u=1
    obj=bpy.data.objects.new(name,curve);coll.objects.link(obj)
    obj.location=(center[0],center[1],z)
    obj.show_in_front=True;obj.hide_render=True;obj.color=(1,.55,.12,1)
    obj['nwcs_ring']=True
    return obj

def ring_points(obj):
    return [tuple(obj.matrix_world @ Vector(p.co[:3])) for p in obj.data.splines[0].points]

def nwcs_protect_rings(context, p):
    """Expand each editable elliptical guide only as needed to clear the body.

    Do not move the center or alter rotation, and do not shrink guides. BVH is
    evaluated in world space, so armatures and avatar object transforms count.
    """
    body=p.reference_body
    coll=bpy.data.collections.get('NWCS Control Rings')
    if not body or body.type!='MESH' or not coll:return 0
    dg=context.evaluated_depsgraph_get()
    eval_body=body.evaluated_get(dg)
    mesh=eval_body.to_mesh()
    if not mesh:return 0
    try:
        world=eval_body.matrix_world
        verts=[world @ v.co for v in mesh.vertices]
        tris=[]
        mesh.calc_loop_triangles()
        tris=[tuple(t.vertices) for t in mesh.loop_triangles]
        if not tris:return 0
        bvh=BVHTree.FromPolygons(verts,tris,all_triangles=True)
        count=0
        for ring in list(coll.objects):
            if not ring.get('nwcs_ring') or ring.type!='CURVE':continue
            if ring.name in {'NWCS_Neckline','NWCS_Neck'} or (p.preset=='CORSET' and ring.name in {'NWCS_Bust Support','NWCS_Bust'}):continue
            # A whole ring is scaled uniformly; this retains its elliptical
            # outline instead of introducing random dents from nearest faces.
            pts=ring_points(ring)
            if not pts:continue
            center=ring.matrix_world.translation.copy()
            scale_needed=1.0
            for pt in pts:
                v=Vector(pt)
                nearest,normal,face,distance=bvh.find_nearest(v)
                if nearest is None:continue
                # Signed distance is only locally reliable on the nearest
                # surface; check a radial ray to avoid pushing outside points
                # toward unrelated torso/leg surfaces.
                radial=v-center
                if radial.length<1e-8:continue
                direction=radial.normalized()
                hit,hit_normal,face,hit_dist=bvh.ray_cast(center,direction,radial.length+p.body_min_gap+.2)
                if hit is None:continue
                needed=(hit-center).dot(direction)+p.body_min_gap
                if needed>radial.length:
                    scale_needed=max(scale_needed,needed/radial.length)
            if scale_needed>1.0001:
                # Limit pathological rays (e.g. shoulder ring crossing torso)
                # and allow the artist to reposition the guide if necessary.
                factor=min(scale_needed,2.0)
                ring.scale=tuple(v*factor for v in ring.scale)
                count+=1
        if count:context.view_layer.update()
        return count
    finally:
        eval_body.to_mesh_clear()

class NWCS_OT_protect_rings(bpy.types.Operator):
    bl_idname='nwcs.protect_rings';bl_label='Fit Rings Outside Body';bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        p=context.scene.nwcs_props
        if not p.reference_body or p.reference_body.type!='MESH':
            self.report({'ERROR'},'Choose a mesh Reference Body');return {'CANCELLED'}
        n=nwcs_protect_rings(context,p)
        self.report({'INFO'},f'Body clearance checked; {n} rings expanded')
        return {'FINISHED'}

def activate_move(context):
    """Select the Move tool, not just the translation gizmo visibility."""
    if not context.screen: return
    for area in context.screen.areas:
        if area.type == 'VIEW_3D':
            try:
                with context.temp_override(area=area, region=next(r for r in area.regions if r.type=='WINDOW')):
                    bpy.ops.wm.tool_set_by_id(name='builtin.move')
            except (RuntimeError, StopIteration, ValueError):
                pass


def body_slice(body, height, cx=None, side=None, center_hint=None, band=None):
    """Robust local body slice; side isolates a single leg or arm."""
    pts=[body.matrix_world @ v.co for v in body.data.vertices]
    lo,hi,bx,by=body_bounds(body)
    if cx is None: cx=bx
    width=band or max((hi-lo)*.014,.008)
    near=[v for v in pts if abs(v.z-height)<width and (side is None or (v.x-cx)*side>0)]
    if center_hint is not None:
        near=[v for v in near if abs(v.x-center_hint[0])<center_hint[2] and abs(v.y-center_hint[1])<center_hint[3]]
    if len(near)<8:
        near=sorted([v for v in pts if side is None or (v.x-cx)*side>0],key=lambda v:abs(v.z-height))[:max(20,min(150,len(pts)//40))]
    return near


def fitted_ellipse(pts, gap, center=None, percentile=.92):
    if not pts:return (0,0,.04,.04)
    if center is None:
        sx=sorted(v.x for v in pts);sy=sorted(v.y for v in pts)
        center=(sx[len(sx)//2],sy[len(sy)//2])
    x,y=center
    dx=sorted(abs(v.x-x) for v in pts);dy=sorted(abs(v.y-y) for v in pts)
    k=min(len(dx)-1,int((len(dx)-1)*percentile))
    return x,y,max(.012,dx[k]+gap),max(.012,dy[k]+gap)


def arm_landmarks(body, side, center_x, shoulder_z):
    """Get actual world-space arm positions; never assume arm bone suffix equals X side."""
    arm=body.parent if body.parent and body.parent.type=='ARMATURE' else None
    if arm is None:
        arm=next((m.object for m in body.modifiers if m.type=='ARMATURE' and m.object),None)
    lo,hi,cx,cy=body_bounds(body)
    h=hi-lo
    if arm:
        bones=list(arm.pose.bones)
        def is_arm(b, names):
            name=b.name.lower().replace(' ','').replace('-','').replace('_','')
            return any(w in name for w in names)
        uppers=[b for b in bones if is_arm(b,('upperarm','uparm','shoulder'))]
        uppers=[b for b in uppers if ((arm.matrix_world @ b.head).x-center_x)*side>0]
        if uppers:
            upper=max(uppers,key=lambda b:(arm.matrix_world @ b.head).z)
            shoulder=arm.matrix_world @ upper.head
            elbow=arm.matrix_world @ upper.tail
            # Prefer a connected forearm whose head is closest to the upper-arm tail.
            forearms=[b for b in bones if is_arm(b,('forearm','lowerarm','loarm'))]
            forearms=[b for b in forearms if ((arm.matrix_world @ b.head).x-center_x)*side>0]
            if forearms:
                fore=min(forearms,key=lambda b:((arm.matrix_world @ b.head)-elbow).length)
                wrist=arm.matrix_world @ fore.tail
            else:
                wrist=elbow+(elbow-shoulder)*.85
            if (elbow-shoulder).length>h*.045 and (wrist-elbow).length>h*.04:
                return shoulder,elbow,wrist
    # Geometry fallback: estimate the shoulder at the outer upper torso,
    # then track the outward arm vertices rather than selecting low torso vertices.
    pts=[body.matrix_world@v.co for v in body.data.vertices]
    shoulder_band=[v for v in pts if abs(v.z-shoulder_z)<h*.028 and (v.x-cx)*side>h*.085]
    if shoulder_band:
        outward=sorted((v.x-cx)*side for v in shoulder_band)
        sx=cx+side*min(h*.205,max(h*.115,outward[int((len(outward)-1)*.45)]))
        sy=sorted(v.y for v in shoulder_band)[len(shoulder_band)//2]
    else:
        sx=cx+side*h*.16;sy=cy
    shoulder=Vector((sx,sy,shoulder_z))
    # Pick arm points progressively farther outward; avoid the torso by X threshold.
    candidates=[v for v in pts if (v.x-cx)*side>abs(sx-cx)+h*.045 and v.z>lo+h*.32]
    if candidates:
        candidates.sort(key=lambda v:(v.x-cx)*side)
        # The farthest mesh vertices include fingers; use an inset wrist
        # target instead of averaging the outermost hand geometry.
        far=max((v.x-cx)*side for v in candidates)
        span=max(.001,far-abs(sx-cx))
        wrist_x=cx+side*(abs(sx-cx)+span*.76)
        band=[v for v in candidates if abs(v.x-wrist_x)<max(h*.012,span*.06)]
        if band:
            wrist=Vector((wrist_x,sorted(v.y for v in band)[len(band)//2],sorted(v.z for v in band)[len(band)//2]))
        else:
            wrist=shoulder+Vector((side*span*.76,0,-span*.08))
        elbow=shoulder.lerp(wrist,.52)
    else:
        elbow=shoulder+Vector((side*h*.15,0,-h*.085))
        wrist=shoulder+Vector((side*h*.30,0,-h*.17))
    return shoulder,elbow,wrist


def oriented_ring(center, direction, radius, n, name, coll, thickness):
    # Oval cross-section: keep width/depth independent for each arm.
    rx,ry=radius if isinstance(radius,tuple) else (radius,radius)
    ob=ring_at(center.z,(center.x,center.y),rx,ry,n,name,coll,thickness=thickness)
    ob.rotation_euler=Vector((0,0,1)).rotation_difference(direction.normalized()).to_euler()
    return ob

def tank_neck_drop(i,n,p):
    # Front assumed to face -Y; front center occurs at angle 3*pi/2.
    angle=2*math.pi*i/n
    front=max(0.0,-math.sin(angle))
    back=max(0.0,math.sin(angle))
    if p.tank_neckline=='V':
        return p.tank_neck_depth*(front**7)+p.tank_neck_depth*.28*(back**2)
    if p.tank_neckline=='OPEN':
        return p.tank_neck_depth*.50*(front**12)+p.tank_neck_depth*.20*(back**2)
    return p.tank_neck_depth*(front**2)+p.tank_neck_depth*.45*(back**2)

def nwcs_neck_profile(i, n, p):
    """Generate the opening directly on the guide ring; never simulate a folded collar.

    Neckline shaping is geometric, with a symmetric front and a shallow back.
    This is an original implementation informed by Divine Cut's dedicated neck loops.
    """
    a=2*math.pi*i/n + p.neckline_rotation
    front=max(0.0,-math.sin(a))
    back=max(0.0,math.sin(a))
    shoulder=abs(math.cos(a))
    if p.preset in {'SWEATER','CARDIGAN'}: style=p.sweater_neck
    elif p.preset=='TSHIRT': style=p.tshirt_neck
    elif p.preset=='DRESS': style=p.dress_neckline
    else: style=p.tank_neckline
    body=p.reference_body
    height=(body_bounds(body)[1]-body_bounds(body)[0]) if body and body.type=='MESH' else 1.7
    # Preserve the user's depth control, with actual depth for low-neck garments.
    depth=max(p.neckline_front_drop, p.tank_neck_depth if p.preset=='TANK' else 0.0)
    depth=max(depth,height*({'V':.055,'SCOOP':.043,'SQUARE':.032,'OPEN':.024,'CREW':.018,'TURTLE':0.0}.get(style,.035)))
    depth=min(depth,height*.105)
    if style=='TURTLE':depth=0.0
    # V: linear front descent, scoop: rounded descent, square: flatter bottom.
    if style=='V': front_shape=front
    elif style=='SQUARE':front_shape=min(1.0,front*2.5)**.4
    elif style=='OPEN':front_shape=front**10
    elif style=='CREW':front_shape=front**2
    else:front_shape=front**1.5
    # Keep the shoulder attachment at the ring height; do not create a fold.
    anchor=max(0.0,1.0-shoulder**5)
    drop=depth*front_shape*anchor + depth*.18*back**2*anchor
    pitch=math.tan(p.neckline_tilt)*(-math.sin(a))*p.neckline_ring_depth*anchor
    roll=min(0.0,math.tan(p.neckline_side_tilt)*math.cos(a)*p.neckline_ring_width)*anchor
    return -drop+pitch+roll


def nwcs_blend_neck_rows(rows, n, body_height):
    """Grade the neckline into the upper chest without overlapping face strips.

    Never move a lower row above the opening; preserve positive row spacing.
    """
    if len(rows)<4:return
    collar=rows[-1]
    # Only the last three strips are shaped; the shoulder stays supported.
    for offset, fraction in ((1,.72),(2,.38),(3,.12)):
        row=rows[-1-offset]
        for i in range(n):
            top=Vector(collar[i]); v=Vector(row[i])
            # A graded horizontal taper gives a continuous opening and no
            # sudden radial jump in the final strip.
            row[i]=Vector((v.x+(top.x-v.x)*fraction*.38,
                           v.y+(top.y-v.y)*fraction*.38,
                           min(v.z,top.z-max(body_height*.0025,0.001)*offset)))


def nwcs_update_neckline_ring(context, p):
    if p.preset not in {'TANK','SWEATER','CARDIGAN','DRESS','TSHIRT'}:return
    ring=bpy.data.objects.get('NWCS_Neckline' if p.preset!='TANK' else 'NWCS_Neck')
    if not ring or ring.type!='CURVE' or not ring.get('nwcs_ring'):return
    points=ring.data.splines[0].points
    n=len(points)
    for i,point in enumerate(points):
        point.co.z=nwcs_neck_profile(i,n,p)
    ring.data.update_tag()

def nwcs_neck_property_changed(self,context):
    try:nwcs_update_neckline_ring(context,self)
    except (ReferenceError,AttributeError):pass

def nwcs_bikini_stretch_changed(self, context):
    """Adjust only object scale; never modify the imported FBX vertices."""
    for ob in bpy.data.objects:
        if ob.get('nwcs_bikini_original_fbx'):
            base=ob.get('nwcs_bikini_base_scale')
            if base and len(base)==3:
                ob.scale=(base[0]*self.bikini_stretch_x,
                          base[1]*self.bikini_stretch_y,
                          base[2]*self.bikini_stretch_z)


def nwcs_reference_body_changed(self, context):
    """Changing the reference via the object picker also removes prior reference models."""
    if context is None or not hasattr(context, 'scene'):
        return
    chosen=self.reference_body
    if chosen is not None and chosen.type=='MESH':
        nwcs_remove_previous_reference(context, chosen)
        chosen['nwcs_reference_avatar']=True

class NWCS_Props(bpy.types.PropertyGroup):
    reference_body:PointerProperty(name='Reference Body',type=bpy.types.Object,update=nwcs_reference_body_changed)
    preset:EnumProperty(name='Garment Preset',items=[('SWEATER','Sweater Top','Sweater with sleeves'),('TSHIRT','Men’s T-Shirt','Crew or V-neck short sleeve T-shirt'),('TANK','Tank Top','Short fitted tank'),('MINI','Mini Skirt','Short skirt'),('LONG','Long Skirt','Long skirt'),('PANTS','Pants','Connected waist, crotch and legs'),('DRESS','Dress','One-piece dress'),('CARDIGAN','Open Cardigan','Open front'),('CORSET','Laced V-Front Corset','Fitted corset with front lacing and pointed V hem'),('BIKINI','Bikini Panties','Bikini cut'),('BOXER_BRIEFS','Boxer Briefs','Fitted boxers'),('BOXER_SHORTS','Boxer Shorts','Relaxed boxers')],default='TANK')
    cardigan_opening:FloatProperty(name='Front Opening',default=24,min=8,max=65,subtype='ANGLE' if False else 'NONE')
    cardigan_hem:FloatProperty(name='Hem Height (body ratio)',default=.48,min=.37,max=.63)
    corset_lace_gap:FloatProperty(name='Lacing Width',default=.042,min=.015,max=.12,subtype='DISTANCE')
    corset_v_depth:FloatProperty(name='Front V Depth',default=.075,min=.015,max=.20,subtype='DISTANCE')
    corset_fit_offset:FloatProperty(name='Corset Clearance',default=.009,min=.002,max=.035,subtype='DISTANCE')
    corset_post_fit:FloatProperty(name='Gentle Side Fit',default=.35,min=0.0,max=.7,subtype='FACTOR',description='Strength of bounded upper-side/back fit after creating corset; breast panels remain unchanged')
    cup_coverage:FloatProperty(name='Cup Coverage',default=1.,min=.65,max=1.35)
    strap_width:FloatProperty(name='Strap Width',default=1.,min=.5,max=2.)
    panty_waist:FloatProperty(name='Waist Height (body ratio)',default=.56,min=.49,max=.64)
    bikini_leg_tilt:FloatProperty(name='Leg Opening Tilt',description='Raise the front of each leg opening toward the hip while keeping the crotch gusset low',default=.035,min=0.0,max=.075,subtype='DISTANCE')
    bikini_stretch_x:FloatProperty(name='Stretch Width',description='Scale original panties side-to-side without altering mesh topology',default=1.0,min=.5,max=2.0,precision=3,update=nwcs_bikini_stretch_changed)
    bikini_stretch_y:FloatProperty(name='Stretch Depth',description='Scale original panties front-to-back',default=1.0,min=.5,max=2.0,precision=3,update=nwcs_bikini_stretch_changed)
    bikini_stretch_z:FloatProperty(name='Stretch Height',description='Scale original panties vertically',default=1.0,min=.5,max=2.0,precision=3,update=nwcs_bikini_stretch_changed)
    accessory_kind:EnumProperty(name='Accessory',items=[('BELT','Belt','Belt with buckle'),('BUTTONS','Buttons','Row of buttons'),('ZIPPER','Zipper','Surface-fitted tapes, interlocking 3D teeth and pull')],default='BELT')
    accessory_width:FloatProperty(name='Width',default=.025,min=.002,max=.15,subtype='DISTANCE')
    accessory_height:FloatProperty(name='Vertical Position',default=.65,min=0,max=1,subtype='FACTOR')
    accessory_offset:FloatProperty(name='Surface Offset',default=.007,min=.001,max=.06,subtype='DISTANCE')
    accessory_count:IntProperty(name='Button Count',default=5,min=1,max=24)
    accessory_length:FloatProperty(name='Zipper Length',default=.24,min=.025,max=1.,subtype='DISTANCE')
    accessory_size:FloatProperty(name='Button Size',default=.012,min=.003,max=.06,subtype='DISTANCE')
    accessory_attach:bpy.props.BoolProperty(name='Parent to Garment',default=True,description='Parent accessory objects to the selected garment; apply cloth before using accessories on a draped garment')
    dress_style:EnumProperty(name='Dress Style',items=[('SHEATH','Sheath','Fitted'),('ALINE','A-Line','Gentle flare'),('FITFLARE','Fit & Flare','Full skirt'),('EMPIRE','Empire','Raised waist')],default='ALINE')
    dress_length:EnumProperty(name='Dress Length',items=[('MINI','Mini',''),('KNEE','Knee',''),('MIDI','Midi',''),('MAXI','Maxi','')],default='KNEE')
    dress_neckline:EnumProperty(name='Dress Neckline',items=[('SCOOP','Scoop',''),('V','V-Neck',''),('SQUARE','Square',''),('OPEN','Slightly Open','')],default='SCOOP')
    dress_sleeves:EnumProperty(name='Dress Sleeves',items=[('NONE','Sleeveless',''),('SHORT','Short',''),('LONG','Long','')],default='NONE')
    dress_pleats:bpy.props.BoolProperty(name='Dress Skirt Pleats',default=False)
    ruffle_style:EnumProperty(name='Hem Ruffles',items=[('NONE','None','Smooth hem'),('SOFT','Soft','Gentle gathered waves'),('FULL','Full','Fuller flounced waves')],default='NONE',description='Add a smooth flounced hem to skirts and dresses')
    ruffle_count:IntProperty(name='Ruffle Waves',default=8,min=3,max=16,description='Number of smooth waves around the hem')
    ruffle_depth:FloatProperty(name='Ruffle Depth',default=.018,min=.002,max=.065,subtype='DISTANCE',description='Maximum outward flare at the hem')
    ruffle_height:FloatProperty(name='Ruffle Height',default=.30,min=.12,max=.60,subtype='FACTOR',description='Fraction of the skirt length occupied by ruffles')

    pants_style:EnumProperty(name='Leg Style',items=[('FITTED','Fitted',''),('STRAIGHT','Straight',''),('WIDE','Wide',''),('FLARE','Flared','')],default='STRAIGHT')
    pants_waist:EnumProperty(name='Waist Height',items=[('LOW','Low',''),('MID','Mid',''),('HIGH','High','')],default='MID')
    pants_length:EnumProperty(name='Pants Length',items=[('SHORT','Shorts',''),('CAPRI','Capri',''),('FULL','Full Length','')],default='FULL')
    body_protection:bpy.props.BoolProperty(name='Body Collision Protection',default=True,description='Keep control rings outside the reference avatar during garment construction')
    body_min_gap:FloatProperty(name='Minimum Body Gap',default=.01,min=.001,max=.05,precision=3,subtype='DISTANCE',description='Minimum surface gap in Blender units; .01 is 1 cm at meter scale')
    mirror_legs:bpy.props.BoolProperty(name='Mirror Leg Adjustments',default=True)
    tshirt_neck:EnumProperty(name='T-Shirt Neck',items=[('CREW','Crew Neck',''),('V','V-Neck','')],default='CREW')
    tshirt_fit:EnumProperty(name='T-Shirt Fit',items=[('REGULAR','Regular',''),('RELAXED','Relaxed','')],default='REGULAR')
    sweater_fit:EnumProperty(name='Sweater Fit',items=[('FITTED','Close Fit',''),('RELAXED','Relaxed',''),('OVERSIZED','Oversized',''),('CROPPED','Cropped','')],default='FITTED')
    sweater_crop:BoolProperty(name='Crop Sweater',description='Shorten the sweater hem independently of fit',default=False)
    sweater_crop_height:FloatProperty(name='Crop Hem Height',description='Height of the cropped hem as a fraction of the avatar height',default=.62,min=.57,max=.72,precision=3)
    sweater_neck:EnumProperty(name='Sweater Neck',items=[('CREW','Crew',''),('V','V-Neck',''),('SCOOP','Scoop',''),('TURTLE','Turtleneck','')],default='CREW')
    sweater_sleeves:EnumProperty(name='Sleeve Length',items=[('SHORT','Short',''),('THREEQUARTER','Three Quarter',''),('LONG','Long','')],default='LONG')
    sweater_cuffs:bpy.props.BoolProperty(name='Cuffs and Waistband',default=True)
    mirror_sleeves:bpy.props.BoolProperty(name='Mirror Sleeve Adjustments',default=True)
    fabric_weight:FloatProperty(name='Fabric Weight',default=1.0,min=.2,max=3.0,description='Cloth mass multiplier: lighter or heavier fabric, independent of stiffness')
    cloth_stiffness:FloatProperty(name='Cloth Stiffness',default=35.0,min=0.0,max=100.0,subtype='PERCENTAGE',description='Soft 0 to structured 100; applied when building and before each simulation')
    prefit_shrinkwrap:bpy.props.BoolProperty(name='Shrinkwrap Before Simulation',default=False,description='Fit garment near body before cloth; restrict to neckline/upper chest for tops')
    prefit_offset:FloatProperty(name='Shrinkwrap Clearance',default=.008,min=.003,max=.04,precision=3,subtype='DISTANCE')
    neckline_hold:FloatProperty(name='Neckline Shape Hold',default=.45,min=0.,max=.85,subtype='FACTOR',description='Gentle top-edge pin weights; avoids folded neck bands')
    fabric_drape:EnumProperty(name='Fabric Drape',items=[('SOFT','Soft','Light, flowing fabric'),('MEDIUM','Medium','Everyday fabric'),('STRUCTURED','Structured','Tailored, firmer fabric')],default='SOFT')
    advanced_controls:bpy.props.BoolProperty(name='Advanced Geometry Controls',default=False)
    tank_neckline:EnumProperty(name='Tank Neckline',items=[('SCOOP','Soft Scoop','Gentle rounded neckline'),('V','V-Neck','Defined V-shaped neckline'),('OPEN','Slightly Open','Shallow open-look notch at front')],default='SCOOP')
    tank_neck_depth:FloatProperty(name='Neckline Depth',default=0.065,min=0.015,max=0.18,subtype='DISTANCE')
    neckline_front_drop:FloatProperty(name='Front Drop',default=.012,min=0,max=.065,soft_max=.035,subtype='DISTANCE',update=nwcs_neck_property_changed)
    neckline_tilt:FloatProperty(name='Forward Tilt',default=-.20,min=-.65,max=.65,subtype='ANGLE',update=nwcs_neck_property_changed)
    neckline_side_tilt:FloatProperty(name='Side Tilt',default=0.,min=-.65,max=.65,subtype='ANGLE',update=nwcs_neck_property_changed)
    neckline_rotation:FloatProperty(name='Neckline Rotation',default=0.,min=-3.14159,max=3.14159,subtype='ANGLE',update=nwcs_neck_property_changed)
    neckline_ring_width:FloatProperty(default=.12,options={'HIDDEN'})
    neckline_ring_depth:FloatProperty(default=.08,options={'HIDDEN'})
    rings: IntProperty(name='Ring Segments',default=32,min=12,max=128)
    clearance:FloatProperty(name='Body Clearance',default=0.018,min=0.003,max=0.5,subtype='DISTANCE')
    top_height:FloatProperty(name='Neck Height',default=0.88,min=0.35,max=1.0)
    chest_height:FloatProperty(name='Chest Height',default=0.72,min=0.2,max=0.95)
    waist_height:FloatProperty(name='Waist Height',default=0.52,min=0.1,max=0.9)
    hem_height:FloatProperty(name='Hem Height',default=0.40,min=0.0,max=0.85)
    ring_thickness:FloatProperty(name='Ring Grip Thickness',default=.003,min=.0008,max=.02,subtype='DISTANCE')
    sleeve_length:FloatProperty(name='Sleeve Length',default=.65,min=.2,max=1.2)
    pleat_count:IntProperty(name='Pleat Count',default=12,min=4,max=48)
    pleat_depth:FloatProperty(name='Pleat Depth',default=0.010,min=0.0,max=0.25,subtype='DISTANCE')
    pleat_style:EnumProperty(name='Skirt Style',items=[('PLAIN','Plain','No pleats'),('PLEATED','Pleated','Radial pleats concentrated toward the hem')],default='PLAIN')
    fabric:EnumProperty(name='Fabric',items=[('COTTON','Cotton','Everyday cotton'),('SILK','Silk','Light flowing fabric'),('DENIM','Denim','Heavy structured fabric'),('LEATHER','Leather','Stiff leather-like fabric')],default='COTTON')
    pin_strength:FloatProperty(name='Waist Pin Strength',default=1.0,min=0.1,max=1.0,description='Pin only the top waistband row; 1 is fixed, lower values allow movement')
    waist_fit_offset:FloatProperty(name='Waist Fit Offset',default=0.012,min=0.003,max=0.12,subtype='DISTANCE',description='Gap between the body waist and skirt waistband in Blender units')
    conform_rows:IntProperty(name='Waist Fit Rows',default=3,min=1,max=8,description='Number of top fabric rows blended toward the body')
    conform_clearance:FloatProperty(name='Conform Clearance',default=0.006,min=0.001,max=0.05,subtype='DISTANCE',description='Clearance from the body surface')
    skirt_fullness:FloatProperty(name='Skirt Fullness',default=1.10,min=1.0,max=2.5,description='Hem flare independent of the fitted waistband')
    sim_frames:IntProperty(name='Simulation Frames',default=250,min=10,max=1000)
    finish_width:FloatProperty(name='Hem / Waistband Width',default=.008,min=.001,max=.06,subtype='DISTANCE')
    finish_thickness:FloatProperty(name='Trim Thickness',default=.0012,min=.0003,max=.01,subtype='DISTANCE')
    seam_style:EnumProperty(name='Seam Style',items=[('PLAIN','Plain','Single seam line'),('DOUBLE','Double Stitch','Parallel seam lines'),('OVERLOCK','Overlocked','Prominent seam line')],default='PLAIN')
    seam_width:FloatProperty(name='Seam Width',default=.0012,min=.0002,max=.008,subtype='DISTANCE')
    seam_visibility:FloatProperty(name='Seam Visibility',default=.65,min=0.0,max=1.0,subtype='FACTOR')
    fabric_thickness:FloatProperty(name='Fabric Thickness',description='Visible inside and outside fabric thickness after cloth simulation',default=.002,min=.0002,max=.02,subtype='DISTANCE')

def nwcs_neck_landmark(body,coords,z0,height,cx,cy):
    """Locate an open neck rim, then fall back to rig or a narrow neck slice."""
    mesh=body.data
    counts=[0]*len(mesh.edges)
    for loop in mesh.loops:counts[loop.edge_index]+=1
    graph={}
    for edge,count in zip(mesh.edges,counts):
        if count==1:
            a,b=edge.vertices;graph.setdefault(a,set()).add(b);graph.setdefault(b,set()).add(a)
    rims=[];seen=set()
    for first in graph:
        if first in seen:continue
        stack=[first];component=[];seen.add(first)
        while stack:
            index=stack.pop();component.append(coords[index])
            for other in graph[index]:
                if other not in seen:seen.add(other);stack.append(other)
        if len(component)<6:continue
        center=sum(component,Vector())/len(component)
        width=max(v.x for v in component)-min(v.x for v in component)
        depth=max(v.y for v in component)-min(v.y for v in component)
        if center.z>z0+height*.78 and abs(center.x-cx)<height*.10 and height*.025<width<height*.23 and depth<height*.23:
            rims.append((center.z,center))
    if rims:
        center=max(rims,key=lambda x:x[0])[1]
        # Place the editable ring just below the open rim, not at full-avatar
        # ratios that assume this headless reference includes a head.
        return Vector((center.x,center.y,center.z-height*.018))
    rig=body.find_armature()
    if rig and rig.data.bones.get('mNeck'):
        return rig.matrix_world@rig.data.bones['mNeck'].head_local
    candidates=[]
    for step in range(80,97):
        z=z0+height*step/100
        near=[v for v in coords if abs(v.z-z)<height*.008]
        if len(near)<12:continue
        xs=sorted(v.x for v in near);ys=sorted(v.y for v in near)
        width=xs[int((len(xs)-1)*.95)]-xs[int((len(xs)-1)*.05)]
        if height*.035<width<height*.23:
            candidates.append((width,Vector(((xs[0]+xs[-1])*.5,(ys[0]+ys[-1])*.5,z))))
    if candidates:
        minimum=min(w for w,center in candidates)
        return min((center for w,center in candidates if w<=minimum*1.12),key=lambda v:v.z)
    return Vector((cx,cy,z0+height*.90))

def nwcs_tank_body_clearance(context,rows,body,gap):
    """Use coherent horizontal body rays, never independent nearest normals."""
    mesh=body.data;mesh.calc_loop_triangles();world=body.matrix_world
    verts=[world@v.co for v in mesh.vertices]
    bvh=BVHTree.FromPolygons(verts,[tuple(t.vertices) for t in mesh.loop_triangles],all_triangles=True)
    height=max(v.z for v in verts)-min(v.z for v in verts)
    front=min(v.y for v in verts)-height*.05
    back=max(v.y for v in verts)+height*.05
    for row_number,row in enumerate(rows):
        center=sum(row,Vector())/len(row)
        for i,point in enumerate(row):
            original=point.copy()
            angle=2*math.pi*i/len(row)
            # Fit front and back panels along a common axis, keeping their X
            # profile instead of spreading the cloth out along T-pose arms.
            if abs(math.sin(angle))>.08:
                sign=1 if math.sin(angle)<0 else -1
                origin=Vector((point.x,front if sign==1 else back,point.z))
                hit,normal,face,distance=bvh.ray_cast(origin,Vector((0,sign,0)),back-front)
                if hit is not None:
                    point.y=min(point.y,hit.y-gap) if sign==1 else max(point.y,hit.y+gap)
            else:
                # Side seams use short torso rays; long rays along an arm are
                # deliberately ignored. Upper seam points follow the neck.
                origin=Vector((center.x,center.y,point.z))
                radial=Vector((point.x-center.x,point.y-center.y,0))
                if radial.length>1e-8:
                    direction=radial.normalized()
                    hit,normal,face,distance=bvh.ray_cast(origin,direction,height*.145)
                    if hit is not None and normal.dot(direction)>.05:
                        point=origin+direction*max(radial.length,distance+gap)
            row[i]=point
    # Spread coverage outward across neighboring rows, rather than leaving
    # isolated ray-projected points that would create long cloth edges.
    for iteration in range(6):
        snapshot=[[v.copy() for v in row] for row in rows]
        for j,row in enumerate(rows):
            for i,point in enumerate(row):
                sine=math.sin(2*math.pi*i/len(row))
                if abs(sine)<.15:continue
                neighbors=[snapshot[j][(i-1)%len(row)].y,snapshot[j][(i+1)%len(row)].y]
                if j>0:neighbors.append(snapshot[j-1][i].y)
                if j+1<len(rows):neighbors.append(snapshot[j+1][i].y)
                average=sum(neighbors)/len(neighbors)
                point.y=min(point.y,average) if sine<0 else max(point.y,average)
    return rows

def nwcs_round_tank_armholes(vertices,faces,segments):
    edge_counts={}
    for face in faces:
        for a,b in zip(face,face[1:]+face[:1]):
            key=tuple(sorted((a,b)));edge_counts[key]=edge_counts.get(key,0)+1
    graph={}
    for (a,b),count in edge_counts.items():
        if count==1:graph.setdefault(a,set()).add(b);graph.setdefault(b,set()).add(a)
    seen=set();holes=[]
    for first in graph:
        if first in seen:continue
        stack=[first];component=[];seen.add(first)
        while stack:
            index=stack.pop();component.append(index)
            for other in graph[index]:
                if other not in seen:seen.add(other);stack.append(other)
        if 6<len(component)<segments and all(len(graph[i])==2 for i in component):holes.append(component)
    result=[Vector(v) for v in vertices]
    for iteration in range(3):
        old=[v.copy() for v in result]
        for hole in holes:
            for index in hole:
                neighbors=list(graph[index])
                result[index]=old[index]*.5+(old[neighbors[0]]+old[neighbors[1]])*.25
    return [tuple(v) for v in result]

def nwcs_tank_curve_point(previous,low,high,following,t):
    """Monotone cubic fitting keeps a waist without straight, boxy panels."""
    value=low.lerp(high,t)
    for axis in (0,1):
        before=low[axis]-previous[axis];delta=high[axis]-low[axis];after=following[axis]-high[axis]
        tangent0=2*before*delta/(before+delta) if before*delta>0 else 0.
        tangent1=2*delta*after/(delta+after) if delta*after>0 else 0.
        x=(2*t**3-3*t*t+1)*low[axis]+(t**3-2*t*t+t)*tangent0+(-2*t**3+3*t*t)*high[axis]+(t**3-t*t)*tangent1
        value[axis]=max(min(low[axis],high[axis]),min(max(low[axis],high[axis]),x))
    return value

class NWCS_OT_make_rings(bpy.types.Operator):
    bl_idname='nwcs.make_rings';bl_label='Create Control Rings';bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        p=context.scene.nwcs_props;body=p.reference_body
        if not body or body.type!='MESH':
            self.report({'ERROR'},'Choose a mesh Reference Body');return {'CANCELLED'}
        # Fit to the selected mesh's actual vertex distribution, rather than
        # an oversized bounding box (often polluted by stray import geometry).
        coords=[body.matrix_world @ v.co for v in body.data.vertices]
        if len(coords)<16:
            self.report({'ERROR'},'Reference body has insufficient geometry');return {'CANCELLED'}
        zz=sorted(v.z for v in coords)
        z0=zz[int((len(zz)-1)*.005)]
        z1=zz[int((len(zz)-1)*.995)]
        h=z1-z0
        # Torso center from the waist/chest region, ignoring extended T-pose arms.
        middle=[v for v in coords if z0+h*.56 < v.z < z0+h*.72]
        if len(middle)<20:middle=coords
        xx=sorted(v.x for v in middle); yy=sorted(v.y for v in middle)
        cx=xx[len(xx)//2];cy=yy[len(yy)//2]
        if h<=0:self.report({'ERROR'},'Body has no height');return {'CANCELLED'}
        neck_landmark=nwcs_neck_landmark(body,coords,z0,h,cx,cy)
        if p.preset=='TANK' and p.rings<64:p.rings=64
        # Derive anatomical vertical landmarks from this body's geometry.
        # A fixed fraction of overall height places guides too low on bodies
        # with different leg/torso/head proportions.
        # Find the crotch as the highest slice with two distinct leg clusters.
        crotch_z=z0+h*.46
        for i in range(32,66):
            test_z=z0+h*i/100
            slice_pts=[v for v in coords if abs(v.z-test_z)<h*.009 and abs(v.y-cy)<h*.13]
            if len(slice_pts)<20:continue
            xs=sorted(v.x-cx for v in slice_pts)
            neg=[x for x in xs if x<0];pos=[x for x in xs if x>0]
            if len(neg)>6 and len(pos)>6 and min(pos)-max(neg)>h*.012:
                crotch_z=test_z
        # The widest horizontal span near the upper torso identifies the
        # shoulder/arm line for T-pose bodies; fall back to the standard level.
        shoulder_z=z0+h*.855
        spans=[]
        for i in range(70,94):
            test_z=z0+h*i/100
            sl=[v.x for v in coords if abs(v.z-test_z)<h*.009]
            if len(sl)>=20:
                sl.sort();spans.append((sl[int(len(sl)*.97)]-sl[int(len(sl)*.03)],test_z))
        if spans:
            maxspan=max(v for v,z in spans)
            broad=[z for v,z in spans if v>=maxspan*.86]
            if maxspan>h*.48 and broad:
                shoulder_z=sorted(broad)[len(broad)//2]
        # Map the existing preset control ratios onto the body's actual
        # crotch-to-shoulder span. Keep the endpoints stable for head/feet.
        crotch_ratio=max(.37,min(.57,(crotch_z-z0)/h))
        shoulder_ratio=max(.75,min(.91,(shoulder_z-z0)/h))
        def body_level(f):
            if f<=.46:return z0+h*f*(crotch_ratio/.46)
            if f<=.855:return z0+h*(crotch_ratio+(f-.46)*(shoulder_ratio-crotch_ratio)/(.855-.46))
            return z0+h*(shoulder_ratio+(f-.855)*(1-shoulder_ratio)/(.145))
        _nwcs_mirror_state.clear()
        old=bpy.data.collections.get('NWCS Control Rings')
        if old:
            for o in list(old.objects):bpy.data.objects.remove(o,do_unlink=True)
        coll=old or bpy.data.collections.new('NWCS Control Rings')
        if not old:context.scene.collection.children.link(coll)
        # Sample body vertex extents in horizontal slabs. Conservative initial ellipses.
        if p.preset=='CARDIGAN':
            levels=[('Hem',p.cardigan_hem,1.035),('Waist',.635,1.045),('Bust',.75,1.085),('Neckline',.86,.65)]
        elif p.preset=='CORSET': levels=[('Hem',.54,1.035),('Waist',.64,1.03),('Bust Support',.715,1.025),('Bust',.755,1.035)]
        elif p.preset=='BRA': levels=[('Underband',.69,1.015),('Bust',.765,1.015),('StrapTop',.86,.70)]
        elif p.preset=='BIKINI': levels=[('Crotch',p.panty_waist-.095,1.025),('Hip',p.panty_waist-.045,1.025),('Waist',p.panty_waist,1.025)]
        elif p.preset in {'BOXER_BRIEFS','BOXER_SHORTS'}: levels=[('Waist',.57,1.035 if p.preset=='BOXER_BRIEFS' else 1.09),('Hip',.49,1.045 if p.preset=='BOXER_BRIEFS' else 1.11)]
        elif p.preset=='TANK': levels=[('Hem',.56,1.05),('Waist',.64,1.045),('Chest',.75,.94),('Neck',.86,.64)]
        elif p.preset=='MINI': levels=[('Hem',.39,p.skirt_fullness),('Waist',.57,1.0)]
        elif p.preset=='LONG': levels=[('Hem',.12,p.skirt_fullness),('Waist',.57,1.0)]
        elif p.preset=='PANTS':
            waist_level={'LOW':.52,'MID':.57,'HIGH':.62}[p.pants_waist]
            levels=[('Waist',waist_level,1.0),('Hip',.49,1.06)]
        elif p.preset=='DRESS':
            length_factor={'MINI':.38,'KNEE':.29,'MIDI':.20,'MAXI':.10}[p.dress_length]
            fullness={'SHEATH':1.04,'ALINE':1.30,'FITFLARE':1.75,'EMPIRE':1.40}[p.dress_style]
            levels=[('Hem',length_factor,fullness),('Hip',.49,1.05),('Waist',.57,1.03),('Underbust',.68,1.03),('Bust',.75,1.04),('Neckline',.86,.65)]
        elif p.preset in {'SWEATER','TSHIRT'}:
            fit={'FITTED':1.015,'RELAXED':1.14,'OVERSIZED':1.27,'CROPPED':1.08}[p.sweater_fit]
            if p.preset=='TSHIRT':
                fit=1.08 if p.tshirt_fit=='REGULAR' else 1.16
            cropped=p.preset=='SWEATER' and (p.sweater_crop or p.sweater_fit=='CROPPED')
            hem=p.sweater_crop_height if cropped else .545
            waist=max(.635,hem+.045) if cropped else .635
            # Lower controls hug the torso rather than inheriting the loose bust multiplier.
            lower={'FITTED':1.005,'RELAXED':1.055,'OVERSIZED':1.11,'CROPPED':1.035}[p.sweater_fit]
            if p.preset=='TSHIRT':lower=1.045 if p.tshirt_fit=='REGULAR' else 1.105
            levels=[('Hem',hem,lower),('Waist',waist,lower),('Bust',.75,fit),('Neckline',.86,.65)]
        else: levels=[('Hem',p.hem_height,1.12),('Waist',p.waist_height,1.08),('Chest',p.chest_height,1.06),('Neck',p.top_height,0.60)]
        if p.preset in {'MINI','LONG','DRESS'} and p.ruffle_style!='NONE' and p.rings < p.ruffle_count*8:
            p.rings=min(128,p.ruffle_count*8)
        if p.preset in {'MINI','LONG'} and p.pleat_style=='PLEATED' and p.rings < p.pleat_count*6:
            p.rings=min(128,p.pleat_count*6)
        # Neck ring remains at its actual neck elevation; never push it down
        # to the shoulder plane (that buried the collar in the shoulders).
        for label,factor,mult in levels:
            z=body_level(factor);slab=max(h*.055,.015)
            if p.preset=='TANK' and label=='Waist':
                waist_slices=[]
                for step in range(62,80):
                    sample_z=z0+h*step/100
                    section=[v for v in coords if abs(v.z-sample_z)<h*.006 and abs(v.x-cx)<h*.20]
                    if len(section)>=12:
                        xs=sorted(v.x for v in section);ys=sorted(v.y for v in section)
                        width=xs[int((len(xs)-1)*.97)]-xs[int((len(xs)-1)*.03)]
                        depth=ys[int((len(ys)-1)*.97)]-ys[int((len(ys)-1)*.03)]
                        waist_slices.append((width*depth,sample_z))
                if waist_slices:z=min(waist_slices,key=lambda item:item[0])[1]
            if p.preset=='TANK' and label=='Chest':
                bust_slices=[]
                for step in range(74,91):
                    sample_z=z0+h*step/100
                    section=[v for v in coords if abs(v.z-sample_z)<h*.006 and abs(v.x-cx)<h*.16]
                    if len(section)>=12:
                        ys=sorted(v.y for v in section)
                        depth=ys[int((len(ys)-1)*.97)]-ys[int((len(ys)-1)*.03)]
                        bust_slices.append((depth,sample_z))
                if bust_slices:z=max(bust_slices,key=lambda item:item[0])[1]
            if label in {'Neck','Neckline'} and p.preset in {'TANK','DRESS','SWEATER','TSHIRT','CARDIGAN'}:
                z=neck_landmark.z
            nearby=[v for v in coords if abs(v.z-z)<slab]
            if not nearby:nearby=sorted(coords,key=lambda v:abs(v.z-z))[:max(10,len(coords)//100)]
            gap=p.waist_fit_offset if label=='Waist' and p.preset in {'MINI','LONG','PANTS','DRESS'} else p.clearance
            # Tank upper rings must not include extended arms/shoulders from
            # the broad body sampling slab.  Sample close to the ring's own
            # elevation and use robust torso extents rather than arm outliers.
            if (p.preset in {'TANK','DRESS','SWEATER','TSHIRT','CARDIGAN','BRA','CORSET','BIKINI','BOXER_BRIEFS','BOXER_SHORTS'} and label in {'Chest','Neck','Bust','Neckline','Underbust','Waist','Hem','StrapTop','Crotch','Hip','LegHem','Bust Support'}) or (p.preset=='PANTS' and label in {'Waist','Hip'}):
                narrow=[v for v in coords if abs(v.z-z)<max(h*.012,.008)]
                if len(narrow)>=12:nearby=narrow
                xvals=sorted(abs(v.x-cx) for v in nearby)
                yvals=sorted(abs(v.y-cy) for v in nearby)
                # Measure the torso silhouette rather than an inner 80%
                # quantile. Keep an allowance for shoulder/arm outliers.
                idx=max(0,int((len(xvals)-1)*.94))
                rx=xvals[idx]+min(gap*.65,.018)
                ry=yvals[idx]+min(gap*.65,.018)
            else:
                rx=max(abs(v.x-cx) for v in nearby)+gap
                ry=max(abs(v.y-cy) for v in nearby)+gap
            if p.preset=='CORSET' and label=='Bust Support':
                # The support guide is a torso-only ring, not an arm-span ellipse.
                # Derive its side width from the waist and a narrow rib-cage slab.
                waist_z=body_level(.64)
                wx=[v for v in coords if abs(v.z-waist_z)<max(h*.012,.008)]
                if len(wx)>=12:
                    xs=sorted(abs(v.x-cx) for v in wx)
                    ys=sorted(abs(v.y-cy) for v in wx)
                    idx=int((len(xs)-1)*.80)
                    rx=min(rx, max(.035,xs[idx]*1.075))
                    ry=min(ry, max(.025,ys[idx]*1.15))
                mult=1.025
            ring_cx,ring_cy=cx,cy
            if p.preset=='TANK' and label in {'Hem','Waist','Chest'}:
                section=[v for v in coords if abs(v.z-z)<h*.009 and abs(v.x-cx)<h*.22]
                if len(section)>=12:
                    xs=sorted(v.x for v in section);ys=sorted(v.y for v in section)
                    ring_cx=(xs[0]+xs[-1])*.5;ring_cy=(ys[0]+ys[-1])*.5
                    rx=max(.025,(xs[-1]-xs[0])*.5);ry=max(.02,(ys[-1]-ys[0])*.5)
                    ratios=sorted(math.sqrt(((v.x-ring_cx)/rx)**2+((v.y-ring_cy)/ry)**2) for v in section)
                    envelope=max(1.,ratios[int((len(ratios)-1)*.98)])
                    rx=rx*envelope+min(p.clearance*.5,.01);ry=ry*envelope+min(p.clearance*.5,.01)
                    mult=1.0
            ring=ring_at(z,(ring_cx,ring_cy),rx*mult,ry*mult,p.rings,PREFIX+label,coll,thickness=p.ring_thickness)
            if p.preset in {'TANK','DRESS','SWEATER','TSHIRT','CARDIGAN'} and label in {'Neck','Neckline'}:
                # The neck ring must be measured at the neck, not from the
                # outstretched arms included in a horizontal body slice.
                ring.location.x=neck_landmark.x;ring.location.y=neck_landmark.y
                neck_pts=[v for v in coords if abs(v.z-z)<h*.012 and abs(v.x-neck_landmark.x)<h*.105]
                if len(neck_pts)>=12:
                    xs=sorted(abs(v.x-neck_landmark.x) for v in neck_pts)
                    ys=sorted(abs(v.y-neck_landmark.y) for v in neck_pts)
                    ix=int((len(xs)-1)*.88)
                    nrx=min(h*.09,max(h*.038,xs[ix]+min(p.clearance*.25,.005)))
                    nry=min(h*.072,max(h*.026,ys[ix]+min(p.clearance*.25,.005)))
                else:
                    nrx=h*.062;nry=h*.044
                # Recenter the collar on the neck cross-section, not the torso.
                # This prevents the front of the ring projecting like a shelf.
                if len(neck_pts)>=12:
                    near_y=sorted(v.y for v in neck_pts)
                    neck_center_y=(near_y[int((len(near_y)-1)*.12)]+near_y[int((len(near_y)-1)*.88)])*.5
                    ring.location.y=neck_center_y
                # Refit the already-created curve instead of adding a second ring.
                for i,pt in enumerate(ring.data.splines[0].points):
                    a=2*math.pi*i/p.rings
                    pt.co.x=nrx*math.cos(a)
                    pt.co.y=nry*math.sin(a)
                p.neckline_ring_width=nrx
                p.neckline_ring_depth=nry
                nwcs_update_neckline_ring(context,p)
            if p.preset=='TANK':
                # Uniform X spacing on the front/back panels avoids nearly
                # coincident seam vertices after fitting cloth over the bust.
                points=ring.data.splines[0].points
                radius_x=max(abs(point.co.x) for point in points)
                radius_y=max(abs(point.co.y) for point in points)
                for i,point in enumerate(points):
                    phase=i/len(points)
                    x=1.-4.*phase if phase<=.5 else 4.*phase-3.
                    point.co.x=radius_x*x
                    point.co.y=radius_y*math.sqrt(max(0.,1.-x*x))*(1. if phase<.5 else -1.)
        if p.preset=='PANTS':
            # Use the body's actual left/right leg cross sections; no broad
            # torso sampling and no 8-cm default clearance on tiny ankles.
            leg_gap=min(p.clearance*.18,.014)
            for side,sign in [('L',1),('R',-1)]:
                leg_levels = ([('Thigh',.45),('Ankle',.425)] if p.pants_length=='SHORT' else
                              [('Thigh',.43),('Knee',.26),('Ankle',.20)] if p.pants_length=='CAPRI' else
                              [('Thigh',.43),('Knee',.26),('Ankle',.08)])
                for label,factor in leg_levels:
                    z=body_level(factor)
                    near=body_slice(body,z,cx,side=sign,band=h*.012)
                    # The leg center is the median, not the whole-body center.
                    x,y,rx,ry=fitted_ellipse(near,leg_gap,percentile=.90)
                    style_mult={'FITTED':1.0,'STRAIGHT':1.07,'WIDE':1.22,'FLARE':(1.28 if label=='Ankle' else 1.04)}[p.pants_style]
                    ring_at(z,(x,y),rx*style_mult,ry*style_mult,p.rings,PREFIX+side+'_'+label,coll,thickness=p.ring_thickness)
        if p.preset in {'BOXER_BRIEFS','BOXER_SHORTS'}:
            # The same thigh-to-hem ring names and ordering as Pants SHORT.
            # Both hem and thigh rings remain editable before construction.
            for side,sign in [('L',1),('R',-1)]:
                for label,factor in [('Thigh',.455),('Ankle',.405 if p.preset=='BOXER_BRIEFS' else .355)]:
                    z=body_level(factor)
                    near=body_slice(body,z,cx,side=sign,band=h*.012)
                    x,y,rx,ry=fitted_ellipse(near,min(p.clearance*.18,.014),percentile=.90)
                    scale=1.045 if p.preset=='BOXER_BRIEFS' else 1.14
                    ring_at(z,(x,y),rx*scale,ry*scale,p.rings,
                            PREFIX+side+'_'+label,coll,thickness=p.ring_thickness)
        # Arm controls follow actual armature joints where available; otherwise
        # estimate the arm axis from body geometry, including an angled A-pose.
        if p.preset in {'SWEATER','TSHIRT','DRESS','CARDIGAN'} and (p.preset!='DRESS' or p.dress_sleeves!='NONE'):
            shoulder_z=body_level(.855)
            for side,sign in [('L',1),('R',-1)]:
                shoulder,elbow,wrist=arm_landmarks(body,sign,cx,shoulder_z)
                # In a T-pose, sleeve cross-sections must be vertical in front
                # view. Only the shoulder guide receives a slight inward tilt.
                arm_pts=[body.matrix_world@v.co for v in body.data.vertices]
                far=max(((v.x-cx)*sign for v in arm_pts if abs(v.z-shoulder_z)<h*.12),default=h*.38)
                arm_end=cx+sign*(abs(shoulder.x-cx)+max(h*.12,(far-abs(shoulder.x-cx))*.70))
                def arm_center_at(x, fallback):
                    slab=[v for v in arm_pts if abs(v.x-x)<h*.013 and
                          abs(v.z-shoulder_z)<h*.105 and (v.x-cx)*sign>h*.13]
                    if len(slab)<6:return fallback
                    sy=sorted(v.y for v in slab);sz=sorted(v.z for v in slab)
                    return Vector((x,sy[len(sy)//2],sz[len(sz)//2]))
                tpose=abs((wrist-shoulder).z)<h*.11
                if tpose:
                    shoulder=arm_center_at(shoulder.x,shoulder)
                    wrist=arm_center_at(arm_end,Vector((arm_end,shoulder.y,shoulder.z)))
                    elbow=arm_center_at((shoulder.x+wrist.x)*.5,shoulder.lerp(wrist,.5))
                axis=(elbow-shoulder).normalized()
                if tpose:axis=Vector((float(sign),0,0))
                length_scale=({'SHORT':.40,'THREEQUARTER':.77,'LONG':1.0}[p.sweater_sleeves] if p.preset=='SWEATER' else (.40 if p.preset=='TSHIRT' else (.42 if p.dress_sleeves=='SHORT' else 1.0)))
                full=wrist-shoulder
                # Stop before the hand even when an armature's forearm bone
                # includes a portion of the hand or the mesh tip is misread.
                # In many imported avatars the wrist bone/mesh estimate is
                # inside the hand. Leave a margin and never extend beyond the
                # first 82% of the estimated shoulder-to-wrist vector.
                full*=.92 if tpose else .82
                # Only three visible sleeve controls: shoulder, elbow, cuff.
                # The upper arm is interpolated when building the sleeve.
                cuff=shoulder+full*length_scale
                locations=([('Shoulder',shoulder),('Wrist',cuff)] if p.preset=='TSHIRT' else [('Shoulder',shoulder),('Elbow',shoulder+(cuff-shoulder)*.55),('Wrist',cuff)])
                if tpose:
                    locations=[(label,arm_center_at(point.x,point)) for label,point in locations]
                # Radius is measured perpendicular to the local arm axis.
                arm_pts=[body.matrix_world@v.co for v in body.data.vertices]
                for label,point in locations:
                    dist=(point-shoulder).dot(axis)
                    nearby=[v for v in arm_pts if abs((v-shoulder).dot(axis)-dist)<max(h*.010,.006)
                            and (v.x-cx)*sign>abs(shoulder.x-cx)*.95]
                    # Exclude torso vertices and distant geometry that inflate rings.
                    candidates=sorted(((v-point)-axis*(v-point).dot(axis)).length for v in nearby)
                    # Reject torso/hand outliers; use the lower radial
                    # percentile, not the 75th percentile of a mixed slab.
                    candidates=[r for r in candidates if r<h*.065]
                    if len(candidates)>=8:
                        rad=candidates[min(len(candidates)-1,int(len(candidates)*.88))]+min(p.clearance*.12,.006)
                    else:rad=h*({'Shoulder':.032,'Elbow':.025,'Wrist':.017}[label])
                    # The shoulder root must clear the full upper-arm cross section in T-pose.
                    if label=='Shoulder' and p.preset=='SWEATER' and tpose:
                        rad=max(rad*1.20,h*.040)
                        rad=min(h*.055,rad)
                    else:
                        rad=min(h*.039,max(h*.009,rad))
                    # Elliptical rather than circular sleeve guides; slight
                    # depth compression follows the usual arm cross-section.
                    # Shoulder-only diagonal, leaning inward toward the neck.
                    ring_axis=axis.copy()
                    if label=='Shoulder' and tpose:
                        ring_axis=Vector((float(sign),0,.16)).normalized()
                    oriented_ring(point,ring_axis,(rad,rad*.88),p.rings,PREFIX+side+'_'+label,coll,p.ring_thickness)
        if p.body_protection and p.preset!='BIKINI':nwcs_protect_rings(context,p)
        # Initialize symmetry from the newly created controls, before the first transform.
        nwcs_sync_mirror_baseline()
        waist=bpy.data.objects.get(PREFIX+'Waist')
        for ob in context.selected_objects:ob.select_set(False)
        if waist:
            waist.select_set(True)
            context.view_layer.objects.active=waist
        # Enable Move gizmo in all 3D View editors of this workspace.
        for area in context.screen.areas if context.screen else []:
            if area.type=='VIEW_3D':
                area.spaces.active.show_gizmo=True
                area.spaces.active.show_gizmo_object_translate=True
                area.spaces.active.show_gizmo_object_rotate=False
                area.spaces.active.show_gizmo_object_scale=False
        activate_move(context)
        context.scene.tool_settings.transform_pivot_point='MEDIAN_POINT'
        self.report({'INFO'},'Control rings created. Move/scale controls, then Build Garment.')
        return {'FINISHED'}

class NWCS_OT_center_ring_origins(bpy.types.Operator):
    bl_idname='nwcs.center_ring_origins'
    bl_label='Center Ring Origins'
    bl_description='Set every control ring origin to its geometric center without moving the ring'
    bl_options={'REGISTER','UNDO'}
    def execute(self, context):
        coll=bpy.data.collections.get('NWCS Control Rings')
        if not coll:
            self.report({'WARNING'},'Create control rings first')
            return {'CANCELLED'}
        count=0
        for obj in coll.objects:
            if obj.type!='CURVE' or not obj.get('nwcs_ring'):
                continue
            points=[p for spline in obj.data.splines for p in spline.points]
            if not points:
                continue
            center=sum((Vector(p.co[:3]) for p in points),Vector())/len(points)
            # Shift curve geometry in local coordinates, preserving the world position.
            for point in points:
                point.co[:3]=Vector(point.co[:3])-center
            obj.location += obj.matrix_world.to_3x3() @ center
            obj.data.update_tag()
            count+=1
        self.report({'INFO'},f'Centered origins on {count} control rings')
        return {'FINISHED'}

class NWCS_OT_fit_waist(bpy.types.Operator):
    bl_idname='nwcs.fit_waist';bl_label='Fit Waist Ring to Body';bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        p=context.scene.nwcs_props
        body=p.reference_body
        ring=bpy.data.objects.get(PREFIX+'Waist')
        if not body or body.type!='MESH' or not ring:
            self.report({'ERROR'},'Choose a mesh body and create control rings first')
            return {'CANCELLED'}
        if context.object and context.object.mode!='OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        z=ring.matrix_world.translation.z
        # Intersect actual evaluated body triangles with the waist plane.
        # This avoids the oversized fit caused by sampling a thick vertical slab.
        depsgraph=context.evaluated_depsgraph_get()
        evaluated=body.evaluated_get(depsgraph)
        mesh=evaluated.to_mesh()
        hits=[]
        try:
            mesh.calc_loop_triangles()
            world=[evaluated.matrix_world @ v.co for v in mesh.vertices]
            for tri in mesh.loop_triangles:
                vs=[world[i] for i in tri.vertices]
                for i,j in ((0,1),(1,2),(2,0)):
                    a,b=vs[i],vs[j]
                    dz=b.z-a.z
                    if abs(dz)<1e-9:continue
                    t=(z-a.z)/dz
                    if 0<=t<=1:
                        hits.append(a.lerp(b,t))
        finally:
            evaluated.to_mesh_clear()
        if len(hits)<8:
            self.report({'ERROR'},'No usable body cross-section at this ring height. Move ring to the waist.')
            return {'CANCELLED'}
        # Use the cross-section center rather than the full-body bounding-box center.
        xmin=min(v.x for v in hits);xmax=max(v.x for v in hits)
        ymin=min(v.y for v in hits);ymax=max(v.y for v in hits)
        cx=(xmin+xmax)*.5;cy=(ymin+ymax)*.5
        rx=(xmax-xmin)*.5+p.waist_fit_offset
        ry=(ymax-ymin)*.5+p.waist_fit_offset
        # Clear any old object scale/rotation. The ring is reconstructed in local
        # coordinates, so repeated fits are idempotent even after manual scaling.
        ring.parent=None
        ring.location=(cx,cy,z)
        ring.rotation_mode='XYZ'
        ring.rotation_euler=(0,0,0)
        ring.scale=(1,1,1)
        points=ring.data.splines[0].points
        for i,pt in enumerate(points):
            angle=2*math.pi*i/len(points)
            pt.co=(rx*math.cos(angle),ry*math.sin(angle),0,1)
        ring.data.update_tag()
        context.view_layer.update()
        self.report({'INFO'},'Waist ring fitted to the body cross-section; prior scale cleared')
        return {'FINISHED'}

class NWCS_OT_conform_waist(bpy.types.Operator):
    bl_idname='nwcs.conform_waist';bl_label='Apply Waist Conform';bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        p=context.scene.nwcs_props
        body=p.reference_body
        obj=next((o for o in context.scene.objects if o.get('nwcs_sim_ready')),None)
        if p.preset not in {'MINI','LONG'} or not obj or not body or body.type!='MESH':
            self.report({'ERROR'},'Build a skirt and assign a mesh Reference Body first')
            return {'CANCELLED'}
        if obj==body:
            self.report({'ERROR'},'Reference Body cannot be the garment')
            return {'CANCELLED'}
        cloth=next((m for m in obj.modifiers if m.type=='CLOTH'),None)
        if cloth and cloth.point_cache.is_baked:
            self.report({'ERROR'},'Free baked cloth cache before conforming')
            return {'CANCELLED'}
        # Generated skirt rows run from hem to waistband. Restrict conform to
        # the last rows and fade its influence below the top edge.
        count=int(obj.get('nwcs_torso_rows',0))
        segments=int(obj.get('nwcs_segments',0))
        if count<2 or segments<3:
            self.report({'ERROR'},'Garment lacks skirt row metadata; rebuild using v1.2')
            return {'CANCELLED'}
        old=obj.vertex_groups.get('NWCS_Waist_Conform')
        if old:obj.vertex_groups.remove(old)
        group=obj.vertex_groups.new(name='NWCS_Waist_Conform')
        rows=min(p.conform_rows,count)
        for k in range(rows):
            # Full fit at top, smoothly decreasing below it.
            weight=(1.0-k/rows)**2
            start=(count-1-k)*segments
            group.add(list(range(start,start+segments)),weight,'REPLACE')
        sw=obj.modifiers.new('NWCS Temporary Waist Conform','SHRINKWRAP')
        sw.target=body
        sw.wrap_method='NEAREST_SURFACEPOINT'
        sw.offset=p.conform_clearance
        sw.vertex_group=group.name
        # Bake just the fitting operation into geometry, not the cloth modifier.
        # Temporarily move it before Cloth and disable other modifiers.
        previous=context.view_layer.objects.active
        previously_selected=list(context.selected_objects)
        try:
            if obj.hide_get():obj.hide_set(False)
            for ob in previously_selected:ob.select_set(False)
            obj.select_set(True);context.view_layer.objects.active=obj
            while obj.modifiers[0]!=sw:
                bpy.ops.object.modifier_move_up(modifier=sw.name)
            bpy.ops.object.modifier_apply(modifier=sw.name)
            context.scene.frame_set(1)
        except Exception as ex:
            if sw.name in obj.modifiers:obj.modifiers.remove(sw)
            self.report({'ERROR'},f'Waist conform failed: {ex}')
            return {'CANCELLED'}
        finally:
            obj.select_set(False)
            for ob in previously_selected:
                if ob.name in bpy.data.objects:ob.select_set(True)
            if previous and previous.name in bpy.data.objects:context.view_layer.objects.active=previous
        self.report({'INFO'},'Waist conformed to reference body. Reset and replay cloth simulation.')
        return {'FINISHED'}

def nwcs_fit_lower_waist(context, obj, p, operator=None):
    """Bake a narrow, weighted body-surface fit into lower garment waist geometry.

    Keeps crotch, leg openings, and the rest of the mesh unchanged. This is
    done before Cloth, never as a live modifier on the simulation stack.
    """
    if p.preset not in {'PANTS', 'BOXER_BRIEFS', 'BOXER_SHORTS', 'BIKINI'}:
        return False
    body=p.reference_body
    if not body or body.type!='MESH' or body==obj or not obj.data.vertices:
        return False
    from mathutils import Vector
    verts=obj.data.vertices
    world=[obj.matrix_world @ v.co for v in verts]
    top=max(v.z for v in world)
    bottom=min(v.z for v in world)
    # The upper 12% of the garment is the waistband; feather its lower edge.
    band=max(.012,(top-bottom)*.12)
    old=obj.vertex_groups.get('NWCS_Lower_Waist_Fit')
    if old:obj.vertex_groups.remove(old)
    group=obj.vertex_groups.new(name='NWCS_Lower_Waist_Fit')
    indices=[]
    for i,co in enumerate(world):
        delta=top-co.z
        if delta<=band:
            t=max(0.,min(1.,1.-delta/band))
            weight=max(.001,t*t*(3.-2.*t))
            group.add([i],weight,'REPLACE')
            indices.append(i)
    if not indices:return False
    sw=obj.modifiers.new('NWCS Lower Waist Body Fit','SHRINKWRAP')
    sw.target=body
    sw.wrap_method='NEAREST_SURFACEPOINT'
    sw.offset=p.conform_clearance
    sw.vertex_group=group.name
    try:
        with context.temp_override(object=obj,active_object=obj,selected_objects=[obj],selected_editable_objects=[obj]):
            bpy.ops.object.modifier_apply(modifier=sw.name)
        if operator:operator.report({'INFO'},p.preset+' waistband fitted to avatar')
        return True
    except Exception as exc:
        if obj.modifiers.get(sw.name):obj.modifiers.remove(sw)
        if operator:operator.report({'WARNING'},'Waist fitting skipped: '+str(exc))
        return False

def build_connected_pants(context, p, operator):
    """Build a true pair-of-pants surface: waist + two leg tubes + raised crotch saddle.

    No voxel remesh, Boolean cutter, or solid hip cylinder below the crotch.
    The mesh has three boundary loops: waist, left hem and right hem.
    """
    waist=bpy.data.objects.get(PREFIX+'Waist')
    hip=bpy.data.objects.get(PREFIX+'Hip')
    boxer=p.preset in {'BOXER_BRIEFS','BOXER_SHORTS'}
    leg_names=('Thigh','Ankle') if boxer or p.pants_length=='SHORT' else ('Thigh','Knee','Ankle')
    rings={side:[bpy.data.objects.get(PREFIX+side+'_'+name) for name in leg_names]
           for side in ('L','R')}
    all_rings=[waist,hip]+rings['L']+rings['R']
    if any(r is None for r in all_rings):
        operator.report({'ERROR'},'Create Pants Control Rings first')
        return {'CANCELLED'}
    n=len(ring_points(waist))
    if n<16 or n%4 or any(len(ring_points(r))!=n for r in all_rings):
        operator.report({'ERROR'},'Pants require matching ring counts divisible by 4 (minimum 16)')
        return {'CANCELLED'}
    wp=[Vector(v) for v in ring_points(waist)]
    hp=[Vector(v) for v in ring_points(hip)]
    lp={s:[[Vector(v) for v in ring_points(r)] for r in rings[s]] for s in ('L','R')}
    left_center=sum(lp['L'][0],Vector())/n
    right_center=sum(lp['R'][0],Vector())/n
    # Ring angles start at +X; positive-X leg is L, negative-X leg is R.
    if left_center.x <= right_center.x:
        operator.report({'ERROR'},'Left and right thigh controls are reversed; rebuild control rings')
        return {'CANCELLED'}
    # Body-fitted thigh controls can overlap on closely spaced avatar legs.
    # Automatically resolve only the inward-facing overlap, keeping ring shapes
    # and the user-adjusted controls intact. Apply the same shift to every leg
    # profile so the pant legs do not twist or taper sideways between rings.
    left_inner=min(v.x for v in lp['L'][0]);right_inner=max(v.x for v in lp['R'][0])
    if left_inner <= right_inner+1e-5:
        # Separate the leg surfaces by a small gap without altering Y or Z.
        # Ring geometry is in world coordinates (ring_points).
        gap=max(0.004, (abs(left_center.x-right_center.x))*0.025)
        shift=(right_inner-left_inner+gap)*0.5
        for profile in lp['L']:
            for v in profile:v.x+=shift
        for profile in lp['R']:
            for v in profile:v.x-=shift
        left_center.x+=shift
        right_center.x-=shift
        operator.report({'INFO'},'Auto-separated overlapping thigh rings for pants/boxers')
    verts=[];faces=[]
    def add_loop(points):
        start=len(verts);verts.extend(tuple(v) for v in points)
        return [start+i for i in range(len(points))]
    def quad(a,b,c,d):faces.append((a,b,c,d))
    def connect(a,b):
        for i in range(n):
            j=(i+1)%n
            quad(a[i],a[j],b[j],b[i])
    waist_loop=add_loop(wp);hip_loop=add_loop(hp)
    # Integrated boxer waistband with pronounced recessed lower seam.
    # All successive loops are welded through shared face indices: no Edge Split.
    waistband_face_start = len(faces)
    waistband_face_end = waistband_face_start
    waistband_seam_start = waistband_face_start
    waistband_seam_end = waistband_face_start
    if p.preset=='BOXER_BRIEFS':
        waist_z_avg=sum(v.z for v in wp)/n
        hip_z_avg=sum(v.z for v in hp)/n
        span=max(.025,waist_z_avg-hip_z_avg)
        depth=min(span*.55,max(.026,span*.36))
        cx=sum(v.x for v in wp)/n
        cy=sum(v.y for v in wp)/n
        # Project outward from the actual waist control rather than a fixed radius.
        relief=max(.005,min(.011,span*.065))
        groove=max(.003,min(.006,relief*.65))
        def band_profile(drop,offset):
            out=[]
            for v in wp:
                radial=Vector((v.x-cx,v.y-cy,0))
                if radial.length_squared>1e-12:radial.normalize()
                out.append(v+radial*offset+Vector((0,0,-drop)))
            return out
        top_ridge=add_loop(band_profile(depth*.08,relief*.75))
        band_upper=add_loop(band_profile(depth*.20,relief))
        band_lower=add_loop(band_profile(depth*.78,relief))
        # Narrow raised piping above a deep crease, then a smooth return to cloth.
        seam_ridge=add_loop(band_profile(depth*.86,relief*1.18))
        seam_valley=add_loop(band_profile(depth*.92,-groove))
        seam_exit=add_loop(band_profile(depth*.99,relief*.08))
        connect(waist_loop,top_ridge)
        connect(top_ridge,band_upper)
        connect(band_upper,band_lower)
        waistband_face_end=len(faces)
        waistband_seam_start=len(faces)
        connect(band_lower,seam_ridge)
        connect(seam_ridge,seam_valley)
        connect(seam_valley,seam_exit)
        waistband_seam_end=len(faces)
        connect(seam_exit,hip_loop)
    else:
        connect(waist_loop,hip_loop)
    leg_loops={}
    for side in ('L','R'):
        # Profiles descend from thigh to ankle; no closed caps or inner solid.
        profiles=lp[side]
        loops=[add_loop(profile) for profile in profiles]
        leg_loops[side]=loops
        for j in range(len(loops)-1):connect(loops[j],loops[j+1])
    l=leg_loops['L'][0];r=leg_loops['R'][0]
    quarter=n//4;half=n//2
    # The OUTER half of each leg joins the corresponding half of the hip.
    # The inner halves are joined through an elevated crotch seam instead.
    for k in range(half):
        i=(-quarter+k)%n;j=(-quarter+k+1)%n
        quad(hip_loop[i],hip_loop[j],l[j],l[i])
        i=(quarter+k)%n;j=(quarter+k+1)%n
        quad(hip_loop[i],hip_loop[j],r[j],r[i])
    hip_z=sum(v.z for v in hp)/n
    thigh_z=min(left_center.z,right_center.z)
    crotch_z=thigh_z+max(.008,(hip_z-thigh_z)*.52)
    # A raised seam runs from the front to the back between the thighs.
    # This avoids the horizontal fabric web that made shorts look like a skirt.
    midx=(left_center.x+right_center.x)*.5
    # Evenly distribute crotch-seam vertices between the actual front and back
    # thigh-ring endpoints. Angular (sine) sampling clusters the first/last
    # vertices almost on top of each other, creating two extreme edge outliers
    # in boxer shorts and briefs despite otherwise valid mesh topology.
    front_y=(lp['L'][0][quarter].y+lp['R'][0][quarter].y)*.5
    back_y=(lp['L'][0][(quarter+half)%n].y+lp['R'][0][(quarter-half)%n].y)*.5
    seam=[]
    for k in range(half+1):
        y=front_y+(back_y-front_y)*(k/half)
        seam.append(len(verts))
        verts.append((midx,y,crotch_z))
    for k in range(half):
        li=(quarter+k)%n;lj=(quarter+k+1)%n
        ri=(quarter-k)%n;rj=(quarter-k-1)%n
        quad(l[li],l[lj],seam[k+1],seam[k])
        quad(seam[k],seam[k+1],r[rj],r[ri])
    # Close front/back crotch junctions with two triangles each.
    front=quarter;back=(3*quarter)%n
    faces.append((hip_loop[front],l[front],seam[0]))
    faces.append((hip_loop[front],seam[0],r[front]))
    faces.append((hip_loop[back],seam[-1],l[back]))
    faces.append((hip_loop[back],r[back],seam[-1]))
    # Check the topology before touching an existing working garment.
    from collections import Counter
    edges=Counter()
    for f in faces:
        for i in range(len(f)):
            edge=tuple(sorted((f[i],f[(i+1)%len(f)])))
            edges[edge]+=1
    if any(count>2 for count in edges.values()):
        operator.report({'ERROR'},'Pants topology failed: non-manifold crotch')
        return {'CANCELLED'}
    mesh=bpy.data.meshes.new('NWCS_Pants_TrueCrotchMesh')
    mesh.from_pydata(verts,[],faces);mesh.update()
    for old in list(context.scene.objects):
        if old.get('nwcs_sim_ready') and not old.get('nwcs_frozen'):
            bpy.data.objects.remove(old,do_unlink=True)
    obj=bpy.data.objects.new('NWCS_Garment',mesh)
    context.scene.collection.objects.link(obj)
    for ob in context.selected_objects:ob.select_set(False)
    obj.select_set(True);context.view_layer.objects.active=obj
    # Recalculate normals and create UVs without changing the pants topology.
    import bmesh
    bm=bmesh.new();bm.from_mesh(mesh)
    bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
    bm.to_mesh(mesh);bm.free();mesh.update()
    # Repair/validate the actual cloth cage BEFORE creating the cloth modifier.
    # Boxers share the connected-pants builder; their short crotch transitions
    # can contain loose or folded elements that otherwise reach simulation.
    nwcs_repair_cloth_cage(obj)
    # Run the boxer-specific edge correction BEFORE the first validation.
    # Previously the initial validation cancelled garment construction before
    # the later boxer repair could ever run.
    if boxer:
        nwcs_relax_boxer_edge_outliers(obj)
    try:
        nwcs_validate_cloth_cage(obj, p.preset + ' pre-fit')
    except ValueError as exc:
        bpy.data.objects.remove(obj, do_unlink=True)
        operator.report({'ERROR'}, str(exc))
        return {'CANCELLED'}
    for poly in mesh.polygons:poly.use_smooth=True
    if p.preset=='BOXER_BRIEFS':
        # A distinct material slot makes the integral waistband easy to texture.
        band_mat=bpy.data.materials.get('NWCS Boxer Elastic Waistband')
        if band_mat is None:
            band_mat=bpy.data.materials.new('NWCS Boxer Elastic Waistband')
            band_mat.diffuse_color=(.075,.075,.075,1.0)
        mesh.materials.append(band_mat)
        band_slot=len(mesh.materials)-1
        for fi in range(waistband_face_start,waistband_face_end):
            mesh.polygons[fi].material_index=band_slot
        seam_mat=bpy.data.materials.get('NWCS Boxer Waistband Seam')
        if seam_mat is None:
            seam_mat=bpy.data.materials.new('NWCS Boxer Waistband Seam')
            seam_mat.diffuse_color=(.085,.075,.075,1.0)
        seam_slot=len(mesh.materials)
        mesh.materials.append(seam_mat)
        for fi in range(waistband_seam_start,waistband_seam_end):
            mesh.polygons[fi].material_index=seam_slot
    nwcs_trouser_pattern_uv(obj)
    waist_z=sum(v.z for v in wp)/n
    hip_z=sum(v.z for v in hp)/n
    band=max(.012,abs(waist_z-hip_z)*.12)
    group=obj.vertex_groups.new(name='NWCS_Edge_Anchors')
    for v in mesh.vertices:
        if v.co.z>=waist_z-band:
            weight=min(1.0,max(.05,(v.co.z-(waist_z-band))/band))
            group.add([v.index],weight*p.pin_strength,'REPLACE')
    # Conform the waist only; this routine is shared with boxers and bikinis.
    if p.preset!='BOXER_BRIEFS':
        nwcs_fit_lower_waist(context, obj, p, operator)
    # Surface smoothing is visual only and happens after cloth, preserving
    # the already-working crotch junction and separate leg openings.
    if p.body_protection:
        nwcs_fit_garment_outside_body(context,obj,p.reference_body,p.body_min_gap)
    if boxer:
        # Body fitting can pull isolated crotch junctions away from adjacent
        # vertices. Relax only confirmed edge-outlier vertices, preserving
        # mesh topology, waistband anchors, and every other garment preset.
        nwcs_relax_boxer_edge_outliers(obj)
        try:
            nwcs_validate_cloth_cage(obj, p.preset + ' post-fit')
        except ValueError as exc:
            bpy.data.objects.remove(obj, do_unlink=True)
            operator.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
    cloth=obj.modifiers.new('NWCS Cloth','CLOTH')
    cloth.settings.vertex_group_mass=group.name
    cloth.settings.quality=9
    presets={'COTTON':(.22,18,12,1.5,1),'SILK':(.10,7,5,.25,.4),
             'DENIM':(.40,38,28,6,1.8),'LEATHER':(.48,55,40,10,2.5)}
    mass,stretch,shear,bend,air=presets[p.fabric]
    cloth.settings.mass=mass
    cloth.settings.tension_stiffness=stretch
    cloth.settings.compression_stiffness=stretch
    cloth.settings.shear_stiffness=shear
    cloth.settings.bending_stiffness=bend
    cloth.settings.air_damping=air
    cloth.collision_settings.use_self_collision=False
    cloth.collision_settings.distance_min=.005
    obj['nwcs_preset'] = p.preset
    nwcs_solver_stability_profile(obj,cloth,p)
    nwcs_configure_collision_environment(context,obj,cloth,p.reference_body)
    cloth.point_cache.frame_start=1;cloth.point_cache.frame_end=p.sim_frames
    obj['nwcs_generated']=True
    obj['nwcs_sim_ready']=True
    # Catmull-Clark softens angular thigh/hip transitions and silhouette.
    # AFTER cloth means it cannot alter the cloth topology or crotch seams.
    smooth=obj.modifiers.new('NWCS Pants Surface Smoothing','SUBSURF')
    smooth.subdivision_type='CATMULL_CLARK'
    smooth.levels=2
    smooth.render_levels=2
    nwcs_add_fabric_thickness(obj,p.fabric_thickness)
    obj['nwcs_connected_pants']=True
    obj['nwcs_torso_rows']=0
    obj['nwcs_segments']=n
    body=p.reference_body
    if body and not any(m.type=='COLLISION' for m in body.modifiers):
        body.modifiers.new('NWCS Body Collision','COLLISION')
    context.scene.frame_start=1;context.scene.frame_end=p.sim_frames
    context.scene.frame_set(1)
    coll=bpy.data.collections.get('NWCS Control Rings')
    if coll:
        if boxer:
            for ring in list(coll.objects):bpy.data.objects.remove(ring,do_unlink=True)
        else:
            for ring in coll.objects:ring.hide_set(True);ring.hide_render=True
    nwcs_finish_garment_transform(context,obj)
    operator.report({'INFO'},'True crotch topology built: two independent leg openings')
    return {'FINISHED'}

def nwcs_fit_garment_outside_body(context, obj, body, gap):
    """Keep the rest mesh intact before cloth starts.

    Previous releases projected each penetrating vertex independently along
    the nearest avatar triangle normal. At elbows, armpits and necklines,
    adjacent vertices could receive divergent normals and form needle-shaped
    cloth elements. Body contact is now left to Blender's collision solver.
    Control rings must be adjusted if the initial garment penetrates deeply.
    """
    return 0


def nwcs_cap_surface_material():
    name="NWCS Surface (temporary)"
    mat=bpy.data.materials.get(name)
    if mat is None:mat=bpy.data.materials.new(name)
    return mat

def nwcs_cap_marker_material():
    name="NWCS Construction Cap (temporary)"
    mat=bpy.data.materials.get(name)
    if mat is None:mat=bpy.data.materials.new(name)
    return mat

def nwcs_add_shoulder_yoke(rows, n, body_height):
    """Add a supported upper-chest/shoulder transition before neck taper.

    The old direct bust-to-neck interpolation collapsed the entire shoulder
    surface into the neck edge. Preserve a torso-width ring just below the
    neckline so the cloth has an actual shoulder panel to drape over.
    """
    if len(rows)<3:return rows
    collar=rows[-1]
    bust=rows[-5] if len(rows)>=5 else rows[-2]
    neck_center=sum(collar,Vector())/n
    # Use the actual torso shape, but move up near the collar. This creates
    # a short, well-supported transition rather than a long sloping wedge.
    yoke=[]
    for i in range(n):
        base=Vector(bust[i])
        top=Vector(collar[i])
        v=base.lerp(top,.16)
        v.z=max(v.z,top.z-body_height*.040)
        yoke.append(v)
    # Replace only the penultimate interpolation row. The collar and its
    # exact chosen shape remain unchanged.
    rows[-2]=yoke
    return rows

def build_connected_sleeved(context,p,operator):
    """Build a single open, connected cloth cage without Boolean unions.

    Torso armholes are removed as rectangular patches of the structured ring
    mesh; each hole is connected to its sleeve by a graded transition surface.
    No capped solids, Boolean slivers, or overlapping sleeve interior faces.
    """
    labels=('Hem','Hip','Waist','Underbust','Bust','Neckline') if p.preset=='DRESS' else ('Hem','Waist','Bust','Neckline')
    torso=[bpy.data.objects.get(PREFIX+name) for name in labels]
    arm_labels=('Shoulder','Wrist') if p.preset=='TSHIRT' else ('Shoulder','Elbow','Wrist')
    arms={side:[bpy.data.objects.get(PREFIX+side+'_'+name) for name in arm_labels] for side in ('L','R')}
    if any(r is None for r in torso) or any(r is None for rs in arms.values() for r in rs):
        operator.report({'ERROR'},'Create garment control rings first');return {'CANCELLED'}
    n=len(ring_points(torso[0]))
    if n<16 or n%2 or any(len(ring_points(r))!=n for r in torso+sum(arms.values(),[])):
        operator.report({'ERROR'},'Sleeved garments require an even ring segment count of at least 16');return {'CANCELLED'}
    rows=[]
    for a,b in zip(torso[:-1],torso[1:]):
        low=[Vector(v) for v in ring_points(a)];high=[Vector(v) for v in ring_points(b)]
        if not rows:rows.append(low)
        for t in (.25,.5,.75,1.):rows.append([x.lerp(y,t) for x,y in zip(low,high)])
    height=body_bounds(p.reference_body)[1]-body_bounds(p.reference_body)[0]
    # Shoulder transition preserves broad upper chest rather than collapsing
    # the final torso strip directly into a small neck opening.
    nwcs_add_shoulder_yoke(rows,n,height)
    # Neckline: distribute the actual cutout over the last three rings, and
    # clamp its depth against the local shoulder strip to avoid folded quads.
    nwcs_blend_neck_rows(rows,n,height)
    # Build torso ring lattice, with symmetric side patches removed.
    verts=[tuple(v) for ring in rows for v in ring]
    if p.preset=='DRESS' and p.ruffle_style != 'NONE':
        waist_z=sum(v.z for v in ring_points(torso[2]))/n
        hem_z=sum(v.z for v in ring_points(torso[0]))/n
        verts=nwcs_flounce_hem(verts,p,waist_z,hem_z)
    faces=[];m=len(rows)
    # Hole dimensions in grid cells: stay clear of neckline and bust.
    hw=max(2,min(n//8,7));hh=max(2,min(m//4,4))
    j0=m-2-hh
    if j0<1:
        operator.report({'ERROR'},'Insufficient torso rows for armholes');return {'CANCELLED'}
    centers={'L':0,'R':n//2}
    holes={}
    cut=set()
    for side,c in centers.items():
        i0=c-hw//2
        for j in range(j0,j0+hh):
            for di in range(hw):cut.add((j,(i0+di)%n))
        # Consistently ordered perimeter around the rectangular removed faces.
        perimeter=[]
        for di in range(hw):perimeter.append((j0,(i0+di)%n))
        for dj in range(hh):perimeter.append((j0+dj,(i0+hw)%n))
        for di in range(hw,0,-1):perimeter.append((j0+hh,(i0+di)%n))
        for dj in range(hh,0,-1):perimeter.append((j0+dj,(i0)%n))
        holes[side]=[j*n+i for j,i in perimeter]
    for j in range(m-1):
        for i in range(n):
            if (j,i) in cut:continue
            k=(i+1)%n
            faces.append((j*n+i,j*n+k,(j+1)*n+k,(j+1)*n+i))
    def add_ring(points):
        start=len(verts);verts.extend(tuple(v) for v in points)
        return [start+i for i in range(len(points))]
    def join(a,b):
        if len(a)!=len(b):raise ValueError('Unmatched sleeve bridge loops')
        for i in range(len(a)):
            k=(i+1)%len(a)
            faces.append((a[i],a[k],b[k],b[i]))
    def sample_loop(points,count):
        # Arc-length sampling avoids narrow wedge faces at unequal ring counts.
        distances=[(points[(i+1)%len(points)]-points[i]).length for i in range(len(points))]
        total=sum(distances)
        if total<1e-7:raise ValueError('Collapsed armhole loop')
        result=[]
        for k in range(count):
            d=total*k/count
            for i,seg in enumerate(distances):
                if d<=seg or i==len(distances)-1:
                    result.append(points[i].lerp(points[(i+1)%len(points)],d/max(seg,1e-9)))
                    break
                d-=seg
        return result
    for side in ('L','R'):
        rp=[[Vector(v) for v in ring_points(r)] for r in arms[side]]
        if len(rp)==2:rp.insert(1,[a.lerp(b,.5) for a,b in zip(rp[0],rp[1])])
        sleeve_center=sum(rp[0],Vector())/n
        # Use shoulder ring as the sleeve's actual root, not an interior
        # capped tube penetrating the torso wall.
        boundary=holes[side]
        bp=[Vector(verts[k]) for k in boundary]
        # Rotate the sleeve seam to match the armhole's closest point.
        start=min(range(n),key=lambda k:(rp[0][k]-bp[0]).length_squared)
        sleeve=[rp[0][(start+k)%n] for k in range(n)]
        # Compare winding to prevent twisted bridges.
        forward=sum((sample_loop(bp,n)[k]-sleeve[k]).length_squared for k in range(n))
        reverse=[sleeve[(-k)%n] for k in range(n)]
        backward=sum((sample_loop(bp,n)[k]-reverse[k]).length_squared for k in range(n))
        if backward<forward:sleeve=reverse;rp=[ [ring[(start-k)%n] for k in range(n)] for ring in rp]
        else:rp=[ [ring[(start+k)%n] for k in range(n)] for ring in rp]
        # Connect a variable-size hole to an n-vertex sleeve with a
        # triangulated, arc-length zipper and a halfway transition ring.
        sampled=sample_loop(bp,n)
        mid=[a.lerp(b,.50) for a,b in zip(sampled,rp[0])]
        mid_ids=add_ring(mid)
        # zipper: each boundary vertex joins its two nearest mid samples;
        # progress monotonically around both loops to prevent crossing.
        nb=len(boundary)
        i=j=0
        while i<nb or j<n:
            ai=boundary[i%nb];bj=mid_ids[j%n]
            if i==nb:
                faces.append((ai,bj,mid_ids[(j+1)%n]));j+=1
            elif j==n:
                faces.append((ai,boundary[(i+1)%nb],bj));i+=1
            elif (i+1)/nb < (j+1)/n:
                faces.append((ai,boundary[(i+1)%nb],bj));i+=1
            else:
                faces.append((ai,bj,mid_ids[(j+1)%n]));j+=1
        previous=mid_ids
        for idx,ring in enumerate(rp):
            current=add_ring(ring)
            join(previous,current)
            previous=current
    # No caps: neck, hem and cuffs are genuine boundary loops.
    mesh=bpy.data.meshes.new('NWCS_Connected_Cloth_Cage')
    mesh.from_pydata(verts,[],faces);mesh.update()
    obj=bpy.data.objects.new('NWCS_Garment',mesh)
    context.scene.collection.objects.link(obj)
    for selected in context.selected_objects:selected.select_set(False)
    obj.select_set(True);context.view_layer.objects.active=obj
    import bmesh
    bm=bmesh.new();bm.from_mesh(mesh)
    bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
    bm.to_mesh(mesh);bm.free();mesh.update()
    nwcs_repair_cloth_cage(obj)
    try:
        nwcs_validate_cloth_cage(obj,p.preset)
    except ValueError as exc:
        bpy.data.objects.remove(obj,do_unlink=True)
        operator.report({'ERROR'},str(exc));return {'CANCELLED'}
    if p.preset=='CARDIGAN':
        # Open front on the completed sweater mesh, retaining the original
        # shoulder joins and sleeve geometry. Front of avatar is negative Y.
        import bmesh
        bm=bmesh.new();bm.from_mesh(obj.data)
        zlo,zhi,mid_x,mid_y=body_bounds(p.reference_body)
        height=zhi-zlo
        half_width=height*(.008+.00030*p.cardigan_opening)
        to_cut=[]
        for face in bm.faces:
            center=face.calc_center_median()
            if center.y>=mid_y or abs(center.x-mid_x)>half_width:continue
            if center.z<zlo+height*(p.cardigan_hem-.025) or center.z>zlo+height*.935:continue
            to_cut.append(face)
        if not to_cut:
            bm.free()
            bpy.data.objects.remove(obj,do_unlink=True)
            operator.report({'ERROR'},'Could not cut cardigan front; adjust torso rings')
            return {'CANCELLED'}
        bmesh.ops.delete(bm,geom=to_cut,context='FACES')
        # Remove loose vertices created by the opening cut.
        loose=[v for v in bm.verts if not v.link_faces]
        if loose:bmesh.ops.delete(bm,geom=loose,context='VERTS')
        bm.to_mesh(obj.data);bm.free();obj.data.update()
        obj['nwcs_open_front']=True
    for old in list(context.scene.objects):
        if old!=obj and old.get('nwcs_sim_ready') and not old.get('nwcs_frozen'):
            bpy.data.objects.remove(old,do_unlink=True)
    for f in obj.data.polygons:f.use_smooth=True
    # Never Catmull-Clark subdivide the raw boolean mesh. The irregular
    # shoulder n-gons generate enormous spikes and collapsed neck surfaces.
    # Preserve the unmodified joined cage for cloth simulation.
    # Do not invoke Blender's UV solver on boolean-joined sleeve topology
    # during garment creation. Native solver crashes cannot be caught by Python.
    nwcs_safe_initial_uv(obj)
    group=obj.vertex_groups.new(name='NWCS_Edge_Anchors')
    lo,hi,_,_=body_bounds(p.reference_body)
    neck_z=sum(Vector(v).z for v in ring_points(torso[-1]))/n
    # Support only the neckline edge with a soft constraint. This is a
    # boundary restraint, not a replacement for proper neckline geometry.
    # Boolean sleeve intersection vertices remain free to settle.
    neck_center=sum(rows[-1],Vector())/n
    neck_limit=max((v-neck_center).length for v in rows[-1])*1.12
    rim=[]
    for v in obj.data.vertices:
        if abs(v.co.z-neck_center.z)<height*.04 and (v.co-neck_center).length<neck_limit:
            rim.append(v.index)
    if rim and p.neckline_hold>0:
        group.add(rim,min(.35,p.neckline_hold),'REPLACE')
    if p.body_protection:
        nwcs_fit_garment_outside_body(context,obj,p.reference_body,p.body_min_gap)
    cloth=obj.modifiers.new('NWCS Cloth','CLOTH')
    cloth.settings.vertex_group_mass=group.name;cloth.settings.quality=11
    presets={'COTTON':(.22,18,12,1.5,1),'SILK':(.10,7,5,.25,.4),'DENIM':(.40,38,28,6,1.8),'LEATHER':(.48,55,40,10,2.5)}
    mass,stretch,shear,bend,air=presets[p.fabric]
    drape={'SOFT':(.75,.28,.25),'MEDIUM':(1.0,.58,.60),'STRUCTURED':(1.15,1.0,1.05)}[p.fabric_drape]
    cloth.settings.mass=mass*drape[0]
    cloth.settings.tension_stiffness=stretch*drape[1]*.70
    cloth.settings.compression_stiffness=stretch*drape[1]*.70
    cloth.settings.shear_stiffness=shear*drape[1]*.75
    cloth.settings.bending_stiffness=bend*drape[2]*.45
    cloth.settings.air_damping=air*.35
    cloth.collision_settings.use_self_collision=False;cloth.collision_settings.distance_min=.004
    nwcs_stable_upper_cloth(cloth, p.fabric, p.fabric_drape)
    obj['nwcs_preset'] = p.preset
    nwcs_solver_stability_profile(obj,cloth,p)
    nwcs_configure_collision_environment(context,obj,cloth,p.reference_body)
    cloth.point_cache.frame_start=1;cloth.point_cache.frame_end=p.sim_frames
    # Subdivision is visual-only and follows cloth so the simulator still
    # uses the stable original cage.  Solidify remains the final modifier.
    rounding=obj.modifiers.new('NWCS Sweater Surface Smoothing','SUBSURF')
    rounding.levels=1;rounding.render_levels=2
    nwcs_add_fabric_thickness(obj,p.fabric_thickness)
    obj['nwcs_generated']=True;obj['nwcs_sim_ready']=True;obj['nwcs_connected_sleeves']=True
    obj['nwcs_torso_rows']=0;obj['nwcs_segments']=n
    body=p.reference_body
    if body and not any(m.type=='COLLISION' for m in body.modifiers):body.modifiers.new('NWCS Body Collision','COLLISION')
    context.scene.frame_start=1;context.scene.frame_end=p.sim_frames;context.scene.frame_set(1)
    coll=bpy.data.collections.get('NWCS Control Rings')
    if coll:
        for r in coll.objects:r.hide_set(True);r.hide_render=True
    nwcs_finish_garment_transform(context,obj)
    # UV refinement is explicit; never call native unwrap while constructing cloth.
    # A stable initial UV map has already been assigned above.
    nwcs_discard_control_rings()
    for selected in list(context.selected_objects):selected.select_set(False)
    obj.select_set(True);context.view_layer.objects.active=obj
    operator.report({'INFO'},'Sweater built with cloth; control rings removed. Press Play to simulate.')
    return {'FINISHED'}

def nwcs_add_fabric_thickness(obj, thickness):
    """Keep Cloth on a single surface; create inside/outside only downstream."""
    if not obj or obj.type != 'MESH': return
    mod = obj.modifiers.get('NWCS Fabric Thickness')
    if mod is None: mod = obj.modifiers.new('NWCS Fabric Thickness', 'SOLIDIFY')
    mod.thickness = thickness
    # Outer offset avoids consuming the body's pre-simulation clearance.
    mod.offset = 1.0
    mod.use_rim = True
    mod.use_even_offset = True
    mod.show_viewport = True
    mod.show_render = True
    # Solidify must evaluate after Cloth and after any smoothing modifier.
    # All generators add it as their final modifier.

def nwcs_center_generated_origin(obj):
    """Center mesh object's origin at geometry bounding-box center in world space."""
    if not obj or obj.type!='MESH' or not obj.data.vertices:return
    from mathutils import Vector
    lo=Vector((min(v.co.x for v in obj.data.vertices),min(v.co.y for v in obj.data.vertices),min(v.co.z for v in obj.data.vertices)))
    hi=Vector((max(v.co.x for v in obj.data.vertices),max(v.co.y for v in obj.data.vertices),max(v.co.z for v in obj.data.vertices)))
    center=(lo+hi)*.5
    for v in obj.data.vertices:v.co-=center
    obj.location += obj.matrix_world.to_3x3() @ center
    obj.data.update()

def nwcs_finish_garment_transform(context, obj):
    """Put the Move gizmo at the new garment's geometric center, not at world zero.

    Keep world-space vertex positions unchanged. Select the garment so Blender
    displays its transform arrows at the corrected object origin.
    """
    if obj is None or obj.type != 'MESH':
        return
    nwcs_center_generated_origin(obj)
    if context.object and context.object.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    for selected in list(context.selected_objects):
        selected.select_set(False)
    obj.hide_set(False)
    obj.select_set(True)
    context.view_layer.objects.active = obj
    context.view_layer.update()
    activate_move(context)


def nwcs_discard_control_rings():
    coll=bpy.data.collections.get('NWCS Control Rings')
    if coll:
        for ring in list(coll.objects):bpy.data.objects.remove(ring,do_unlink=True)
        if not coll.objects:bpy.data.collections.remove(coll)
    for ring in list(bpy.data.objects):
        if ring.get('nwcs_ring'):bpy.data.objects.remove(ring,do_unlink=True)
    _nwcs_mirror_state.clear()

# Track transforms across gizmo operations; retain the last known state of each guide.
_nwcs_mirror_state={}
_nwcs_mirror_busy=False

def nwcs_sync_mirror_baseline():
    coll=bpy.data.collections.get('NWCS Control Rings')
    _nwcs_mirror_state.clear()
    if coll:
        for ob in coll.objects:
            if ob.get('nwcs_ring'):
                _nwcs_mirror_state[ob.name]=tuple(round(float(v),7) for row in ob.matrix_world for v in row)

@persistent
def nwcs_mirror_ring_handler(scene,depsgraph):
    global _nwcs_mirror_busy
    if _nwcs_mirror_busy or not hasattr(scene,'nwcs_props'):return
    p=scene.nwcs_props
    if not (p.mirror_legs or p.mirror_sleeves):return
    coll=bpy.data.collections.get('NWCS Control Rings')
    if not coll:return
    rings={o.name:o for o in coll.objects if o.get('nwcs_ring')}
    current={name:tuple(round(float(v),7) for row in ob.matrix_world for v in row) for name,ob in rings.items()}
    if not _nwcs_mirror_state:
        _nwcs_mirror_state.update(current);return
    changed={name for name,mat in current.items() if name in _nwcs_mirror_state and mat!=_nwcs_mirror_state[name]}
    if not changed:
        _nwcs_mirror_state.clear();_nwcs_mirror_state.update(current);return
    z0,z1,cx,cy=body_bounds(p.reference_body) if p.reference_body else (0,0,0,0)
    reflect=Matrix(((-1,0,0,2*cx),(0,1,0,0),(0,0,1,0),(0,0,0,1)))
    active=bpy.context.view_layer.objects.active if bpy.context.view_layer else None
    # When both guides are reported as changed, the selected guide is the source.
    sources=sorted(changed,key=lambda name: 0 if active and name==active.name else 1)
    _nwcs_mirror_busy=True
    try:
        handled=set()
        for name in sources:
            if name in handled or not (name.startswith(PREFIX+'L_') or name.startswith(PREFIX+'R_')):continue
            suffix=name[len(PREFIX)+2:]
            sleeve=suffix in {'Shoulder','Elbow','Wrist'}
            if (sleeve and not p.mirror_sleeves) or (not sleeve and not p.mirror_legs):continue
            other=PREFIX+('R_' if name.startswith(PREFIX+'L_') else 'L_')+suffix
            if other not in rings:continue
            # Never overwrite a deliberately selected opposite guide.
            if other in changed and active and active.name==other:continue
            src=rings[name];dst=rings[other]
            dst.matrix_world=reflect @ src.matrix_world @ reflect
            dst.update_tag(refresh={'OBJECT'})
            handled.add(other)
    finally:
        nwcs_sync_mirror_baseline()
        _nwcs_mirror_busy=False

def nwcs_apply_stiffness(obj, cloth, percent):
    """Adjust stiffness while keeping baseline on the mesh object, not modifier."""
    scale = .30 + 1.70 * (max(0., min(100., float(percent))) / 100.)
    st = cloth.settings
    for field in ('tension_stiffness', 'compression_stiffness', 'shear_stiffness', 'bending_stiffness'):
        key = 'nwcs_base_' + field
        base = obj.get(key)
        if base is None:
            base = float(getattr(st, field))
            obj[key] = base
        setattr(st, field, max(.01, float(base) * scale))


def nwcs_add_prefit(obj, body, props, n, torso_rows):
    """Bounded rest-mesh fitting; never leave a live Shrinkwrap before Cloth.

    Nearest-surface shrinkwrap can snap neck vertices to distant triangles
    (shoulders, breasts, arms), producing the giant spikes at frame 1.
    This pre-fit moves only nearby vertices, by at most a small fraction of
    their local mesh edge length. The cloth cage is never subdivided here.
    """
    if not props.prefit_shrinkwrap or not body or body.type != 'MESH' or body == obj:
        return
    from mathutils.bvhtree import BVHTree
    depsgraph = bpy.context.evaluated_depsgraph_get()
    try:
        bvh = BVHTree.FromObject(body, depsgraph, epsilon=0.0)
    except Exception as exc:
        obj['nwcs_prefit_status'] = 'Skipped: avatar surface unavailable: ' + str(exc)[:120]
        return
    if bvh is None:
        obj['nwcs_prefit_status'] = 'Skipped: avatar has no BVH surface'
        return
    world_to_body = body.matrix_world.inverted_safe()
    body_to_world = body.matrix_world
    world_to_obj = obj.matrix_world.inverted_safe()
    obj_to_world = obj.matrix_world
    mesh = obj.data
    neighbors = [[] for _ in mesh.vertices]
    for edge in mesh.edges:
        i,j = edge.vertices
        d = (mesh.vertices[i].co - mesh.vertices[j].co).length
        if d > 1e-7:
            neighbors[i].append(d)
            neighbors[j].append(d)
    upper = props.preset in {'TANK','SLEEVELESS','TSHIRT','SWEATER','DRESS'}
    band = 3 if upper else 2
    weights = (0.45, 0.25, 0.10) if upper else (0.40, 0.15)
    proposals = {}
    for dist in range(min(band,torso_rows)):
        row = torso_rows-1-dist
        for idx in range(row*n, min((row+1)*n, len(mesh.vertices))):
            if not neighbors[idx]:
                continue
            vertex = mesh.vertices[idx]
            world = obj_to_world @ vertex.co
            local_body = world_to_body @ world
            found = bvh.find_nearest(local_body)
            if found is None or found[0] is None:
                continue
            nearest, normal, _, _ = found
            if normal is None or normal.length < 1e-8:
                continue
            target_world = body_to_world @ (nearest + normal.normalized()*props.prefit_offset)
            delta_local = (world_to_obj @ target_world) - vertex.co
            # Reject distant/ambiguous surface matches outright. Never pull
            # across a shoulder, armpit or the opposite side of the avatar.
            local_edge = min(neighbors[idx])
            cap = min(0.008, local_edge*0.18)
            if delta_local.length > cap or delta_local.length < 1e-8:
                continue
            proposals[idx] = delta_local * weights[dist]
    for idx, delta in proposals.items():
        mesh.vertices[idx].co += delta
    mesh.update()
    obj['nwcs_prefit_status'] = f'Bounded pre-fit: {len(proposals)} vertices (no live modifier)'


def nwcs_configure_collision_environment(context, garment, cloth, body):
    """Isolate collision to the intended avatar and clamp solver impulses.

    Prevents unrelated scene collision objects from violently repelling a
    garment. Keep the physics cage single-layer; no cloth-side Solidify.
    """
    co = cloth.collision_settings
    co.use_collision = bool(body and body.type == 'MESH')
    co.use_self_collision = False
    if hasattr(co, 'impulse_clamp'):
        co.impulse_clamp = 2.0
    if hasattr(co, 'self_impulse_clamp'):
        co.self_impulse_clamp = 2.0
    if not body or body.type != 'MESH':
        return
    if not any(m.type == 'COLLISION' for m in body.modifiers):
        body.modifiers.new('NWCS Body Collision', 'COLLISION')
    body.collision.use = True
    body.collision.thickness_outer = 0.001
    body.collision.cloth_friction = 3.0
    name = 'NWCS Collider - ' + str(body.name)
    collection = bpy.data.collections.get(name)
    if collection is None:
        collection = bpy.data.collections.new(name)
        context.scene.collection.children.link(collection)
    if body.name not in collection.objects:
        collection.objects.link(body)
    if hasattr(co, 'collection'):
        co.collection = collection
    garment['nwcs_collision_body'] = body.name


def nwcs_solver_stability_profile(obj, cloth, props):
    """Per-garment profiles derived from Divine Cut 4.0.8 reference values.

    Avoid copying Divine Cut's pressure/shrink setup: our generated cloth cages
    have different pressure groups and open boundaries.
    """
    kind = obj.get('nwcs_preset', '') or getattr(props, 'preset', 'TANK')
    # mass, tension, compression, shear, bend, cloth gap, self gap
    profiles = {
        'TANK': (.1, 10, 10, 10, 3, .001, .001),
        'TSHIRT': (.1, 10, 10, 10, 3, .001, .001),
        'SWEATER': (.5, 3, 10, 3, 3, .001, .0025),
        'CARDIGAN': (.5, 3, 10, 3, 3, .001, .0025),
        'MINI': (.1, 5, 5, 5, 3, .002, .0025),
        'LONG': (.1, 5, 5, 5, 3, .002, .0025),
        'DRESS': (.1, 5, 5, 5, 3, .002, .0025),
        'PANTS': (.5, 3, 10, 3, 3, .001, .0025),
        'BOXER_BRIEFS': (.5, 3, 10, 3, 3, .001, .0025),
        'BOXER_SHORTS': (.5, 3, 10, 3, 3, .001, .0025),
    }
    mass, tension, compression, shear, bend, gap, self_gap = profiles.get(kind, profiles['TANK'])
    st, co = cloth.settings, cloth.collision_settings
    st.quality = 21
    st.mass = mass * getattr(props, 'fabric_weight', 1.0)
    st.tension_stiffness = tension
    st.compression_stiffness = compression
    st.shear_stiffness = shear
    st.bending_stiffness = bend
    st.tension_damping = 10
    st.compression_damping = 10
    st.shear_damping = 10
    st.pin_stiffness = .1
    st.use_pressure = False
    co.use_collision = True
    # Divine Cut enables self-collision, but ours can start with intersecting
    # fabric; avoid the resulting solver impulses until cage is guaranteed clean.
    co.use_self_collision = False
    co.collision_quality = 5
    co.distance_min = gap
    co.self_distance_min = self_gap
    co.friction = 2
    obj['nwcs_solver_profile'] = 'Divine Cut-inspired '+kind


def nwcs_stable_upper_cloth(cloth, fabric, drape='MEDIUM'):
    """Conservative solver profile for tops and dresses; no neckline pins."""
    mass, stretch, shear, bend, air = {
        'COTTON': (.22, 18., 12., 1.5, 1.),
        'SILK': (.10, 7., 5., .25, .4),
        'DENIM': (.40, 38., 28., 6., 1.8),
        'LEATHER': (.48, 55., 40., 10., 2.5),
    }[fabric]
    scale = {'SOFT': .55, 'MEDIUM': .75, 'STRUCTURED': 1.0}.get(drape, .75)
    st = cloth.settings
    st.quality = 16
    st.mass = mass
    st.tension_stiffness = stretch * scale * .65
    st.compression_stiffness = stretch * scale * .55
    st.shear_stiffness = shear * scale * .60
    st.bending_stiffness = bend * scale * .30
    st.air_damping = max(.5, air * .5)
    st.tension_damping = 5.0
    st.compression_damping = 5.0
    st.shear_damping = 5.0
    st.bending_damping = .5
    co = cloth.collision_settings
    co.use_collision = True
    co.use_self_collision = False
    co.collision_quality = 12
    co.distance_min = .003
    co.friction = 2.0

def nwcs_repair_cloth_cage(obj):
    """Remove face-unused vertices (including wire edges), then triangulate folded quads.

    A vertex attached only to a wire edge is still unused by cloth. Previous
    repair only removed vertices with zero edges, leaving the 12 reported
    'isolated vertices' untouched. Do not delete boundary vertices with faces.
    """
    import bmesh
    bm=bmesh.new()
    try:
        bm.from_mesh(obj.data)
        # Face-unused includes wire-only vertices and loose edges.
        unused=[v for v in bm.verts if not v.link_faces]
        unused_count=len(unused)
        if unused:
            bmesh.ops.delete(bm, geom=unused, context='VERTS')
        folded=[]
        for f in bm.faces:
            if len(f.verts)!=4:
                continue
            p=[v.co for v in f.verts]
            a=(p[1]-p[0]).cross(p[2]-p[0])
            b=(p[2]-p[0]).cross(p[3]-p[0])
            if a.length>1e-12 and b.length>1e-12 and a.dot(b)<-0.01*a.length*b.length:
                folded.append(f)
        folded_count=len(folded)
        if folded:
            bmesh.ops.triangulate(bm,faces=folded,quad_method='BEAUTY',ngon_method='BEAUTY')
        if unused_count or folded_count:
            bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
            bm.to_mesh(obj.data)
            obj.data.update()
        return unused_count,folded_count
    finally:
        bm.free()


def nwcs_relax_boxer_edge_outliers(obj):
    """Correct boxer crotch edge outliers before cloth, without topology edits.

    Match the existing validator's definition exactly. Restrict displacement
    to an average of connected neighbors and exclude upper waistband vertices.
    """
    from mathutils import Vector
    mesh=obj.data
    if not mesh.vertices or not mesh.edges:
        return 0
    neighbors=[set() for _ in mesh.vertices]
    for edge in mesh.edges:
        a,b=edge.vertices
        neighbors[a].add(b)
        neighbors[b].add(a)
    zmax=max(v.co.z for v in mesh.vertices)
    zmin=min(v.co.z for v in mesh.vertices)
    fixed=0
    for _ in range(4):
        coords=[v.co.copy() for v in mesh.vertices]
        replacements={}
        for i, adjacent in enumerate(neighbors):
            if len(adjacent)<3 or coords[i].z>zmin+(zmax-zmin)*.78:
                continue
            lengths=sorted((coords[i]-coords[j]).length for j in adjacent)
            baseline=lengths[0]
            if baseline<1e-7:
                continue
            long_edges=sum(d>max(baseline*12,baseline+.025) for d in lengths)
            if long_edges<3 or long_edges<len(lengths)-1:
                continue
            # A trimmed neighbor average avoids pulling the vertex across the
            # crotch opening when an opposite-side neighbor is far away.
            close=sorted(adjacent,key=lambda j:(coords[j]-coords[i]).length)
            keep=close[:max(2,len(close)//2)]
            target=sum((coords[j] for j in keep),Vector())/len(keep)
            replacements[i]=coords[i].lerp(target,.65)
        if not replacements:
            break
        for i,co in replacements.items():
            mesh.vertices[i].co=co
        fixed+=len(replacements)
        mesh.update()
    return fixed


def nwcs_validate_cloth_cage(obj, label='Garment'):
    """Reject malformed cloth faces and extreme local edge outliers.

    Do not reject long thin but regular strips: compare edges with their local
    one-ring neighbors instead of imposing a global aspect-ratio threshold.
    """
    from collections import Counter
    mesh=obj.data
    counts=Counter()
    bad_faces=0
    used=set()
    for face in mesh.polygons:
        indices=list(face.vertices)
        used.update(indices)
        if len(indices)<3 or len(set(indices))!=len(indices) or face.area<1e-10:
            bad_faces+=1
        for key in face.edge_keys:
            counts[tuple(sorted(key))]+=1
    nonmanifold=sum(c>2 for c in counts.values())
    # The cloth solver is especially sensitive to near-zero-area triangles
    # created by Boolean sleeve joins, even if no vertex is an edge outlier.
    # Evaluate in local mesh units; compare each triangle to its own edge scale.
    sliver_faces=0
    inverted_quads=0
    for face in mesh.polygons:
        ids=list(face.vertices)
        if len(ids)<3:continue
        points=[mesh.vertices[i].co for i in ids]
        lengths=[(points[i]-points[(i+1)%len(points)]).length for i in range(len(points))]
        if min(lengths)<1e-7:
            sliver_faces+=1
            continue
        longest=max(lengths)
        if face.area/(longest*longest)<0.0005:
            sliver_faces+=1
        if len(points)==4:
            # A quad whose two constituent triangles face opposite directions
            # is folded or bow-tied, and is unsafe for cloth constraints.
            a=(points[1]-points[0]).cross(points[2]-points[0])
            b=(points[2]-points[0]).cross(points[3]-points[0])
            if a.length>1e-12 and b.length>1e-12 and a.dot(b)<-0.01*a.length*b.length:
                inverted_quads+=1
    unused=len(mesh.vertices)-len(used)
    # Edge outliers can indicate one vertex shot away from an otherwise
    # regular mesh. Require at least three incident edges to avoid false
    # positives at legitimate garment boundaries.
    neighbors=[[] for _ in mesh.vertices]
    for edge in mesh.edges:
        a,b=edge.vertices
        length=(mesh.vertices[a].co-mesh.vertices[b].co).length
        neighbors[a].append(length)
        neighbors[b].append(length)
    # A genuine spike tip is connected to several unusually long edges.
    # Boolean intersections create irregular triangles with ONE long edge,
    # which must not be mistaken for an extruded spike vertex.
    spike_vertices=0
    for incident in neighbors:
        if len(incident)<3:continue
        lengths=sorted(incident)
        baseline=lengths[0]
        if baseline<1e-7:continue
        long_edges=sum(length>max(baseline*12,baseline+.025) for length in lengths)
        if long_edges>=3 and long_edges>=len(lengths)-1:
            spike_vertices+=1
    if bad_faces or nonmanifold or unused or spike_vertices or sliver_faces or inverted_quads:
        raise ValueError(
            f'{label}: unsafe cloth cage: {bad_faces} collapsed faces, '
            f'{nonmanifold} non-manifold edges, {unused} isolated vertices, '
            f'{spike_vertices} extreme edge outliers, {sliver_faces} needle faces, '
            f'{inverted_quads} folded quads. Simulation was not started.'
        )
    return True



class NWCS_OT_conform_waist_any(bpy.types.Operator):
    """Fit only the waistband of a finished garment to the reference body."""
    bl_idname='nwcs.conform_waist_any'
    bl_label='Shrinkwrap Waist to Body'
    bl_options={'REGISTER','UNDO'}

    def execute(self,context):
        p=context.scene.nwcs_props
        body=p.reference_body
        if body is None or body.type!='MESH':
            self.report({'ERROR'},'Select a mesh Reference Body')
            return {'CANCELLED'}
        garment=context.active_object
        if garment is None or garment==body or garment.type!='MESH' or not (garment.get('nwcs_generated') or garment.get('nwcs_sim_ready') or garment.name.startswith('NWCS ')):
            self.report({'ERROR'},'Select the finished garment mesh before applying waist conform')
            return {'CANCELLED'}
        if p.preset not in {'MINI','LONG','PANTS','BOXER_BRIEFS','BOXER_SHORTS','BIKINI'}:
            self.report({'ERROR'},'Waist conform is for skirts, pants, boxers and bikini panties')
            return {'CANCELLED'}
        if garment.mode!='OBJECT':
            self.report({'ERROR'},'Switch to Object Mode first')
            return {'CANCELLED'}
        cloth=next((m for m in garment.modifiers if m.type=='CLOTH'),None)
        if cloth and cloth.point_cache.is_baked:
            self.report({'ERROR'},'Free the cloth cache before fitting the waistband')
            return {'CANCELLED'}
        # Detect the waistband by its upper edge in world space, rather than
        # relying on row indices that differ between pants and fitted meshes.
        from mathutils import Vector
        coords=[garment.matrix_world@v.co for v in garment.data.vertices]
        if not coords:
            self.report({'ERROR'},'Garment has no vertices')
            return {'CANCELLED'}
        zmax=max(v.z for v in coords)
        zmin=min(v.z for v in coords)
        body_world=[body.matrix_world@v.co for v in body.data.vertices]
        body_height=max(v.z for v in body_world)-min(v.z for v in body_world)
        band=max(body_height*.014,(zmax-zmin)*.035)
        candidates=[i for i,v in enumerate(coords) if zmax-v.z<=band]
        if len(candidates)<4:
            self.report({'ERROR'},'Unable to identify waistband vertices')
            return {'CANCELLED'}
        old=garment.vertex_groups.get('NWCS_Waist_Conform')
        if old:garment.vertex_groups.remove(old)
        group=garment.vertex_groups.new(name='NWCS_Waist_Conform')
        for i in candidates:
            weight=max(.05,1.-(zmax-coords[i].z)/band)
            group.add([i],weight,'REPLACE')
        sw=garment.modifiers.new('NWCS Waist Fit','SHRINKWRAP')
        sw.target=body
        sw.wrap_method='NEAREST_SURFACEPOINT'
        sw.offset=p.conform_clearance
        sw.vertex_group=group.name
        # Apply on the base mesh before cloth or subdivision; do not apply
        # or discard any of the existing garment modifiers.
        try:
            while garment.modifiers[0]!=sw:
                bpy.ops.object.modifier_move_up(modifier=sw.name)
            bpy.ops.object.modifier_apply(modifier=sw.name)
            context.scene.frame_set(1)
        except Exception as exc:
            if garment.modifiers.get(sw.name):garment.modifiers.remove(sw)
            self.report({'ERROR'},'Waist conform failed: '+str(exc))
            return {'CANCELLED'}
        self.report({'INFO'},'Waist fitted to avatar; legs and lower garment unchanged')
        return {'FINISHED'}

class NWCS_OT_corset_gentle_fit(bpy.types.Operator):
    """After building, gently conform corset upper sides and back without touching bust/laces."""
    bl_idname='nwcs.corset_gentle_fit'
    bl_label='Gentle Corset Side Fit'
    bl_options={'REGISTER','UNDO'}

    def execute(self,context):
        p=context.scene.nwcs_props
        body=p.reference_body
        garment=context.active_object
        if not body or body.type!='MESH' or not garment or garment.type!='MESH' or garment==body or not garment.name.startswith('NWCS V-Front Laced Corset'):
            self.report({'ERROR'},'Select the generated corset and a mesh Reference Body')
            return {'CANCELLED'}
        if garment.mode!='OBJECT':
            self.report({'ERROR'},'Switch to Object Mode first')
            return {'CANCELLED'}
        from mathutils.bvhtree import BVHTree
        # Build the search surface in world coordinates, so transformed bodies work.
        depsgraph=context.evaluated_depsgraph_get()
        eval_body=body.evaluated_get(depsgraph)
        bm=eval_body.to_mesh()
        try:
            world_vertices=[tuple(eval_body.matrix_world@v.co) for v in bm.vertices]
            faces=[tuple(poly.vertices) for poly in bm.polygons]
            if not faces:
                self.report({'ERROR'},'Reference body has no surface faces')
                return {'CANCELLED'}
            bvh=BVHTree.FromPolygons(world_vertices,faces,all_triangles=False)
            bmin=min(v[2] for v in world_vertices);bmax=max(v[2] for v in world_vertices)
            # Torso center estimated from the corset waist, not arm-contaminated bust.
            coords=[garment.matrix_world@v.co for v in garment.data.vertices]
            zmin=min(v.z for v in coords);zmax=max(v.z for v in coords)
            height=max(1e-5,zmax-zmin)
            waist=[v for v in coords if .35<(v.z-zmin)/height<.58]
            if not waist: waist=coords
            center_y=(min(v.y for v in waist)+max(v.y for v in waist))*.5
            center_x=(min(v.x for v in waist)+max(v.x for v in waist))*.5
            side_radius=max(.025,max(abs(v.x-center_x) for v in waist))
            inv=garment.matrix_world.inverted_safe()
            changed=0
            for vertex,world in zip(garment.data.vertices,coords):
                t=(world.z-zmin)/height
                if t<.52: continue
                # Front breast panels and center-front lacing are intentionally excluded.
                # Back and underarm side panels only; soft blend at the boundaries.
                lateral=abs(world.x-center_x)/side_radius
                back=(world.y-center_y)/max(side_radius,.025)
                if back<-.12 or (back<.15 and lateral<.78):continue
                side_weight=min(1.,max(0.,(lateral-.68)/.28))
                back_weight=min(1.,max(0.,(back+.12)/.35))
                region=max(side_weight,back_weight)
                if region<=0:continue
                upper=min(1.,max(0.,(t-.52)/.22))
                result=bvh.find_nearest(world, .045)
                if not result or result[0] is None:continue
                hit,normal,face,distance=result
                if distance>.045:continue
                # The nearest face may be an arm. Reject large pulls and only
                # move vertices inward towards the body, never out to an arm.
                displacement=hit-world
                radial=Vector((world.x-center_x,world.y-center_y,0))
                if radial.length<1e-6:continue
                radial.normalize()
                inward=displacement.dot(radial)
                if inward>=-.0005:continue
                pull=min(-inward,.012)*p.corset_post_fit*region*upper
                if pull<1e-6:continue
                new_world=world-radial*pull
                vertex.co=inv@new_world
                changed+=1
            garment.data.update()
            self.report({'INFO'},f'Gentle corset fit: {changed} side/back vertices adjusted; bust and lacing preserved')
            return {'FINISHED'}
        finally:
            eval_body.to_mesh_clear()

def nwcs_flounce_hem(verts, p, waist_z, hem_z):
    """Generate a smooth hem flounce using tapered flare and low-frequency waves.

    The flare is gradual, preserving the upper cloth cage and keeping neighboring
    vertices continuous. It is geometry, not a displacement shader.
    """
    if p.ruffle_style == 'NONE' or waist_z <= hem_z + 1e-5:
        return verts
    height = waist_z - hem_z
    band = max(height * p.ruffle_height, 1e-5)
    bottom = [v for v in verts if v[2] <= hem_z + band]
    if not bottom:return verts
    cx = sum(v[0] for v in bottom) / len(bottom)
    cy = sum(v[1] for v in bottom) / len(bottom)
    # Keep the frequency below the mesh sampling limit; the user-facing
    # wave count remains honored on normal-density cages.
    count = max(3, min(int(p.ruffle_count), 12))
    # A flounce requires a visibly wider hem, not just tiny radial ripples.
    flare = min(height * .24, max(p.ruffle_depth * (3.5 if p.ruffle_style == 'FULL' else 2.0), height * .055))
    wave_amp = flare * (.32 if p.ruffle_style == 'FULL' else .18)
    result=[]
    for x,y,z in verts:
        t = max(0.0,min(1.0,(hem_z + band-z)/band))
        # C2-continuous fade prevents a hard fold at the upper flounce edge.
        fade=t*t*t*(t*(t*6.0-15.0)+10.0)
        dx,dy=x-cx,y-cy
        radius=math.hypot(dx,dy)
        if radius<1e-8 or fade<=0.0:
            result.append((x,y,z));continue
        angle=math.atan2(dy,dx)
        outward=fade*(flare+wave_amp*math.cos(count*angle))
        result.append((x+dx/radius*outward,y+dy/radius*outward,z))
    return result

class NWCS_OT_build(bpy.types.Operator):
    bl_idname='nwcs.build_garment';bl_label='Build Garment from Rings';bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        if context.screen and context.screen.is_animation_playing:
            bpy.ops.screen.animation_cancel(restore_frame=False)
        p=context.scene.nwcs_props
        if p.body_protection:nwcs_protect_rings(context,p)
        if p.preset in {'BRA','CORSET','BIKINI'}:
            try:
                obj=nwcs_build_fitted(context,p)
                nwcs_discard_control_rings()
                self.report({'INFO'},'Created '+obj.name)
                return {'FINISHED'}
            except Exception as exc:
                self.report({'ERROR'},'Fitted garment build: '+str(exc))
                return {'CANCELLED'}
        if p.preset in {'PANTS','BOXER_BRIEFS','BOXER_SHORTS'}:
            try:
                return build_connected_pants(context,p,self)
            except Exception as exc:
                self.report({'ERROR'},f'Pants build stopped: {type(exc).__name__}: {exc}')
                return {'CANCELLED'}
        if p.preset in {'SWEATER','TSHIRT','CARDIGAN'} or (p.preset=='DRESS' and p.dress_sleeves!='NONE'):
            try:
                return build_connected_sleeved(context,p,self)
            except Exception as exc:
                self.report({'ERROR'},f'Sweater build stopped: {type(exc).__name__}: {exc}')
                return {'CANCELLED'}
        parts=({'MINI':('Hem','Waist'),'LONG':('Hem','Waist'),'TANK':('Hem','Waist','Chest','Neck'),'PANTS':('Hip','Waist'),'DRESS':('Hem','Hip','Waist','Underbust','Bust','Neckline'),'SWEATER':('Hem','Waist','Bust','Neckline')})[p.preset]
        names=[PREFIX+x for x in parts]
        rings=[bpy.data.objects.get(n) for n in names]
        if any(o is None for o in rings):
            self.report({'ERROR'},'Create Control Rings first');return {'CANCELLED'}
        counts=[len(ring_points(o)) for o in rings]
        if len(set(counts))!=1:
            self.report({'ERROR'},'Ring vertex counts differ');return {'CANCELLED'}
        n=counts[0]
        is_skirt=p.preset in {'MINI','LONG'}
        # Build many fabric rows from the ring profiles, not just four stiff strips.
        # Ring order is hem -> waist, so topmost ring is anchored.
        # Choose skirt row count from the actual ring geometry.  The cloth
        # solver works best when vertical edges are comparable to the edges
        # around the circumference; a fixed 20 rows can make long, skinny
        # quads on long skirts and encourage vertical buckling.
        if is_skirt:
            low_profile = ring_points(rings[0])
            high_profile = ring_points(rings[-1])
            edge_lengths = [
                (Vector(low_profile[(i + 1) % n]) - Vector(low_profile[i])).length
                for i in range(n)
            ]
            edge_lengths += [
                (Vector(high_profile[(i + 1) % n]) - Vector(high_profile[i])).length
                for i in range(n)
            ]
            typical_edge = max(0.008, sum(edge_lengths) / len(edge_lengths))
            skirt_height = sum(
                (Vector(high_profile[i]) - Vector(low_profile[i])).length
                for i in range(n)
            ) / n
            sections = max(12, min(128, math.ceil(skirt_height / typical_edge)))
        else:
            sections = 20 if p.preset=='DRESS' else (14 if p.preset=='TANK' else 12 if p.preset=='SWEATER' else 8)
        verts=[];faces=[]
        guide_profiles=[ring_points(ring) for ring in rings]
        for j in range(len(rings)-1):
            low=ring_points(rings[j]);high=ring_points(rings[j+1])
            for step in range(sections):
                if j and step==0 and p.preset!='TANK':continue
                t=step/sections
                for i in range(n):
                    v=Vector(low[i]).lerp(Vector(high[i]),t)
                    if p.preset=='TANK':
                        previous=guide_profiles[max(0,j-1)][i]
                        following=guide_profiles[min(len(rings)-1,j+2)][i]
                        v=nwcs_tank_curve_point(Vector(previous),Vector(low[i]),Vector(high[i]),Vector(following),t)
                    if (is_skirt and p.pleat_style=='PLEATED') or (p.preset=='DRESS' and p.dress_pleats and j<2):
                        center=Vector((sum(q[0] for q in low)/n,sum(q[1] for q in low)/n,0))
                        radial=Vector((v.x-center.x,v.y-center.y,0))
                        if radial.length>1e-7:
                            angle=math.atan2(radial.y,radial.x)
                            # Fade pleats toward waistband (the final control ring).
                            height_fade=1.0-(j+t)/(len(rings)-1)
                            # Rounded pleat profile: soften radial peaks and
                            # ease the effect toward the waist, avoiding sharp
                            # triangular ridges in the fabric.
                            fade=height_fade*height_fade*(3.0-2.0*height_fade)
                            wave=math.cos(p.pleat_count*angle)
                            rounded=wave
                            v+=radial.normalized()*(p.pleat_depth*0.55*rounded*fade)
                    verts.append(tuple(v))
        last=ring_points(rings[-1])
        if p.preset in {'TANK','DRESS'}:
            # Reconstruct the final rows, preserving the guide ring exactly.
            allrows=[ [Vector(v) for v in verts[j:j+n]] for j in range(0,len(verts),n)]
            allrows.append([Vector(v) for v in last])
            nwcs_blend_neck_rows(allrows,n,body_bounds(p.reference_body)[1]-body_bounds(p.reference_body)[0])
            if p.preset=='TANK':allrows=nwcs_tank_body_clearance(context,allrows,p.reference_body,max(.022,p.body_min_gap))
            verts=[tuple(v) for row in allrows[:-1] for v in row]
            last=allrows[-1]
        for i in range(n):
            v=Vector(last[i])
            verts.append(tuple(v))
        if p.preset in {'MINI','LONG','DRESS'} and p.ruffle_style != 'NONE':
            waist_ring = rings[-1] if is_skirt else rings[2]
            waist_z = sum(Vector(v).z for v in ring_points(waist_ring))/n
            hem_z = sum(Vector(v).z for v in ring_points(rings[0]))/n
            verts = nwcs_flounce_hem(verts,p,waist_z,hem_z)
        torso_rows=len(verts)//n
        for j in range(torso_rows-1):
            for i in range(n):
                k=(i+1)%n
                # Tank armholes: remove side panels below the shoulder bridge.
                # Keep the uppermost two face rows intact so the front and back
                # remain joined across BOTH shoulders (rather than ending in
                # separate disconnected panels at the top boundary).
                if p.preset=='TANK':
                    arm_start=max(1,(len(rings)-2)*sections+max(2,sections//2))
                    shoulder_bridge_start=max(arm_start+1,torso_rows-3)
                    progress=(j-arm_start+.5)/max(1,shoulder_bridge_start-arm_start)
                    # Smaller rounded opening: narrow at both ends and widest
                    # at the middle, preserving a higher underarm and broad straps.
                    threshold=.985-.085*math.sin(math.pi*max(0.,min(1.,progress)))
                    angle=abs(math.cos(2*math.pi*(i+.5)/n))
                    if arm_start<=j<shoulder_bridge_start and angle>threshold:
                        continue
                faces.append((j*n+i,j*n+k,(j+1)*n+k,(j+1)*n+i))
        # For skirts the four torso rings are the complete skirt profile.
        # Pants prototype adds separate leg tubes; crotch junction still needs topology work.
        if p.preset=='PANTS':
            for side in ('L','R'):
                leg=[bpy.data.objects.get(PREFIX+side+'_'+part) for part in ('Ankle','Knee','Thigh')]
                if any(o is None for o in leg):continue
                base=len(verts)
                for o in leg:verts.extend(ring_points(o))
                for j in range(2):
                    for i in range(n):
                        k=(i+1)%n
                        faces.append((base+j*n+i,base+j*n+k,base+(j+1)*n+k,base+(j+1)*n+i))
        # Build independent sleeve tubes between shoulder, elbow, and wrist controls.
        for side in (('L','R') if p.preset in {'SWEATER','DRESS'} and (p.preset!='DRESS' or p.dress_sleeves!='NONE') else ()):
            arm=[bpy.data.objects.get(PREFIX+side+'_'+part) for part in ('Shoulder','UpperArm','Elbow','Wrist')]
            if any(o is None for o in arm):continue
            if any(len(ring_points(o))!=n for o in arm):continue
            base=len(verts)
            for o in arm:verts.extend(ring_points(o))
            for j in range(len(arm)-1):
                for i in range(n):
                    k=(i+1)%n
                    faces.append((base+j*n+i,base+j*n+k,base+(j+1)*n+k,base+(j+1)*n+i))
        # Remove unused side-wall vertices created by the open armhole cuts.
        # Keeps the cloth cage free of isolated points.
        if p.preset=='TANK':
            used=sorted({vi for face in faces for vi in face})
            remap={old:new for new,old in enumerate(used)}
            verts=[verts[old] for old in used]
            faces=[tuple(remap[vi] for vi in face) for face in faces]
            verts=nwcs_round_tank_armholes(verts,faces,n)
        # Validate the generated cage before replacing a previous garment.
        # This also avoids allowing malformed geometry into cloth simulation.
        trial=bpy.data.meshes.new('NWCS Validation Mesh')
        try:
            trial.from_pydata(verts,[],faces);trial.update()
            from types import SimpleNamespace
            nwcs_repair_cloth_cage(SimpleNamespace(data=trial))
            nwcs_validate_cloth_cage(SimpleNamespace(data=trial),p.preset)
        except ValueError as exc:
            self.report({'ERROR'},str(exc));return {'CANCELLED'}
        finally:
            bpy.data.meshes.remove(trial)
        # Replace the current working garment only; preserve finished garments.
        for previous in list(context.scene.objects):
            if previous.get('nwcs_sim_ready') and not previous.get('nwcs_frozen'):
                bpy.data.objects.remove(previous,do_unlink=True)
        mesh=bpy.data.meshes.new('NWCS_GarmentMesh');mesh.from_pydata(verts,[],faces);mesh.update()
        obj=bpy.data.objects.new('NWCS_Garment',mesh);context.scene.collection.objects.link(obj)
        obj['nwcs_generated']=True
        if p.preset=='TANK':obj['nwcs_uv_pattern_mode']='GARMENT'
        obj['nwcs_torso_rows']=torso_rows
        obj['nwcs_segments']=n
        obj['nwcs_vertical_sections']=sections
        # Pattern UV: U runs around the circumference, V runs hem-to-waist.
        # Separate UV at the back seam, even though the mesh vertices are welded.
        uv=mesh.uv_layers.new(name='NWCS_Pattern_UV')
        for poly in mesh.polygons:
            if poly.index >= (torso_rows-1)*n: continue
            row=poly.index//n
            segment=poly.index%n
            u0=segment/n;u1=(segment+1)/n
            v0=row/(torso_rows-1);v1=(row+1)/(torso_rows-1)
            for li,coords in zip(poly.loop_indices,((u0,v0),(u1,v0),(u1,v1),(u0,v1))):
                uv.data[li].uv=coords
        for poly in mesh.polygons:
            poly.use_smooth=True
        for ob in context.selected_objects:ob.select_set(False)
        obj.select_set(True);context.view_layer.objects.active=obj
        # Do not recenter the cage here. The former block referenced
        # `frozen.data` (which exists only in the Freeze operator), aborting
        # TANK, MINI, LONG and sleeveless DRESS builds before CLOTH was added.
        # nwcs_finish_garment_transform() handles the origin safely below.
        for area in context.screen.areas if context.screen else []:
            if area.type=='VIEW_3D':
                area.spaces.active.show_gizmo=True
                area.spaces.active.show_gizmo_object_translate=True
                area.spaces.active.show_gizmo_object_rotate=False
                area.spaces.active.show_gizmo_object_scale=False
        # Set up cloth in Blender 4.5; keep all physics operations before hiding rings.
        # The uppermost torso ring is the waistband on skirts and neckline on tops.
        pin=obj.vertex_groups.new(name='NWCS_Edge_Anchors')
        # Stabilize the waistband across several rows rather than anchoring a
        # single vertex row.  A one-row anchor creates a sharp hinge that lets
        # the cloth fold vertically and bunch up directly beneath the waist.
        # Weights taper smoothly down the skirt; the remaining rows drape freely.
        if is_skirt:
            band = min(5, torso_rows)
            for distance in range(band):
                row = torso_rows - 1 - distance
                weights = (1.0, 0.85, 0.55, 0.25, 0.08)
                weight = weights[distance] * p.pin_strength
                pin.add(list(range(row*n, (row+1)*n)), weight, 'REPLACE')
        else:
            # Gentle neckline shape stabilization, never a rigid folded collar.
            # Only the upper open boundary is supported; rest drapes naturally.
            if p.preset in {'TANK','SLEEVELESS','TSHIRT','SWEATER','DRESS'} and p.neckline_hold > 0:
                for distance, factor in enumerate((0.55, 0.25, 0.08)):
                    row=torso_rows-1-distance
                    if row>=0:
                        indices=[remap[i] for i in range(row*n,(row+1)*n) if i in remap] if p.preset=='TANK' else list(range(row*n,(row+1)*n))
                        pin.add(indices,min(0.55,p.neckline_hold)*factor,'REPLACE')
        if p.body_protection:
            nwcs_fit_garment_outside_body(context,obj,p.reference_body,p.body_min_gap)
        nwcs_add_prefit(obj,p.reference_body,p,n,torso_rows)
        nwcs_repair_cloth_cage(obj)
        try:
            nwcs_validate_cloth_cage(obj,p.preset+' post-fit')
        except ValueError as exc:
            bpy.data.objects.remove(obj,do_unlink=True)
            self.report({'ERROR'},str(exc))
            return {'CANCELLED'}
        cloth=obj.modifiers.new('NWCS Cloth','CLOTH')
        settings=cloth.settings
        settings.vertex_group_mass=pin.name
        settings.quality=11 if p.preset=='DRESS' else 9
        # Use valid cloth settings; invalid RNA fields previously interrupted setup.
        presets={
            'COTTON':(.22,18.0,12.0,1.5,1.0),
            'SILK':(.10,7.0,5.0,.25,.4),
            'DENIM':(.40,38.0,28.0,6.0,1.8),
            'LEATHER':(.48,55.0,40.0,10.0,2.5),
        }
        mass,stretch,shear,bend,air=presets[p.fabric]
        if p.preset=='DRESS':
            dm={'SOFT':(.8,.55,.22),'MEDIUM':(1.0,.75,.40),'STRUCTURED':(1.2,1.1,.9)}[p.fabric_drape]
            mass*=dm[0];stretch*=dm[1];shear*=dm[1];bend*=dm[2];air*=.35
        settings.mass=mass
        settings.tension_stiffness=stretch
        settings.compression_stiffness=stretch
        settings.shear_stiffness=shear
        settings.bending_stiffness=bend
        settings.air_damping=air
        # Pleated garments start correctly but can catch on the avatar or
        # compress vertically during the simulation. Self collision was already
        # disabled in v1.4.4; tune contact and resistance for pleats only.
        cloth.collision_settings.use_self_collision=False
        if is_skirt and p.pleat_style == 'PLEATED':
            settings.quality = 12
            settings.compression_stiffness = max(stretch * 2.0, 32.0)
            settings.bending_stiffness = max(bend * 2.0, 4.0)
            settings.bending_damping = 0.6
            # Keep cloth/body separation smaller than the pleat depth so
            # neighboring folds are less likely to snag against the body.
            cloth.collision_settings.distance_min = 0.003
            cloth.collision_settings.friction = 1.0
            cloth.collision_settings.collision_quality = 6
        else:
            cloth.collision_settings.distance_min=.008
        if p.preset in {'TANK','DRESS','SWEATER','TSHIRT'}:
            nwcs_stable_upper_cloth(cloth,p.fabric,p.fabric_drape if p.preset=='DRESS' else 'MEDIUM')
        if p.preset=='TSHIRT':
            # Boolean sleeve seams are locally irregular. Keep collision
            # separation very small and damp impulses at these junctions.
            st=cloth.settings
            st.quality=24
            st.mass=.28 if p.fabric=='COTTON' else st.mass
            st.tension_stiffness=min(st.tension_stiffness,5.0)
            st.compression_stiffness=min(st.compression_stiffness,4.0)
            st.shear_stiffness=min(st.shear_stiffness,3.0)
            st.bending_stiffness=min(st.bending_stiffness,.25)
            st.tension_damping=12.0
            st.compression_damping=12.0
            st.shear_damping=12.0
            st.bending_damping=1.0
            co=cloth.collision_settings
            co.use_self_collision=False
            co.collision_quality=16
            co.distance_min=.0015
            co.friction=1.0
        obj['nwcs_preset'] = p.preset
        nwcs_solver_stability_profile(obj,cloth,p)
        nwcs_configure_collision_environment(context,obj,cloth,p.reference_body)
        cloth.point_cache.frame_start=1
        cloth.point_cache.frame_end=p.sim_frames
        sub=obj.modifiers.new('Fabric Subdivision','SUBSURF')
        sub.levels=2
        sub.render_levels=2
        nwcs_add_fabric_thickness(obj,p.fabric_thickness)
        body=p.reference_body
        if body and not any(m.type=='COLLISION' for m in body.modifiers):
            body.modifiers.new('NWCS Body Collision','COLLISION')
            body.collision.thickness_outer=0.003
            body.collision.cloth_friction=3.0
        context.scene.frame_start=1
        context.scene.frame_end=p.sim_frames
        obj['nwcs_sim_ready']=True
        ringcoll=bpy.data.collections.get('NWCS Control Rings')
        if ringcoll:
            for ring in ringcoll.objects:
                ring.hide_set(True)
                ring.hide_render=True
        if p.preset == 'DRESS':
            nwcs_discard_control_rings()
        if context.object and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        nwcs_finish_garment_transform(context,obj)
        context.scene.frame_set(1)
        if p.preset in {'PANTS','SWEATER'} or (p.preset=='DRESS' and p.dress_sleeves!='NONE'):
            self.report({'WARNING'},'Prototype: sleeve/leg joins need topology refinement before export')
        else:
            self.report({'INFO'},'Garment built. Play timeline to drape.')
        return {'FINISHED'}

def nwcs_sculpt_tool(context, tool_id):
    """Activate a Blender sculpt brush from a 3D View context."""
    screen = context.screen
    if not screen:
        return False
    for area in screen.areas:
        if area.type == 'VIEW_3D':
            region = next((r for r in area.regions if r.type == 'WINDOW'), None)
            if region is None:
                continue
            try:
                with context.temp_override(area=area, region=region):
                    bpy.ops.wm.tool_set_by_id(name=tool_id)
                return True
            except (RuntimeError, TypeError, ValueError):
                pass
    return False


class NWCS_OT_grab_pull(bpy.types.Operator):
    bl_idname = 'nwcs.grab_pull'
    bl_label = 'Sculpt Grab & Pull'
    bl_description = 'Sculpt the frozen garment directly using the Grab brush; drag to pull fabric'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH' or not obj.get('nwcs_frozen'):
            self.report({'WARNING'}, 'Finish the garment and select its finished mesh first')
            return {'CANCELLED'}
        if obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.mode_set(mode='SCULPT')
        if not nwcs_sculpt_tool(context, 'builtin_brush.Grab'):
            self.report({'WARNING'}, 'Sculpt Mode opened. Select the Grab brush in the sculpt toolbar.')
        else:
            self.report({'INFO'}, 'Drag on the garment to pull fabric; F changes brush radius, Shift+F changes strength.')
        return {'FINISHED'}


class NWCS_OT_smooth_fabric(bpy.types.Operator):
    bl_idname = 'nwcs.smooth_fabric'
    bl_label = 'Smooth Fabric'
    bl_description = 'Switch to the Smooth sculpt brush to soften lumps in the finished garment'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH' or not obj.get('nwcs_frozen'):
            self.report({'WARNING'}, 'Select the frozen garment first')
            return {'CANCELLED'}
        if obj.mode != 'SCULPT':
            if obj.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.mode_set(mode='SCULPT')
        if not nwcs_sculpt_tool(context, 'builtin_brush.Smooth'):
            self.report({'WARNING'}, 'Select the Smooth brush in the sculpt toolbar, or hold Shift while sculpting.')
        return {'FINISHED'}


class NWCS_OT_end_sculpt(bpy.types.Operator):
    bl_idname = 'nwcs.end_sculpt'
    bl_label = 'Return to Garment'
    bl_description = 'Exit Sculpt Mode and return to Object Mode'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if obj and obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        return {'FINISHED'}


class NWCS_OT_pin_selection(bpy.types.Operator):
    bl_idname='nwcs.pin_selection'
    bl_label='Pin Selected Cloth Vertices'
    bl_description='In Edit Mode, pin selected garment vertices so they remain fixed during cloth simulation'
    bl_options={'REGISTER','UNDO'}
    unpin: bpy.props.BoolProperty(default=False)
    def execute(self,context):
        obj=context.edit_object
        if not obj or obj.type!='MESH' or not any(m.type=='CLOTH' for m in obj.modifiers):
            self.report({'ERROR'},'Select garment vertices in Edit Mode first')
            return {'CANCELLED'}
        import bmesh
        bm=bmesh.from_edit_mesh(obj.data)
        selected=[v.index for v in bm.verts if v.select]
        if not selected:
            self.report({'ERROR'},'No vertices selected')
            return {'CANCELLED'}
        group=obj.vertex_groups.get('NWCS_Edge_Anchors')
        if not group:group=obj.vertex_groups.new(name='NWCS_Edge_Anchors')
        # Vertex group assignment must be done in Object Mode.
        bpy.ops.object.mode_set(mode='OBJECT')
        if self.unpin:group.remove(selected)
        else:group.add(selected,1.0,'REPLACE')
        for mod in obj.modifiers:
            if mod.type=='CLOTH':
                mod.settings.vertex_group_mass=group.name
                mod.settings.pin_stiffness=1.0
        bpy.ops.object.mode_set(mode='EDIT')
        self.report({'INFO'},('Unpinned' if self.unpin else 'Pinned')+f' {len(selected)} vertices. Restart simulation.')
        return {'FINISHED'}

def nwcs_preflight_cloth(context, obj):
    """Validate the actual simulation cage before timeline playback.

    Never silently change garment vertices or approved fabric presets.
    """
    from collections import Counter
    import math
    mesh=obj.data
    mesh.update()
    issues=[]
    if not mesh.vertices or not mesh.polygons:
        issues.append('Garment mesh is empty')
    else:
        try:
            nwcs_validate_cloth_cage(obj,'Garment')
        except ValueError as exc:
            issues.append(str(exc))
        # Detect coincident faces and non-finite coordinates, which can evade
        # the ordinary local-edge validator.
        if any(not all(math.isfinite(c) for c in v.co) for v in mesh.vertices):
            issues.append('Non-finite vertex coordinates')
        signatures=Counter(tuple(sorted(f.vertices)) for f in mesh.polygons)
        if any(n>1 for n in signatures.values()):
            issues.append('Duplicate overlapping faces')
    cloths=[(i,m) for i,m in enumerate(obj.modifiers) if m.type=='CLOTH']
    if len(cloths)!=1:
        issues.append(f'Expected one Cloth modifier; found {len(cloths)}')
    else:
        ci,cloth=cloths[0]
        if any(m.type in {'SOLIDIFY','SUBSURF','MULTIRES','BEVEL'} for m in list(obj.modifiers)[:ci]):
            issues.append('Subdivision or thickness modifier precedes Cloth')
        group=cloth.settings.vertex_group_mass
        if group:
            vg=obj.vertex_groups.get(group)
            if vg is None:
                issues.append('Cloth pin group is missing')
            else:
                # All weights must be in [0,1] and attached to real vertices.
                for v in mesh.vertices:
                    try: weight=vg.weight(v.index)
                    except RuntimeError:continue
                    if not math.isfinite(weight) or weight<0 or weight>1:
                        issues.append('Invalid cloth pin weights');break
        if cloth.point_cache.is_baked:
            issues.append('Cloth cache is baked; free bake before restarting')
    body=context.scene.nwcs_props.reference_body
    if body is not None and body.type=='MESH':
        if not any(m.type=='COLLISION' for m in body.modifiers):
            issues.append('Avatar body has no Collision modifier')
        # World-space proximity check. Penetration cannot be reliably inferred
        # from nearest-distance alone, so flag only extremely close vertices
        # rather than incorrectly projecting the garment through the body.
        try:
            from mathutils.bvhtree import BVHTree
            from mathutils import Vector
            dg=context.evaluated_depsgraph_get()
            ev=body.evaluated_get(dg)
            bm=ev.to_mesh()
            try:
                verts=[body.matrix_world @ v.co for v in bm.vertices]
                polys=[list(f.vertices) for f in bm.polygons]
                if polys and verts:
                    tree=BVHTree.FromPolygons(verts,polys)
                    step=max(1,len(mesh.vertices)//1000)
                    close=0
                    for vi in range(0, len(mesh.vertices), step):
                        v=mesh.vertices[vi]
                        hit=tree.find_nearest(obj.matrix_world@v.co)
                        if hit[0] is not None and hit[3]<0.0005:
                            close+=1
                    if close>max(8,int(((len(mesh.vertices)+step-1)//step)*.12)):
                        issues.append('Garment is nearly coincident with avatar surface; increase initial clearance')
            finally:
                ev.to_mesh_clear()
        except Exception as exc:
            # Evaluation can fail for rigged or modified avatar bodies. This
            # inspection is advisory; do not block otherwise valid simulation.
            obj['nwcs_collision_inspection_warning'] = str(exc)[:240]
    return issues

def nwcs_find_simulation_garment(context):
    """Prefer the selected working cloth garment; never choose a frozen result."""
    active=context.view_layer.objects.active
    def valid(ob):
        return bool(ob and ob.type=='MESH' and ob.get('nwcs_sim_ready')
                    and not ob.get('nwcs_frozen')
                    and any(m.type=='CLOTH' for m in ob.modifiers))
    if valid(active):
        return active
    candidates=[ob for ob in context.scene.objects if valid(ob)]
    return candidates[-1] if candidates else None

class NWCS_OT_validate_cloth(bpy.types.Operator):
    bl_idname='nwcs.validate_cloth'
    bl_label='Validate & Prepare Cloth'
    bl_options={'REGISTER'}
    def execute(self,context):
        obj=nwcs_find_simulation_garment(context)
        if obj is None:
            self.report({'ERROR'},'Build a cloth garment first')
            return {'CANCELLED'}
        obj.pop('nwcs_collision_inspection_warning', None)
        issues=nwcs_preflight_cloth(context,obj)
        if obj.get('nwcs_collision_inspection_warning'):
            self.report({'WARNING'},'Avatar proximity inspection skipped: '+obj['nwcs_collision_inspection_warning'][:140])
        if issues:
            for issue in issues[:4]:self.report({'ERROR'},issue)
            obj['nwcs_preflight_status']='FAILED: '+' | '.join(issues)
            return {'CANCELLED'}
        for mod in obj.modifiers:
            if mod.type=='CLOTH':
                mod.collision_settings.use_self_collision=False
                mod.show_viewport=False
                mod.show_viewport=True
        context.scene.frame_set(context.scene.frame_start)
        obj['nwcs_preflight_status']='PASSED'
        self.report({'INFO'},'Cloth validation passed; cache reset to start frame')
        return {'FINISHED'}

class NWCS_OT_start_sim(bpy.types.Operator):
    bl_idname='nwcs.start_sim';bl_label='Start Cloth Simulation';bl_options={'REGISTER'}
    def execute(self,context):
        obj=nwcs_find_simulation_garment(context)
        if not obj:
            self.report({'ERROR'},'Build a garment first');return {'CANCELLED'}
        obj.pop('nwcs_collision_inspection_warning', None)
        issues=nwcs_preflight_cloth(context,obj)
        if obj.get('nwcs_collision_inspection_warning'):
            self.report({'WARNING'},'Avatar proximity inspection skipped: '+obj['nwcs_collision_inspection_warning'][:140])
        if issues:
            for issue in issues[:4]:self.report({'ERROR'},issue)
            obj['nwcs_preflight_status']='FAILED: '+' | '.join(issues)
            return {'CANCELLED'}
        # Enforce no cloth self-collision, including on garments built by older releases.
        for mod in obj.modifiers:
            if mod.type == 'CLOTH':
                mod.collision_settings.use_self_collision = False
                # Avoid reconfiguring the cloth modifier or collision objects on
                # resume: that invalidates Blender's unbaked simulation cache.
                # The build and explicit Validate action set these properties.
        for o in context.selected_objects:o.select_set(False)
        obj.hide_set(False);obj.hide_render=False
        # Hide frozen results while replaying the original cloth simulation.
        for other in context.scene.objects:
            if other is not obj and other.get('nwcs_frozen'):
                other.hide_set(True)
        obj.select_set(True);context.view_layer.objects.active=obj
        # Resume from the paused frame. Do not rewind or invalidate the cloth
        # point cache when the user presses Simulate after Stop.
        current_frame=context.scene.frame_current
        # Physics evaluation advances while the timeline plays in the viewport.
        if not context.screen or not any(a.type=='VIEW_3D' for a in context.screen.areas):
            self.report({'WARNING'},'Use the timeline Play button to run simulation');return {'FINISHED'}
        if not context.screen.is_animation_playing:
            bpy.ops.screen.animation_play()
        # Register the click watcher in the 3D viewport WINDOW region, not the sidebar.
        try:
            area=next(a for a in context.screen.areas if a.type=='VIEW_3D')
            region=next(r for r in area.regions if r.type=='WINDOW')
            with context.temp_override(area=area,region=region):
                bpy.ops.nwcs.click_to_stop('INVOKE_DEFAULT')
        except Exception as exc:
            self.report({'WARNING'},'Click-to-stop unavailable; use Stop button: '+str(exc)[:100])
        self.report({'INFO'},f'Cloth simulation playing from frame {current_frame}. Stop pauses; Simulate resumes.')
        return {'FINISHED'}

class NWCS_OT_click_to_stop(bpy.types.Operator):
    """Pause playback by clicking directly on the generated garment."""
    bl_idname = 'nwcs.click_to_stop'
    bl_label = 'Click Garment to Stop Simulation'
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        if context.area is None or context.area.type != 'VIEW_3D':
            return {'CANCELLED'}
        self._area = context.area
        self._region = next((r for r in context.area.regions if r.type == 'WINDOW'), None)
        if self._region is None:
            return {'CANCELLED'}
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if not context.screen or not context.screen.is_animation_playing:
            return {'FINISHED'}
        if event.type != 'LEFTMOUSE' or event.value != 'PRESS':
            return {'PASS_THROUGH'}
        region = self._region
        if not region or not self._area or self._area.type != 'VIEW_3D':
            return {'FINISHED'}
        # Mouse coordinates must be relative to the viewport WINDOW region,
        # not the Properties/sidebar region where Start Simulation was pressed.
        x, y = event.mouse_x - region.x, event.mouse_y - region.y
        if not (0 <= x < region.width and 0 <= y < region.height):
            return {'PASS_THROUGH'}
        from bpy_extras import view3d_utils
        from mathutils import Vector
        space = next((sp for sp in self._area.spaces if sp.type == 'VIEW_3D'), None)
        if not space or not space.region_3d:
            return {'PASS_THROUGH'}
        origin = view3d_utils.region_2d_to_origin_3d(region, space.region_3d, (x, y))
        direction = view3d_utils.region_2d_to_vector_3d(region, space.region_3d, (x, y))
        depsgraph = context.evaluated_depsgraph_get()
        for ob in context.scene.objects:
            if not ob.get('nwcs_sim_ready') or not any(m.type == 'CLOTH' for m in ob.modifiers):
                continue
            if ob.hide_get() or ob.type != 'MESH':
                continue
            evaluated = ob.evaluated_get(depsgraph)
            inv = evaluated.matrix_world.inverted_safe()
            local_origin = inv @ origin
            local_dir = (inv.to_3x3() @ direction).normalized()
            try:
                hit, loc, normal, index = evaluated.ray_cast(local_origin, local_dir)
            except (RuntimeError, ValueError):
                continue
            if hit:
                with context.temp_override(area=self._area, region=region):
                    bpy.ops.screen.animation_cancel(restore_frame=False)
                self.report({'INFO'}, 'Garment clicked: simulation paused')
                return {'FINISHED'}
        return {'PASS_THROUGH'}

class NWCS_OT_stop_sim(bpy.types.Operator):
    bl_idname='nwcs.stop_sim'
    bl_label='Stop Simulation'
    bl_description='Pause playback at the current frame without resetting or freezing cloth'
    bl_options={'REGISTER'}
    def execute(self,context):
        if context.screen and context.screen.is_animation_playing:
            bpy.ops.screen.animation_cancel(restore_frame=False)
            self.report({'INFO'},'Simulation paused at current frame')
        else:
            self.report({'INFO'},'Simulation is already stopped')
        return {'FINISHED'}

class NWCS_OT_remove_drafts(bpy.types.Operator):
    bl_idname='nwcs.remove_drafts'
    bl_label='Clear Current Garment'
    bl_description='Remove the current generated garment and all Neverworld control rings; keep avatar and frozen garments'
    bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        if context.screen and context.screen.is_animation_playing:
            bpy.ops.screen.animation_cancel(restore_frame=False)
        if context.object and context.object.mode!='OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        scene=context.scene
        active=context.view_layer.objects.active
        targets=[]
        for ob in list(scene.objects):
            if ob.type!='MESH' or ob.get('nwcs_frozen') or ob.get('nwcs_ring'):
                continue
            # The selected Neverworld garment is always eligible; otherwise
            # recognize known generated garments, including partially built ones.
            selected_garment=(ob==active and (ob.get('nwcs_generated') or ob.name.startswith('NWCS_Garment')))
            generated=(ob.get('nwcs_sim_ready') or ob.get('nwcs_generated') or ob.name.startswith('NWCS_Garment'))
            if selected_garment or generated:
                targets.append(ob)
        for ob in targets:
            bpy.data.objects.remove(ob,do_unlink=True)
        # Clear every add-on control ring, including rings outside the named collection.
        ring_targets=[ob for ob in list(scene.objects) if ob.get('nwcs_ring')]
        ring_collection=bpy.data.collections.get('NWCS Control Rings')
        if ring_collection:
            for ob in list(ring_collection.objects):
                if ob not in ring_targets:
                    ring_targets.append(ob)
        for ob in ring_targets:
            bpy.data.objects.remove(ob,do_unlink=True)
        if ring_collection and not ring_collection.objects:
            bpy.data.collections.remove(ring_collection)
        _nwcs_mirror_state.clear()
        scene.frame_set(1)
        self.report({'INFO'},f'Cleared {len(targets)} garment object(s) and {len(ring_targets)} control ring(s); avatar and frozen garments preserved')
        return {'FINISHED'}

class NWCS_OT_clear_garment_only(bpy.types.Operator):
    bl_idname='nwcs.clear_garment_only'
    bl_label='Clear Garment'
    bl_description='Remove generated garments and their add-on trim, but keep avatar, control rings and settings'
    bl_options={'REGISTER','UNDO'}

    def execute(self,context):
        if context.screen and context.screen.is_animation_playing:
            bpy.ops.screen.animation_cancel(restore_frame=False)
        if context.object and context.object.mode!='OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        targets=[]
        for ob in list(context.scene.objects):
            if ob.type!='MESH' or ob.get('nwcs_ring') or ob.get('nwcs_frozen'):
                continue
            if (ob.get('nwcs_generated') or ob.get('nwcs_sim_ready')
                    or ob.name.startswith('NWCS_Garment')):
                targets.append(ob)
        for ob in targets:
            bpy.data.objects.remove(ob,do_unlink=True)
        context.scene.frame_set(1)
        self.report({'INFO'},f'Cleared {len(targets)} generated garment(s); control rings and avatar preserved')
        return {'FINISHED'}

class NWCS_OT_reset_sim(bpy.types.Operator):
    bl_idname='nwcs.reset_sim';bl_label='Reset Simulation';bl_options={'REGISTER'}
    def execute(self,context):
        scene=context.scene
        if context.screen and context.screen.is_animation_playing:
            bpy.ops.screen.animation_cancel(restore_frame=False)
        for obj in scene.objects:
            if not obj.get('nwcs_sim_ready'):continue
            for mod in obj.modifiers:
                if mod.type=='CLOTH':
                    mod.collision_settings.use_self_collision = False
                    cache=mod.point_cache
                    if cache.is_baked:
                        self.report({'WARNING'},'Free baked cloth cache in Physics > Cache before resetting')
                    else:
                        # Toggling the modifier invalidates the unbaked cloth cache.
                        mod.show_viewport=False
                        mod.show_viewport=True
        scene.frame_set(1)
        self.report({'INFO'},'Returned to frame 1. Play timeline to recalculate.')
        return {'FINISHED'}

class NWCS_OT_show_rings(bpy.types.Operator):
    bl_idname='nwcs.show_rings';bl_label='Show Control Rings';bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        coll=bpy.data.collections.get('NWCS Control Rings')
        if not coll:
            self.report({'ERROR'},'No control rings found');return {'CANCELLED'}
        for ring in coll.objects:ring.hide_set(False)
        return {'FINISHED'}

# Export-safe vertex budget. Keep a margin for later hems and seams.
NWCS_MAX_EXPORT_VERTS = 99999
NWCS_FREEZE_TARGET_VERTS = 80000

def nwcs_reduce_mesh_to_budget(context, obj, limit=NWCS_FREEZE_TARGET_VERTS):
    """Reduce the frozen garment only; leave the simulation cage untouched.

    Blender Decimate preserves UV interpolation on surviving faces. This is
    intended for frozen copies, never the cloth simulation source.
    """
    if obj.type != 'MESH':
        return 0, 0
    original = len(obj.data.vertices)
    if original <= limit:
        return original, original
    # Repeated bounded passes handle non-linear face/vertex reductions.
    for attempt in range(5):
        count = len(obj.data.vertices)
        if count <= limit:
            break
        modifier = obj.modifiers.new('NWCS Export Polygon Reduction', 'DECIMATE')
        modifier.decimate_type = 'COLLAPSE'
        modifier.ratio = max(0.01, min(0.99, (limit / max(1, count)) * 0.87))
        modifier.use_collapse_triangulate = False
        try:
            with context.temp_override(object=obj, active_object=obj, selected_objects=[obj]):
                bpy.ops.object.modifier_apply(modifier=modifier.name)
        except Exception:
            if modifier.name in obj.modifiers:
                obj.modifiers.remove(modifier)
            raise
    remaining = len(obj.data.vertices)
    if remaining > limit:
        raise RuntimeError(f'Cannot reduce garment below {limit:,} vertices (currently {remaining:,})')
    obj['nwcs_export_optimized'] = True
    obj['nwcs_original_vertex_count'] = original
    obj['nwcs_export_vertex_count'] = remaining
    return original, remaining

class NWCS_OT_optimize_export(bpy.types.Operator):
    bl_idname = 'nwcs.optimize_export'
    bl_label = 'Optimize for Upload (under 100K)'
    bl_description = 'Reduce the selected frozen garment to at most 80,000 vertices, leaving room for finishing details'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH' or not obj.get('nwcs_frozen'):
            self.report({'ERROR'}, 'Select a finished Neverworld garment first')
            return {'CANCELLED'}
        try:
            before, after = nwcs_reduce_mesh_to_budget(context, obj)
        except Exception as exc:
            self.report({'ERROR'}, f'Upload optimization failed: {exc}')
            return {'CANCELLED'}
        self.report({'INFO'}, f'Upload-ready garment: {before:,} to {after:,} vertices')
        return {'FINISHED'}

class NWCS_OT_freeze(bpy.types.Operator):
    bl_idname='nwcs.freeze';bl_label='Freeze Garment at Current Frame';bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        obj=context.active_object
        if not obj or obj.type!='MESH' or not any(m.type=='CLOTH' for m in obj.modifiers):
            self.report({'ERROR'},'Select the generated garment with Cloth modifier');return {'CANCELLED'}
        depsgraph=context.evaluated_depsgraph_get();evalobj=obj.evaluated_get(depsgraph)
        # Subdivision and Solidify are evaluated here, which can multiply
        # vertices dramatically. Reduce only the frozen copy, never the cage.
        mesh=bpy.data.meshes.new_from_object(evalobj,preserve_all_data_layers=True,depsgraph=depsgraph)
        frozen=bpy.data.objects.new(obj.name+'_Frozen',mesh);context.scene.collection.objects.link(frozen)
        frozen['nwcs_generated']=True
        frozen['nwcs_frozen']=True
        frozen.matrix_world=obj.matrix_world.copy()
        try:
            initial_count, final_count = nwcs_reduce_mesh_to_budget(context, frozen)
        except Exception as exc:
            bpy.data.objects.remove(frozen, do_unlink=True)
            self.report({'ERROR'}, f'Freeze aborted: {exc}')
            return {'CANCELLED'}
        mesh=frozen.data
        if mesh.vertices:
            xs=[v.co.x for v in mesh.vertices]
            ys=[v.co.y for v in mesh.vertices]
            zs=[v.co.z for v in mesh.vertices]
            mid=Vector(((min(xs)+max(xs))/2,(min(ys)+max(ys))/2,(min(zs)+max(zs))/2))
            world_offset=frozen.matrix_world.to_3x3() @ mid
            for v in mesh.vertices:
                v.co-=mid
            frozen.location+=world_offset
            mesh.update()
        # A frozen result replaces the working garment visually. Keep the
        # original hidden for a possible reset, never display both at once.
        obj.hide_set(True)
        obj.hide_render=True
        for ob in context.selected_objects:ob.select_set(False)
        frozen.select_set(True);context.view_layer.objects.active=frozen
        self.report({'INFO'},'Finished garment visible; simulated original hidden.')
        return {'FINISHED'}

def nwcs_safe_initial_uv(obj):
    """Create deterministic, non-operator UVs without modifying mesh topology.

    This is a crash-safe baseline for boolean-joined sleeves. Detailed pattern
    unwrapping can be performed separately after the garment is safely built.
    """
    from math import atan2, pi
    mesh=obj.data
    if not mesh.vertices or not mesh.polygons:return 0
    layer=mesh.uv_layers.get('NWCS_Garment_UV')
    if layer is None:layer=mesh.uv_layers.new(name='NWCS_Garment_UV')
    mesh.uv_layers.active=layer
    coords=[v.co for v in mesh.vertices]
    xs=[v.x for v in coords];ys=[v.y for v in coords];zs=[v.z for v in coords]
    cx=(min(xs)+max(xs))*.5;cy=(min(ys)+max(ys))*.5
    zmin=min(zs);height=max(max(zs)-zmin,1e-6)
    for face in mesh.polygons:
        for li in face.loop_indices:
            p=coords[mesh.loops[li].vertex_index]
            a=atan2(p.x-cx,p.y-cy)
            layer.data[li].uv=((a+pi)/(2*pi), (p.z-zmin)/height)
    mesh.update()
    return len(mesh.polygons)


def nwcs_trouser_pattern_uv(obj):
    """Stable three-panel cylindrical pattern UV for pants and boxer legs.

    One unbroken rectangular region per leg, one for the hip/waist.
    V always follows garment height (waist at the TOP of the UV).
    Never invokes Smart UV Project or creates random tiny islands.
    """
    from math import atan2, pi, isfinite
    mesh=obj.data
    if not mesh.vertices or not mesh.polygons:
        raise ValueError('No trouser mesh to unwrap')
    coords=[v.co for v in mesh.vertices]
    xs=[p.x for p in coords]; ys=[p.y for p in coords]; zs=[p.z for p in coords]
    xmin,xmax=min(xs),max(xs); ymin,ymax=min(ys),max(ys)
    zmin,zmax=min(zs),max(zs)
    cx=(xmin+xmax)*.5; cy=(ymin+ymax)*.5
    height=max(zmax-zmin,1e-6)
    # Detect the leg centers from lower vertices, not from a generic bounding box.
    lower=[p for p in coords if p.z<zmin+height*.30]
    right=[p.x for p in lower if p.x>cx]; left=[p.x for p in lower if p.x<=cx]
    if not left or not right:raise ValueError('Could not identify both trouser legs')
    lx=sum(left)/len(left);rx=sum(right)/len(right)
    # Hip/leg transition is determined by the thigh-to-waist silhouette.
    # Explicitly maintain UV continuity on each side of this split.
    split=zmin+height*.73
    uv=mesh.uv_layers.get('NWCS_Trouser_Pattern_UV')
    if uv is None:uv=mesh.uv_layers.new(name='NWCS_Trouser_Pattern_UV')
    mesh.uv_layers.active=uv
    # Three full-height, clearly separated rectangular islands:
    # left leg, right leg, waist/seat. No flips or arbitrary packing.
    blocks=((.02,.32),(.35,.65),(.68,.98))
    for poly in mesh.polygons:
        ids=list(poly.loop_indices)
        points=[coords[mesh.loops[i].vertex_index] for i in ids]
        mid=sum((p.z for p in points))/len(points)
        avgx=sum((p.x for p in points))/len(points)
        section=2 if mid>=split else (0 if avgx<cx else 1)
        center_x=(lx,rx,cx)[section]
        # Front of the mesh stays at the same side of every panel.
        angles=[atan2(p.x-center_x,p.y-cy) for p in points]
        # Unwrap angular seam within each polygon (not across the whole mesh).
        if max(angles)-min(angles)>pi:
            angles=[a+2*pi if a<0 else a for a in angles]
        u0,u1=blocks[section]
        for li,p,a in zip(ids,points,angles):
            u=u0+(u1-u0)*((a+pi)/(2*pi))
            # The UV coordinate must stay in its panel even at the seam.
            if u>u1:u-=u1-u0
            v=.02+.96*((p.z-zmin)/height)
            uv.data[li].uv=(max(u0,min(u1,u)),max(.02,min(.98,v)))
    uv.name='NWCS_Trouser_Pattern_UV'
    mesh.update()
    return len(mesh.polygons)


def nwcs_pattern_unwrap(context, obj, margin=0.012):
    """Non-operator UV projection. Does not run Blender's potentially expensive
    Angle Based unwrap or pack-islands solver on dense frozen cloth geometry.
    No mesh topology, modifiers, object selection or mode is changed.
    """
    from math import atan2, pi, isfinite
    mesh = obj.data
    if not mesh.vertices or not mesh.polygons:
        raise ValueError('Garment has no geometry to unwrap')
    coords = [v.co for v in mesh.vertices]
    xs = [p.x for p in coords]; ys = [p.y for p in coords]; zs = [p.z for p in coords]
    cx = (min(xs)+max(xs))*.5; cy = (min(ys)+max(ys))*.5
    xspan = max(max(xs)-min(xs),1e-6)
    zmin,zmax = min(zs),max(zs); zspan = max(zmax-zmin,1e-6)
    uv = mesh.uv_layers.active or mesh.uv_layers.new(name='NWCS_Garment_Pattern_UV')
    mesh.uv_layers.active = uv
    sleeved = bool(obj.get('nwcs_connected_sleeves'))
    # Three non-overlapping regions: left sleeve, torso, right sleeve.
    # UV orientation is fixed, so successive UV repairs are deterministic.
    for poly in mesh.polygons:
        loops = list(poly.loop_indices)
        pts = [coords[mesh.loops[li].vertex_index] for li in loops]
        avgx = sum(p.x for p in pts)/len(pts)
        is_arm = sleeved and abs(avgx-cx) > xspan*.30
        if is_arm:
            right = avgx > cx
            u0,u1 = ((.78,.98) if right else (.02,.22))
            # Sleeve length along X, circumference from Y/Z.
            armpts = [p for p in coords if (p.x>cx+xspan*.30 if right else p.x<cx-xspan*.30)]
            lo = min(p.x for p in armpts); hi=max(p.x for p in armpts)
            scale=max(hi-lo,1e-6)
            for li,p in zip(loops,pts):
                u=u0+(u1-u0)*(p.x-lo)/scale
                v=.02+.96*((atan2(p.z-(zmin+zspan*.70),p.y-cy)+pi)/(2*pi))
                uv.data[li].uv=(u,v)
        else:
            u0,u1 = ((.25,.75) if sleeved else (.02,.98))
            angles=[atan2(p.x-cx,p.y-cy) for p in pts]
            if max(angles)-min(angles)>pi:
                angles=[a+2*pi if a<0 else a for a in angles]
            for li,p,ang in zip(loops,pts,angles):
                t=((ang+pi)/(2*pi))%1.0
                uv.data[li].uv=(u0+(u1-u0)*t,.02+.96*(p.z-zmin)/zspan)
    uv.name='NWCS_Garment_Pattern_UV'
    mesh.update()
    return len(mesh.polygons)


class NWCS_OT_auto_uv(bpy.types.Operator):
    bl_idname = 'nwcs.auto_uv'
    bl_label = 'Repair Garment UV'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        """Fast UV repair using bulk mesh arrays; never invoke an unwrap solver."""
        import numpy as np
        obj = context.active_object
        if not obj or obj.type != 'MESH' or not obj.get('nwcs_generated'):
            self.report({'ERROR'}, 'Select a FINISHED Neverworld garment first')
            return {'CANCELLED'}
        if obj.mode != 'OBJECT':
            self.report({'ERROR'}, 'Switch to Object Mode before repairing UVs')
            return {'CANCELLED'}
        mesh = obj.data
        nverts, nloops = len(mesh.vertices), len(mesh.loops)
        if not nverts or not nloops:
            self.report({'ERROR'}, 'Garment mesh has no UV-mappable geometry')
            return {'CANCELLED'}
        # Avoid running huge synchronous operations that make Blender appear hung.
        if nloops > 1200000:
            self.report({'ERROR'}, 'Mesh exceeds 1.2 million UV corners; optimize the finished garment first')
            return {'CANCELLED'}
        try:
            vertices = np.empty(nverts * 3, dtype=np.float32)
            mesh.vertices.foreach_get('co', vertices)
            vertices = vertices.reshape((-1, 3))
            indices = np.empty(nloops, dtype=np.int32)
            mesh.loops.foreach_get('vertex_index', indices)
            xyz = vertices[indices]
            lo = vertices.min(axis=0)
            hi = vertices.max(axis=0)
            center = (lo + hi) * .5
            span = np.maximum(hi - lo, 1e-6)
            preset = obj.get('nwcs_preset', '')
            if not preset and obj.get('nwcs_frozen'):
                source = bpy.data.objects.get(obj.name.rsplit('_Frozen', 1)[0])
                if source:
                    preset = source.get('nwcs_preset', '')
            pants = preset in {'PANTS', 'BOXER_BRIEFS', 'BOXER_SHORTS'} or bool(obj.get('nwcs_connected_pants'))
            sleeves = bool(obj.get('nwcs_connected_sleeves'))
            if pants:
                # Independent leg panels and upper seat/waist panel.
                low = vertices[vertices[:, 2] < lo[2] + .30 * span[2]]
                left = low[low[:, 0] < center[0]]
                right = low[low[:, 0] >= center[0]]
                if len(left) and len(right):
                    lx = left[:, 0].mean()
                    rx = right[:, 0].mean()
                else:
                    lx, rx = center[0] - .25 * span[0], center[0] + .25 * span[0]
                section = np.where(xyz[:, 2] >= lo[2] + .73 * span[2], 2,
                                   np.where(xyz[:, 0] < center[0], 0, 1))
                centers = np.choose(section, [lx, rx, center[0]])
                angle = np.arctan2(xyz[:, 0] - centers, xyz[:, 1] - center[1])
                u = .02 + section * .33 + .30 * ((angle + np.pi) / (2 * np.pi))
                v = .02 + .96 * (xyz[:, 2] - lo[2]) / span[2]
            else:
                # Two coherent cloth panels rather than face-by-face Smart UV
                # fragments. Determine the outward side from polygon normals,
                # then propagate it through the connected surface. The seam is
                # at the garment sides, leaving front/back intact for graphics.
                nfaces = len(mesh.polygons)
                starts = np.empty(nfaces, dtype=np.int32)
                counts = np.empty(nfaces, dtype=np.int32)
                normals = np.empty(nfaces * 3, dtype=np.float32)
                mesh.polygons.foreach_get('loop_start', starts)
                mesh.polygons.foreach_get('loop_total', counts)
                mesh.polygons.foreach_get('normal', normals)
                normals = normals.reshape((-1, 3))
                face_y = np.add.reduceat(xyz[:, 1], starts) / counts
                # NWCS faces -Y. Side-facing polygons follow their position,
                # but front/back normals anchor the classification across folds.
                yscore = (center[1] - face_y) / max(span[1], 1e-6)
                facing = -normals[:, 1]
                # Determine the side from actual face position, not the
                # normal: ruffles and folded cloth often face backwards.
                # The face-position split keeps each panel coherent.
                front = yscore >= 0
                # A stable positional seam at both side edges. Do not vote
                # across the seam: that can split or invert cloth panels.
                is_front = np.repeat(front, counts)
                # Preserve the recognizable front/back silhouettes. Correct
                # horizontal compression from cloth folds using measured 3-D
                # mesh edge lengths, not a new global unwrap/packing pass.
                # UVs remain two full-height panels on the same 0..1 canvas.
                xbase = (xyz[:, 0] - lo[0]) / span[0]
                # Compute local stretch using each mesh edge's actual length
                # relative to its flat XZ projection. Bound the correction so
                # deep ruffles never explode the UV silhouette.
                edge_ids = np.empty(len(mesh.edges)*2, dtype=np.int32)
                mesh.edges.foreach_get('vertices', edge_ids)
                edges = edge_ids.reshape((-1, 2))
                delta = vertices[edges[:, 1]] - vertices[edges[:, 0]]
                dx = np.abs(delta[:, 0]); dz = np.abs(delta[:, 2])
                # Only predominantly horizontal edges carry fold-depth
                # information. Vertical drape is kept aligned for graphics.
                horizontal = (dx > 1e-6) & (dx > dz * 1.6)
                ratio = np.ones(len(edges), dtype=np.float32)
                ratio[horizontal] = np.clip(np.linalg.norm(delta[horizontal], axis=1) /
                                            np.maximum(dx[horizontal], 1e-6), 1., 1.65)
                weights = dx * horizontal
                stretch_sum = np.bincount(edges.ravel(),
                    weights=np.repeat(ratio * weights, 2), minlength=nverts)
                weight_sum = np.bincount(edges.ravel(),
                    weights=np.repeat(weights, 2), minlength=nverts)
                vertex_stretch = np.divide(stretch_sum, weight_sum,
                    out=np.ones(nverts, dtype=np.float64), where=weight_sum>1e-8)
                # Mild center-anchored compensation; never allow panel overlap.
                correction = np.clip(vertex_stretch[indices] - 1., 0., .45)
                xadjusted = np.clip(.5 + (xbase - .5) * (1. + .28 * correction), 0., 1.)
                u = np.where(is_front, .025, .525) + .45 * xadjusted
                v = .025 + .95 * (xyz[:, 2] - lo[2]) / span[2]
            uvcoords = np.empty((nloops, 2), dtype=np.float32)
            uvcoords[:, 0] = np.clip(u, .001, .999)
            uvcoords[:, 1] = np.clip(v, .001, .999)
            layer = mesh.uv_layers.get('NWCS_Fast_Pattern_UV')
            if layer is None:
                layer = mesh.uv_layers.new(name='NWCS_Fast_Pattern_UV')
            mesh.uv_layers.active = layer
            layer.active_render=True
            layer.data.foreach_set('uv', uvcoords.ravel())
            mesh.update()
        except (MemoryError, Exception) as exc:
            self.report({'ERROR'}, f'UV repair stopped: {exc}')
            return {'CANCELLED'}
        self.report({'INFO'}, f'Front/back UV panels generated for {nloops:,} corners')
        return {'FINISHED'}


class NWCS_OT_repair_frozen_spikes(bpy.types.Operator):
    bl_idname = 'nwcs.repair_frozen_spikes'
    bl_label = 'Fix Geometry Spikes'
    bl_description = 'After Freeze: remove isolated needle vertices without changing UVs or mesh connectivity'
    bl_options = {'REGISTER', 'UNDO'}

    strength: FloatProperty(name='Correction Strength', default=0.85, min=0.1, max=1.0)
    sensitivity: FloatProperty(name='Spike Sensitivity', default=2.8, min=1.8, max=8.0,
                               description='Higher values protect intentional folds; lower values detect more peaks')
    passes: bpy.props.IntProperty(name='Repair Passes', default=3, min=1, max=8)

    def execute(self, context):
        from mathutils import Vector
        from statistics import median
        import bmesh
        obj = context.active_object
        if not obj or obj.type != 'MESH' or not obj.get('nwcs_frozen'):
            self.report({'ERROR'}, 'Finish the garment first, then select its finished copy')
            return {'CANCELLED'}
        if obj.mode != 'OBJECT':
            self.report({'ERROR'}, 'Switch to Object Mode before fixing spikes')
            return {'CANCELLED'}
        mesh = obj.data
        if mesh.shape_keys:
            self.report({'ERROR'}, 'Apply shape keys before repairing frozen geometry')
            return {'CANCELLED'}
        bm = bmesh.new()
        bm.from_mesh(mesh)
        bm.verts.ensure_lookup_table()
        fixed = set()
        for _ in range(self.passes):
            proposals = {}
            coords = {v.index: v.co.copy() for v in bm.verts}
            for v in bm.verts:
                if not v.is_manifold or len(v.link_edges) < 3:
                    continue  # preserve necklines, hems and open boundaries
                neighbors = [e.other_vert(v) for e in v.link_edges]
                if len(neighbors) < 3:
                    continue
                lengths = [(coords[v.index] - coords[n.index]).length for n in neighbors]
                if min(lengths) <= 1e-9:
                    continue
                local_lengths = []
                for n in neighbors:
                    for e in n.link_edges:
                        other = e.other_vert(n)
                        if other != v:
                            local_lengths.append((coords[n.index]-coords[other.index]).length)
                if not local_lengths:
                    continue
                local_scale = median(local_lengths)
                if local_scale <= 1e-9:
                    continue
                center = sum((coords[n.index] for n in neighbors), Vector()) / len(neighbors)
                offset = (coords[v.index] - center).length
                # Require both an abnormally long edge and a large deviation
                # from the local neighborhood; ordinary ruffles should remain.
                if max(lengths) < local_scale * self.sensitivity:
                    continue
                if offset < local_scale * self.sensitivity * 0.8:
                    continue
                # Move no farther than the local scale per pass to avoid collapse.
                delta = center - coords[v.index]
                movement = min(delta.length * self.strength, local_scale * 1.5)
                if delta.length > 1e-9:
                    proposals[v.index] = coords[v.index] + delta.normalized() * movement
            if not proposals:
                break
            for index, target in proposals.items():
                bm.verts[index].co = target
            fixed.update(proposals)
        if fixed:
            bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
            bm.to_mesh(mesh)
            mesh.update()
        bm.free()
        self.report({'INFO'}, f'Geometry spike repair: adjusted {len(fixed)} vertices; UVs preserved')
        return {'FINISHED'}

class NWCS_OT_finish_or_freeze(bpy.types.Operator):
    """Finish cloth by freezing; fitted garments already have their final mesh."""
    bl_idname='nwcs.finish_or_freeze'
    bl_label='Finish Garment'
    bl_options={'REGISTER','UNDO'}

    def execute(self,context):
        obj=context.active_object
        if not obj or obj.type!='MESH' or not obj.get('nwcs_generated'):
            self.report({'ERROR'},'Select a generated garment first')
            return {'CANCELLED'}
        if any(m.type=='CLOTH' for m in obj.modifiers):
            return bpy.ops.nwcs.freeze('EXEC_DEFAULT')
        # Fitted garments do not need cloth freezing.  Keep their fitted
        # modifiers editable and avoid copying evaluated geometry prematurely.
        obj['nwcs_finished']=True
        self.report({'INFO'},'Fitted garment ready for UV repair and export')
        return {'FINISHED'}

class NWCS_OT_finish(bpy.types.Operator):
    bl_idname='nwcs.finish_garment';bl_label='Add Waistband and Hem';bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        p=context.scene.nwcs_props;obj=context.active_object
        if not obj or obj.type!='MESH' or not obj.get('nwcs_generated'):
            self.report({'ERROR'},'Select the generated garment (preferably the frozen copy)');return {'CANCELLED'}
        if any(m.type=='CLOTH' for m in obj.modifiers):
            self.report({'ERROR'},'Finish the garment at your chosen frame, then select its finished copy')
            return {'CANCELLED'}
        # Use boundary loops of the finished garment, not a generic horizontal cylinder.
        # This follows the real draped edge, including any asymmetric hem.
        import bmesh
        bm=bmesh.new();bm.from_mesh(obj.data)
        edges=[e for e in bm.edges if e.is_boundary]
        chains=[];unused=set(edges)
        while unused:
            first=unused.pop();chain=[first.verts[0],first.verts[1]]
            for end in (1,0):
                while True:
                    v=chain[-1] if end==1 else chain[0]
                    options=[e for e in v.link_edges if e in unused]
                    if not options:break
                    e=options[0];unused.remove(e)
                    nv=e.other_vert(v)
                    if end==1:chain.append(nv)
                    else:chain.insert(0,nv)
                    if nv==chain[0] and end==1:break
            if len(chain)>2:chains.append(chain)
        if not chains:
            bm.free();self.report({'ERROR'},'No open garment edges found');return {'CANCELLED'}
        # Two major circumference boundaries are the top and bottom on skirts.
        chains.sort(key=lambda c:sum(v.co.z for v in c)/len(c))
        world=obj.matrix_world
        created=[]
        for label,chain in (('Hem',chains[0]),('Waistband',chains[-1])):
            if len(chain)<4:continue
            coords=[world @ v.co for v in chain]
            if (coords[0]-coords[-1]).length<1e-6:coords=coords[:-1]
            if len(coords)<3:continue
            # A separate thin 3D trim band, following the garment edge.
            # Do not modify the simulation mesh or its UV layout.
            width=p.finish_width if label=='Waistband' else p.finish_width*.55
            center=sum(coords,Vector())/len(coords)
            vv=[];ff=[];count=len(coords)
            for pt in coords:
                vv.append(tuple(pt));vv.append(tuple(pt+Vector((0,0,-width if label=='Waistband' else width))))
            for i in range(count):
                k=(i+1)%count
                ff.append((2*i,2*k,2*k+1,2*i+1))
            mesh=bpy.data.meshes.new('NWCS_'+label+'_Mesh');mesh.from_pydata(vv,[],ff);mesh.update()
            trim=bpy.data.objects.new('NWCS_'+label,mesh);context.scene.collection.objects.link(trim)
            trim['nwcs_generated']=True
            solid=trim.modifiers.new('Trim Thickness','SOLIDIFY');solid.thickness=p.finish_thickness
            bevel=trim.modifiers.new('Soft Trim Edges','BEVEL');bevel.width=min(p.finish_thickness*.4,.002);bevel.segments=2
            # Simple UV for the band.
            uv=mesh.uv_layers.new(name='Trim_UV')
            for poly in mesh.polygons:
                i=poly.index
                for li,coord in zip(poly.loop_indices,((i/count,0),((i+1)/count,0),((i+1)/count,1),(i/count,1))):uv.data[li].uv=coord
            created.append(trim)
        bm.free()
        if not created:
            self.report({'ERROR'},'Could not build trim from boundary loops');return {'CANCELLED'}
        self.report({'INFO'},'Added separate waistband and hem trim; original garment remains editable')
        return {'FINISHED'}

class NWCS_OT_clear(bpy.types.Operator):
    bl_idname='nwcs.clear_studio';bl_label='Clear / Start Over';bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        # Remove only objects created by this add-on; preserve user body and other work.
        for obj in list(bpy.data.objects):
            if obj.get('nwcs_generated') or obj.get('nwcs_ring'):
                bpy.data.objects.remove(obj,do_unlink=True)
        coll=bpy.data.collections.get('NWCS Control Rings')
        if coll and not coll.objects:bpy.data.collections.remove(coll)
        body=context.scene.nwcs_props.reference_body
        if body and body.name in bpy.data.objects:
            for mod in list(body.modifiers):
                if mod.name=='NWCS Body Collision':body.modifiers.remove(mod)
        context.scene.frame_set(1)
        self.report({'INFO'},'Neverworld generated garments and rings cleared; reference body preserved')
        return {'FINISHED'}


def nwcs_remove_previous_reference(context, replacement):
    """Remove every object owned by earlier reference imports, including rigs."""
    previous=context.scene.nwcs_props.reference_body
    targets=set()
    for obj in list(bpy.data.objects):
        if obj == replacement:
            continue
        name=obj.name.lower()
        legacy=(name.startswith('skeleton_meshbody') or name.startswith('skeleton mesh body') or
                name in {'female','male'} or
                name.startswith(('female.','male.','meshbody_classic_f_',
                                 'nwcs female','nwcs male')) or
                obj.get('nwcs_reference_avatar',False) or
                obj.get('nwcs_reference_import',False))
        if legacy or obj == previous:
            targets.add(obj)
    # Older releases left imported rigs untagged. Remove armatures associated
    # with any removed reference, but never unrelated user rigs.
    changed=True
    while changed:
        changed=False
        for obj in list(bpy.data.objects):
            if obj == replacement or obj in targets:
                continue
            associated=(obj.parent in targets or
                any(mod.type=='ARMATURE' and mod.object in targets for mod in obj.modifiers))
            if associated:
                targets.add(obj);changed=True
    for obj in list(bpy.data.objects):
        if obj == replacement or obj in targets or obj.type!='ARMATURE':
            continue
        name=obj.name.lower()
        if name.startswith(('armature','avatar','skeleton','female','male','meshbody')):
            # Only remove a legacy rig when it has no non-reference dependents.
            dependents=[other for other in bpy.data.objects if other.parent==obj or
                any(m.type=='ARMATURE' and m.object==obj for m in other.modifiers)]
            if not dependents or all(d in targets for d in dependents):
                targets.add(obj)
    for obj in targets:
        if obj.name in bpy.data.objects:
            bpy.data.objects.remove(obj,do_unlink=True)
    for coll in list(bpy.data.collections):
        if not coll.objects and not coll.children and coll.name.lower().startswith(('female','male','meshbody')):
            bpy.data.collections.remove(coll)


def nwcs_remove_female_specks(obj):
    """Discard tiny disconnected geometry islands, preserving the main body."""
    import bmesh
    bm=bmesh.new()
    try:
        bm.from_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        seen=set(); islands=[]
        for v in bm.verts:
            if v in seen:continue
            stack=[v];seen.add(v);component=[]
            while stack:
                cur=stack.pop();component.append(cur)
                for edge in cur.link_edges:
                    neighbor=edge.other_vert(cur)
                    if neighbor not in seen:
                        seen.add(neighbor);stack.append(neighbor)
            islands.append(component)
        if not islands:return
        largest=max(len(island) for island in islands)
        # Keep substantive disconnected components; remove only specks.
        tiny=[v for island in islands if len(island)<max(12,int(largest*0.0005)) for v in island]
        if tiny:
            bmesh.ops.delete(bm,geom=tiny,context='VERTS')
            bm.to_mesh(obj.data);obj.data.update()
    finally:
        bm.free()

# User-supplied body reference meshes are bundled in this add-on.
# They are imported as mesh-only reference geometry; any armatures are removed.
class NWCS_OT_load_reference_avatar(bpy.types.Operator):
    bl_idname='nwcs.load_reference_avatar'
    bl_label='Load Male / Female Reference'
    bl_description='Load one of the supplied reference bodies included with the add-on'
    bl_options={'REGISTER','UNDO'}
    gender:EnumProperty(items=[('FEMALE','Female','Included female reference'),('MALE','Male','Included male reference')])
    def execute(self,context):
        import os
        if context.mode!='OBJECT':
            self.report({'ERROR'},'Switch to Object Mode first');return {'CANCELLED'}
        folder=os.path.dirname(__file__)
        path=os.path.join(folder,'female_reference.fbx' if self.gender=='FEMALE' else 'male_reference.obj')
        if not os.path.isfile(path):
            self.report({'ERROR'},'Included reference file is missing');return {'CANCELLED'}
        before=set(bpy.data.objects)
        try:
            if self.gender=='FEMALE':
                # Use the user-exported FBX pose and its baked axis conversion.
                # Do not stack OBJ axis conversions or manual rotations on it.
                bpy.ops.import_scene.fbx(filepath=path, use_manual_orientation=False)
            elif hasattr(bpy.ops.wm,'obj_import'):
                bpy.ops.wm.obj_import(filepath=path, forward_axis='Y', up_axis='Z')
            else:
                bpy.ops.import_scene.obj(filepath=path, axis_forward='Y', axis_up='Z')
        except Exception as exc:
            self.report({'ERROR'},'Could not import included avatar: '+str(exc)[:180]);return {'CANCELLED'}
        # Store object NAMES, not Blender Object wrappers: removed objects turn
        # their wrappers into invalid StructRNA references.
        created_names=[obj.name for obj in bpy.data.objects if obj not in before]
        # Never retain imported skeleton auxiliary geometry as the female body.
        meshes=[bpy.data.objects[name] for name in created_names
                if name in bpy.data.objects and bpy.data.objects[name].type=='MESH'
                and 'skeleton' not in name.lower()]
        if self.gender=='FEMALE':
            # The supplied Collada includes five alternative LOD body meshes.
            # Retain only the highest-detail reference, not five overlapping bodies.
            preferred=next((o for o in meshes if 'meshbody_classic_f_high' in o.name.lower()),None)
            if preferred is None:
                preferred=max(meshes,key=lambda o:len(o.data.vertices),default=None)
            for other in list(meshes):
                if other is not preferred:
                    bpy.data.objects.remove(other,do_unlink=True)
            meshes=[preferred] if preferred else []
        if not meshes:
            self.report({'ERROR'},'No body mesh found in included avatar');return {'CANCELLED'}
        # Remove auxiliary imports by name, re-resolving only live objects.
        keep_names={obj.name for obj in meshes}
        for name in created_names:
            if name not in keep_names:
                imported=bpy.data.objects.get(name)
                if imported is not None:
                    bpy.data.objects.remove(imported,do_unlink=True)
        # Give included reference bodies a soft, visible flesh tone in Solid view.
        skin_name='NWCS Female Skin' if self.gender=='FEMALE' else 'NWCS Male Skin'
        skin_color=(0.72, 0.43, 0.32, 1.0) if self.gender=='FEMALE' else (0.65, 0.39, 0.29, 1.0)
        skin=bpy.data.materials.get(skin_name)
        if skin is None:
            skin=bpy.data.materials.new(skin_name)
        skin.diffuse_color=skin_color
        skin.use_nodes=True
        principled=skin.node_tree.nodes.get('Principled BSDF')
        if principled:
            principled.inputs['Base Color'].default_value=skin_color
        for obj in meshes:
            obj.color=skin_color
            obj.data.materials.clear()
            obj.data.materials.append(skin)
            for polygon in obj.data.polygons:
                polygon.material_index=0
        # Make material colors visible in Blender's Solid viewport.
        for screen in bpy.data.screens:
            for area in screen.areas:
                if area.type=='VIEW_3D':
                    space=area.spaces.active
                    if space.shading.type=='SOLID':
                        space.shading.color_type='MATERIAL'
        # Apply the imported armature deformation before detaching the mesh.
        for obj in meshes:
            try:
                deps=context.evaluated_depsgraph_get()
                ev=obj.evaluated_get(deps)
                frozen=bpy.data.meshes.new_from_object(ev,preserve_all_data_layers=True,depsgraph=deps)
                if frozen:
                    old=obj.data;obj.data=frozen
            except Exception:pass
            for mod in list(obj.modifiers):
                if mod.type=='ARMATURE':obj.modifiers.remove(mod)
            # Keep the world-space pose when removing imported parenting.
            world_matrix=obj.matrix_world.copy()
            obj.parent=None
            obj.matrix_world=world_matrix
            obj.name='Female' if self.gender=='FEMALE' else 'Male'
            obj['nwcs_reference_import']=True
            if self.gender=='FEMALE':
                nwcs_remove_female_specks(obj)
            # new_from_object can replace the material slots; restore flesh after freezing.
            obj.data.materials.clear()
            obj.data.materials.append(skin)
            obj.color=skin_color
            for poly in obj.data.polygons: poly.material_index=0
            obj['nwcs_reference_avatar']=True
            # Normalize both supplied OBJ coordinate systems to Blender Z-up.
            # Male OBJ: Y-up, arms X. Female OBJ: Z-up, arms Y.
            from math import pi
            from mathutils import Matrix, Vector
            if self.gender=='MALE':
                obj.matrix_world = Matrix.Rotation(pi/2, 4, 'X') @ obj.matrix_world
            else:
                # Female FBX exported in the desired pose. Preserve its orientation.
                pass
            context.view_layer.update()
            world_verts=[obj.matrix_world @ v.co for v in obj.data.vertices]
            if world_verts:
                xmin=min(v.x for v in world_verts); xmax=max(v.x for v in world_verts)
                ymin=min(v.y for v in world_verts); ymax=max(v.y for v in world_verts)
                zmin=min(v.z for v in world_verts)
                obj.matrix_world.translation += Vector((-(xmin+xmax)/2, -(ymin+ymax)/2, -zmin))
            if self.gender=='MALE':
                # Original unmodified A-pose; smooth shading hides faceted normals.
                for face in obj.data.polygons:face.use_smooth=True
                if len(obj.data.polygons)<150000:
                    sub=obj.modifiers.new('NWCS Reference Surface Smoothing','SUBSURF')
                    sub.levels=1
                    sub.render_levels=1
            else:
                for face in obj.data.polygons:face.use_smooth=True
        body=max(meshes,key=lambda o:len(o.data.vertices))
        nwcs_remove_previous_reference(context, body)
        context.scene.nwcs_props.reference_body=body
        bpy.ops.object.select_all(action='DESELECT')
        body.select_set(True);context.view_layer.objects.active=body
        self.report({'INFO'},self.gender.title()+' reference loaded')
        return {'FINISHED'}

class NWCS_OT_use_selected_avatar(bpy.types.Operator):
    bl_idname='nwcs.use_selected_avatar'
    bl_label='Use Selected Mesh as Avatar'
    bl_description='Use the currently selected mesh as the clothing reference (import OBJ, DAE, or FBX through Blender first)'
    bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        obj=context.active_object
        if obj is None or obj.type!='MESH':
            self.report({'ERROR'},'Select a mesh body in the viewport or Outliner first')
            return {'CANCELLED'}
        nwcs_remove_previous_reference(context, obj)
        obj['nwcs_reference_avatar']=True
        context.scene.nwcs_props.reference_body=obj
        self.report({'INFO'},'Reference avatar set to '+obj.name)
        return {'FINISHED'}

class NWCS_OT_toggle_reference_avatar(bpy.types.Operator):
    bl_idname='nwcs.toggle_reference_avatar'
    bl_label='Hide / Show Reference Avatar'
    bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        obj=context.scene.nwcs_props.reference_body
        if not obj:
            self.report({'WARNING'},'Select a reference avatar first')
            return {'CANCELLED'}
        obj.hide_set(not obj.hide_get())
        return {'FINISHED'}

class NWCS_PT_panel(bpy.types.Panel):
    bl_label='Neverworld Clothing Creator'
    bl_idname='NWCS_PT_panel'
    bl_space_type='VIEW_3D'
    bl_region_type='UI'
    bl_category='Neverworld'
    def draw(self,context):
        self.layout.label(text='Design  >  Rings  >  Create  >  Simulate  >  Finish')

class NWCS_PT_setup(bpy.types.Panel):
    bl_label='1. Clothing Type'
    bl_idname='NWCS_PT_setup'
    bl_parent_id='NWCS_PT_panel'
    bl_space_type='VIEW_3D'
    bl_region_type='UI'
    def draw(self,context):
        l=self.layout;p=context.scene.nwcs_props
        l.label(text='Included reference bodies or your own imported mesh')
        row=l.row(align=True)
        op=row.operator('nwcs.load_reference_avatar',text='Female');op.gender='FEMALE'
        op=row.operator('nwcs.load_reference_avatar',text='Male');op.gender='MALE'
        l.operator('nwcs.use_selected_avatar',text='Use Selected Mesh as Avatar',icon='OUTLINER_OB_MESH')
        l.prop(p,'reference_body',text='Avatar Reference')
        l.operator('nwcs.toggle_reference_avatar',text='Hide / Show Avatar',icon='HIDE_OFF')
        l.prop(p,'preset',text='Garment')
        if p.preset=='CARDIGAN':
            l.prop(p,'cardigan_opening');l.prop(p,'cardigan_hem')
        elif p.preset=='BRA':
            l.prop(p,'cup_coverage');l.prop(p,'strap_width')
        elif p.preset=='CORSET':
            l.prop(p,'corset_lace_gap');l.prop(p,'corset_v_depth');l.prop(p,'corset_fit_offset')
        elif p.preset=='BIKINI':
            l.label(text='Original FBX mesh - no auto fitting')
            for name in ('bikini_stretch_x','bikini_stretch_y','bikini_stretch_z'):
                l.prop(p,name,slider=True)
        elif p.preset in {'BOXER_BRIEFS','BOXER_SHORTS'}:
            l.label(text='Pants-based thigh and leg rings')
        elif p.preset=='TSHIRT':
            l.prop(p,'tshirt_fit');l.prop(p,'tshirt_neck')
        elif p.preset=='SWEATER':
            for x in ('sweater_fit','sweater_neck','sweater_sleeves','sweater_cuffs','sweater_crop'):l.prop(p,x)
            if p.sweater_crop:l.prop(p,'sweater_crop_height',slider=True)
        elif p.preset=='TANK':
            l.prop(p,'tank_neckline');l.prop(p,'tank_neck_depth')
        elif p.preset=='DRESS':
            for x in ('dress_style','dress_length','dress_neckline','dress_sleeves','dress_pleats'):l.prop(p,x)
            if p.dress_pleats:
                l.prop(p,'pleat_count');l.prop(p,'pleat_depth')
            l.prop(p,'ruffle_style')
            if p.ruffle_style!='NONE':
                for x in ('ruffle_count','ruffle_depth','ruffle_height'):l.prop(p,x)
        elif p.preset=='PANTS':
            for x in ('pants_style','pants_waist','pants_length'):l.prop(p,x)
        else:
            l.prop(p,'pleat_style');l.prop(p,'skirt_fullness')
            if p.pleat_style=='PLEATED':l.prop(p,'pleat_count');l.prop(p,'pleat_depth')
            if p.preset in {'MINI','LONG'}:
                l.prop(p,'ruffle_style')
                if p.ruffle_style!='NONE':
                    for x in ('ruffle_count','ruffle_depth','ruffle_height'):l.prop(p,x)

class NWCS_PT_production(bpy.types.Panel):
    bl_label='2. Control Rings'
    bl_idname='NWCS_PT_production'
    bl_parent_id='NWCS_PT_panel'
    bl_space_type='VIEW_3D'
    bl_region_type='UI'
    def draw(self,context):
        l=self.layout;p=context.scene.nwcs_props
        if p.preset=='BIKINI':
            l.label(text='Original FBX panties use Stretch controls above')
        else:
            l.operator('nwcs.make_rings',text='Create Rings',icon='MESH_CIRCLE')
        if p.preset!='BIKINI':
            l.label(text='Select a ring to move or scale it')
        if p.preset in {'MINI','LONG','DRESS','PANTS'}:
            l.operator('nwcs.fit_waist',text='Fit Waist Ring',icon='SNAP_ON')
        l.separator()
        l.operator('nwcs.build_garment',text='Create Garment',icon='MOD_CLOTH')
        l.operator('nwcs.clear_garment_only',text='Clear Garment',icon='TRASH')
        l.operator('nwcs.remove_drafts',text='Clear Current Garment and Rings',icon='TRASH')
        l.operator('nwcs.clear_studio',text='Start Over',icon='TRASH')
        if p.preset=='CORSET':
            box=l.box();box.label(text='After Creating Corset')
            box.prop(p,'corset_post_fit')
            box.operator('nwcs.corset_gentle_fit',text='Gentle Fit Sides / Back',icon='MOD_SHRINKWRAP')
        if p.preset in {'MINI','LONG','DRESS','PANTS','BOXER_BRIEFS','BOXER_SHORTS'}:
            box=l.box();box.label(text='Waist Fit')
            for x in ('waist_fit_offset','conform_clearance','conform_rows'):box.prop(p,x)
            if p.preset in {'MINI','LONG'}:box.operator('nwcs.conform_waist')
            if p.preset in {'MINI','LONG','PANTS','BOXER_BRIEFS','BOXER_SHORTS'}:
                box.operator('nwcs.conform_waist_any',text='Shrinkwrap Waist to Body')

class NWCS_OT_add_body_collision(bpy.types.Operator):
    bl_idname='nwcs.add_body_collision'
    bl_label='Add Collision to Body'
    bl_description='Add Blender Collision physics to the selected avatar body (or the Avatar reference body)'
    bl_options={'REGISTER','UNDO'}

    def execute(self,context):
        p=context.scene.nwcs_props
        active=context.active_object
        # Prefer the explicitly selected mesh body, but never apply collision
        # to a generated cloth garment or a control-ring mesh.
        body=active if (active and active.type=='MESH' and not
            active.get('nwcs_sim_ready') and not active.get('nwcs_frozen') and
            not any(m.type=='CLOTH' for m in active.modifiers) and
            not active.name.startswith('NWCS_')) else p.reference_body
        if not body or body.type!='MESH':
            self.report({'ERROR'},'Select an avatar body mesh or set Avatar in Clothing Type')
            return {'CANCELLED'}
        existing=next((m for m in body.modifiers if m.type=='COLLISION'),None)
        if existing:
            existing.show_viewport=True
            existing.show_render=True
            self.report({'INFO'},f'Collision already enabled on {body.name}')
            return {'FINISHED'}
        modifier=body.modifiers.new('NWCS Body Collision','COLLISION')
        modifier.show_viewport=True
        modifier.show_render=True
        self.report({'INFO'},f'Added Collision to {body.name}')
        return {'FINISHED'}

class NWCS_PT_simulation(bpy.types.Panel):
    bl_label='3. Simulate'
    bl_idname='NWCS_PT_simulation'
    bl_parent_id='NWCS_PT_panel'
    bl_space_type='VIEW_3D'
    bl_region_type='UI'
    def draw(self,context):
        l=self.layout;p=context.scene.nwcs_props
        if p.preset=='BIKINI':
            l.label(text='Not used for original FBX panties')
            l.label(text='Adjust Stretch sliders in Clothing Type')
            return
        l.prop(p,'fabric')
        l.prop(p,'cloth_stiffness',slider=True)
        l.prop(p,'fabric_weight',slider=True)
        l.prop(p,'prefit_shrinkwrap')
        if p.prefit_shrinkwrap:l.prop(p,'prefit_offset')
        if p.preset in {'TANK','SLEEVELESS','TSHIRT','SWEATER','DRESS'}:l.prop(p,'neckline_hold',slider=True)
        if p.preset in {'DRESS','SWEATER'}:l.prop(p,'fabric_drape')
        l.operator('nwcs.add_body_collision',text='Add Collision to Body',icon='MOD_PHYSICS')
        l.operator('nwcs.validate_cloth',text='Validate & Prepare Cloth',icon='CHECKMARK')
        row=l.row(align=True)
        row.operator('nwcs.start_sim',text='Simulate',icon='PLAY')
        row.operator('nwcs.stop_sim',text='Stop',icon='PAUSE')
        l.operator('nwcs.reset_sim',text='Restart Simulation',icon='FILE_REFRESH')
        # Finishing is now the freeze action; see section 4 below.
        l.separator()
        l.label(text='Edit Mode: select garment vertices')
        row=l.row(align=True)
        row.operator('nwcs.pin_selection',text='Pin Selection',icon='PINNED')
        row.operator('nwcs.pin_selection',text='Unpin Selection',icon='UNPINNED').unpin=True

class NWCS_OT_rename_garment(bpy.types.Operator):
    bl_idname='nwcs.rename_garment'
    bl_label='Rename Garment'
    bl_description='Give the selected garment a new object name; keep its geometry, weights and materials'
    bl_options={'REGISTER','UNDO'}
    new_name: bpy.props.StringProperty(name='Garment Name',default='')
    target_name: bpy.props.StringProperty(options={'HIDDEN','SKIP_SAVE'})

    @staticmethod
    def is_garment(context,ob):
        return bool(ob and ob.type=='MESH' and (ob.get('nwcs_generated') or
            ob.get('nwcs_rigged') or ob==context.scene.nwcs_rig_settings.garment))

    @classmethod
    def poll(cls,context):
        return cls.is_garment(context,context.active_object)

    def invoke(self,context,event):
        self.target_name=context.active_object.name
        self.new_name=self.target_name
        return context.window_manager.invoke_props_dialog(self,width=360)

    def draw(self,context):
        self.layout.prop(self,'new_name')

    def execute(self,context):
        ob=bpy.data.objects.get(self.target_name) if self.target_name else context.active_object
        if not self.is_garment(context,ob):
            self.report({'ERROR'},'Select the garment to rename');return {'CANCELLED'}
        name=self.new_name.strip()
        if not name:
            self.report({'ERROR'},'Enter a garment name');return {'CANCELLED'}
        if ob.get('nwcs_frozen') and not ob.get('nwcs_preset'):
            source=bpy.data.objects.get(ob.name.rsplit('_Frozen',1)[0])
            if source and source.get('nwcs_preset'):ob['nwcs_preset']=source['nwcs_preset']
        ob.name=name
        self.report({'INFO'},'Garment renamed to '+ob.name)
        return {'FINISHED'}

class NWCS_PT_finishing(bpy.types.Panel):
    bl_label='4. Finish'
    bl_idname='NWCS_PT_finishing'
    bl_parent_id='NWCS_PT_panel'
    bl_space_type='VIEW_3D'
    bl_region_type='UI'
    def draw(self,context):
        l=self.layout
        l.operator('nwcs.optimize_export',text='Optimize for Upload (<100K)',icon='MOD_DECIM')
        l.operator('nwcs.repair_frozen_spikes',text='Fix Geometry Spikes',icon='MOD_SMOOTH')
        l.operator('nwcs.finish_or_freeze',text='Finish Garment',icon='CHECKMARK')
        l.operator('nwcs.auto_uv',text='Create / Repair UV',icon='UV')
        l.operator('nwcs.rename_garment',text='Rename Garment',icon='GREASEPENCIL')

def nwcs_pattern_size_changed(settings,context):
    ob=getattr(context,'active_object',None)
    if not ob or ob.type!='MESH':return
    materials=list(ob.data.materials)
    cached=bpy.data.materials.get(ob.get('nwcs_fabric_source',''))
    if cached and cached not in materials:materials.append(cached)
    for material in materials:
        if material and material.use_nodes:
            for node in material.node_tree.nodes:
                if node.type=='MAPPING' and node.get('nwcs_pattern_scale'):
                    node.inputs['Scale'].default_value=(1./settings.pattern_size,1./settings.pattern_size,1.)

def nwcs_prepare_pattern_mapping(material,image_node,size,uv_name=''):
    nodes=material.node_tree.nodes;links=material.node_tree.links
    mapping=next((n for n in nodes if n.type=='MAPPING' and n.get('nwcs_pattern_scale')),None)
    if mapping is None:
        mapping=nodes.new('ShaderNodeMapping');mapping.name='NWCS Pattern Size';mapping['nwcs_pattern_scale']=True
        vector=image_node.inputs['Vector']
        if vector.is_linked:links.new(vector.links[0].from_socket,mapping.inputs['Vector'])
        else:
            coords=nodes.new('ShaderNodeUVMap');coords.uv_map=uv_name
            links.new(coords.outputs['UV'],mapping.inputs['Vector'])
        links.new(mapping.outputs['Vector'],vector)
    mapping.inputs['Scale'].default_value=(1./size,1./size,1.)
    image_node.extension='REPEAT'

def nwcs_baked_material(image,name,uv_name=''):
    material=bpy.data.materials.new(name);material.use_nodes=True
    nodes=material.node_tree.nodes;shader=nodes.get('Principled BSDF')
    shader.inputs['Roughness'].default_value=.65
    texture=nodes.new('ShaderNodeTexImage');texture.name='NWCS Baked Texture';texture.image=image
    coordinates=nodes.new('ShaderNodeUVMap');coordinates.uv_map=uv_name
    material.node_tree.links.new(coordinates.outputs['UV'],texture.inputs['Vector'])
    material.node_tree.links.new(texture.outputs['Color'],shader.inputs['Base Color'])
    nodes.active=texture
    return material

def nwcs_fill_pattern_background(image,material,settings):
    """Fill unused atlas space with the same fabric at the same UV scale."""
    import numpy as np
    from mathutils import Euler
    width,height=image.size
    texture=None;mapping=None
    if material and material.use_nodes:
        nodes=material.node_tree.nodes
        texture=nodes.get('NWCS_Paint_Image')
        if not texture or texture.type!='TEX_IMAGE' or not texture.image:
            texture=next((n for n in nodes if n.type=='TEX_IMAGE' and n.image),None)
        if texture and texture.inputs['Vector'].is_linked:
            candidate=texture.inputs['Vector'].links[0].from_node
            if candidate.type=='MAPPING':mapping=candidate
    source=texture.image if texture else None
    result=np.empty((height,width,4),dtype=np.float32)
    if source and source.size[0] and source.size[1]:
        sw,sh=source.size
        pixels=np.empty(sw*sh*4,dtype=np.float32);source.pixels.foreach_get(pixels);pixels=pixels.reshape((sh,sw,4))
        transform=Matrix.Identity(4)
        if mapping:
            transform=Matrix.Translation(Vector(mapping.inputs['Location'].default_value))@Euler(tuple(mapping.inputs['Rotation'].default_value)).to_matrix().to_4x4()@Matrix.Diagonal((*mapping.inputs['Scale'].default_value,1.))
        base_u=(np.arange(width,dtype=np.float32)+.5)/width
        for row in range(0,height,128):
            end=min(height,row+128)
            base_v=((np.arange(row,end,dtype=np.float32)+.5)/height)[:,None]
            u=transform[0][0]*base_u[None,:]+transform[0][1]*base_v+transform[0][3]
            v=transform[1][0]*base_u[None,:]+transform[1][1]*base_v+transform[1][3]
            x=(u%1.)*sw-.5;y=(v%1.)*sh-.5
            ix=np.floor(x).astype(np.int32);iy=np.floor(y).astype(np.int32)
            fx=(x-ix)[...,None];fy=(y-iy)[...,None]
            result[row:end]=(pixels[iy%sh,ix%sw]*(1-fx)*(1-fy)+pixels[iy%sh,(ix+1)%sw]*fx*(1-fy)+pixels[(iy+1)%sh,ix%sw]*(1-fx)*fy+pixels[(iy+1)%sh,(ix+1)%sw]*fx*fy)
    else:
        color=tuple(settings.base_color)
        if material and material.use_nodes:
            shader=material.node_tree.nodes.get('Principled BSDF')
            if shader:color=tuple(shader.inputs['Base Color'].default_value)
        result[:]=color
    image.pixels.foreach_set(result.ravel());image.update()

def nwcs_bake_shape_accents(context,ob,resolution,uv_name,strength):
    """Diffuse UV silhouette shading; never draw raw triangle/UV edge lines."""
    import numpy as np
    uv_data=ob.data.uv_layers[uv_name].data
    coverage=np.zeros((resolution,resolution),dtype=np.bool_)
    for tri in ob.data.loop_triangles:
        coords=np.array([(uv_data[i].uv.x,uv_data[i].uv.y)
                         for i in tri.loops],dtype=np.float64)*resolution
        a,b,c=coords
        determinant=(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
        if abs(determinant)<1.e-8:continue
        x0=max(0,int(np.floor(coords[:,0].min()-.5)))
        x1=min(resolution,int(np.ceil(coords[:,0].max()-.5))+1)
        y0=max(0,int(np.floor(coords[:,1].min()-.5)))
        y1=min(resolution,int(np.ceil(coords[:,1].max()-.5))+1)
        if x1<=x0 or y1<=y0:continue
        yy,xx=np.ogrid[y0:y1,x0:x1]
        px=xx+.5-a[0];py=yy+.5-a[1]
        u=(px*(c[1]-a[1])-py*(c[0]-a[0]))/determinant
        v=(py*(b[0]-a[0])-px*(b[1]-a[1]))/determinant
        coverage[y0:y1,x0:x1] |= (u>=-1.e-6)&(v>=-1.e-6)&(u+v<=1.+1.e-6)
    if not np.any(coverage):
        raise ValueError('UV island rasterization produced no pixels; repair UV first')
    # Use a broad inward gradient rather than an edge stroke. Four-neighbor
    # erosion avoids the staircase artifacts of the old eight-neighbor mask.
    width=max(24,min(96,int(round(resolution*.055))))
    remaining=coverage.copy()
    gradient=np.zeros((resolution,resolution),dtype=np.float32)
    for step in range(width):
        p=np.pad(remaining,1,mode='constant',constant_values=False)
        inner=(p[1:-1,1:-1]&p[:-2,1:-1]&p[2:,1:-1]&
               p[1:-1,:-2]&p[1:-1,2:])
        edge=remaining & ~inner
        t=step/float(width)
        # Smooth cosine-like falloff with no narrow black outline.
        gradient[edge]=(1.-t*t*(3.-2.*t))
        remaining=inner
        if not np.any(remaining):break
    # Gaussian blur removes pixel-level/jagged edge outlines. Restrict
    # the final compositing to inside the islands only.
    sigma=max(3.,resolution*.008)
    radius=int(round(sigma*3))
    offsets=np.arange(-radius,radius+1,dtype=np.float32)
    kernel=np.exp(-.5*(offsets/sigma)**2);kernel/=kernel.sum()
    for axis in (0,1):
        pad=[(0,0),(0,0)];pad[axis]=(radius,radius)
        padded=np.pad(gradient,pad,mode='edge')
        blurred=np.zeros_like(gradient)
        for k,weight in enumerate(kernel):
            if axis==0:blurred+=weight*padded[k:k+resolution,:]
            else:blurred+=weight*padded[:,k:k+resolution]
        gradient=blurred
    gradient*=coverage
    # Diffuse shading, not a dark contour. Strength slider still works.
    return (1.-(.34*strength)*gradient).ravel()

def nwcs_pack_opaque_jpg(image):
    import tempfile,os
    with tempfile.TemporaryDirectory(prefix='nwcs_jpg_') as directory:
        path=os.path.join(directory,'Baked_Texture.jpg')
        image.filepath_raw=path;image.file_format='JPEG';image.save()
        with open(path,'rb') as file:data=file.read()
        image.pack(data=data,data_len=len(data))
    image.filepath_raw='//'+bpy.path.clean_name(image.name)+'.jpg'

class NWCS_OT_bake_pack_texture(bpy.types.Operator):
    bl_idname='nwcs.bake_pack_texture'
    bl_label='Bake & Pack Texture'
    bl_description='Bake the material colors over a flat fabric background and pack an opaque JPG for textured export'
    bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        ob=context.active_object
        if not ob or ob.type!='MESH' or not (ob.get('nwcs_generated') or ob.get('nwcs_rigged') or ob==context.scene.nwcs_rig_settings.garment):
            self.report({'ERROR'},'Select a finished garment first');return {'CANCELLED'}
        if context.mode!='OBJECT':
            self.report({'ERROR'},'Switch to Object Mode first');return {'CANCELLED'}
        if any(m.type=='CLOTH' for m in ob.modifiers):
            self.report({'ERROR'},'Finish the garment before baking');return {'CANCELLED'}
        if not ob.data.uv_layers.active:
            self.report({'ERROR'},'Create / Repair UV before baking');return {'CANCELLED'}
        if ob.data.users>1:
            self.report({'ERROR'},'Make the garment mesh single-user before baking');return {'CANCELLED'}
        scene=context.scene;settings=scene.nwcs_texture_settings
        original_materials=list(ob.data.materials)
        fabric_materials=original_materials
        cached=bpy.data.materials.get(ob.get('nwcs_fabric_source',''))
        if cached and len(original_materials)==1 and original_materials[0] and original_materials[0].use_nodes and original_materials[0].node_tree.nodes.get('NWCS Baked Texture'):
            fabric_materials=[cached]
        slot_info=[(slot.link,slot.material) for slot in ob.material_slots]
        polygon_slots=[poly.material_index for poly in ob.data.polygons]
        selection=list(context.selected_objects);active=context.view_layer.objects.active
        engine=scene.render.engine;samples=scene.cycles.samples;device=scene.cycles.device
        modifier_states=[(m,m.show_render,m.show_viewport) for m in ob.modifiers]
        uv_name=ob.data.uv_layers.active.name
        ob.data.uv_layers.active.active_render=True
        sources=[];image=None;success=False;hidden=ob.hide_get();active_material=ob.active_material_index
        try:
            resolution=int(settings.resolution)
            image=bpy.data.images.new('NWCS_Baked_'+ob.name,width=resolution,height=resolution,alpha=True)
            image.generated_color=(0,0,0,0);image.file_format='PNG'
            nwcs_fill_pattern_background(image,fabric_materials[0] if fabric_materials else None,settings)
            import numpy as np
            background=np.empty(resolution*resolution*4,dtype=np.float32);image.pixels.foreach_get(background)
            background=background.reshape((-1,4))
            for source in fabric_materials or [None]:
                material=source.copy() if source else bpy.data.materials.new('NWCS Bake Source')
                material.use_nodes=True
                target=material.node_tree.nodes.new('ShaderNodeTexImage');target.image=image;target.name='NWCS Bake Target'
                material.node_tree.nodes.active=target
                for node in material.node_tree.nodes:node.select=(node==target)
                sources.append(material)
            ob.data.materials.clear()
            for material in sources:ob.data.materials.append(material)
            for poly,index in zip(ob.data.polygons,polygon_slots):poly.material_index=min(index,len(sources)-1)
            scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=1
            for modifier,render,viewport in modifier_states:modifier.show_render=False;modifier.show_viewport=False
            ob.hide_set(False)
            bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);context.view_layer.objects.active=ob
            context.view_layer.update()
            # For a prepared UV fabric, flattening its image/mapping onto
            # the same UV coordinates is the exact color bake. Keep the full
            # pattern instead of rendering duplicate shell faces over it.
            prepared=bool(len(fabric_materials)==1 and fabric_materials[0] and fabric_materials[0].use_nodes and fabric_materials[0].node_tree.nodes.get('NWCS_Paint_Image'))
            # The fabric atlas already contains the exact image colors. Baking
            # the surface again can stamp mesh folds, overlaps and unwanted
            # lighting-looking streaks into the fabric. For a single image-
            # based material, preserve the sampled flat atlas instead.
            image_based=bool(len(fabric_materials)==1 and fabric_materials[0] and
                fabric_materials[0].use_nodes and any(
                    n.type=='TEX_IMAGE' and n.image and n.name!='NWCS Bake Target'
                    for n in fabric_materials[0].node_tree.nodes))
            if prepared or image_based:
                pixels=background.copy()
            else:
                result=bpy.ops.object.bake(type='DIFFUSE',pass_filter={'COLOR'},margin=16,use_clear=True,use_selected_to_active=False,uv_layer=ob.data.uv_layers.active.name)
                if 'FINISHED' not in result:raise ValueError('Texture bake did not finish')
                pixels=np.empty(resolution*resolution*4,dtype=np.float32);image.pixels.foreach_get(pixels);pixels=pixels.reshape((-1,4))
                alpha=np.clip(pixels[:,3:4],0.,1.)
                pixels[:,:3]=pixels[:,:3]*alpha+background[:,:3]*(1.-alpha)
            if settings.bake_shape_accents and settings.accent_strength>0:
                factors=nwcs_bake_shape_accents(context,ob,resolution,uv_name,settings.accent_strength)
                pixels[:,:3]*=factors[:,None]
            pixels[:,3]=1.
            image.pixels.foreach_set(pixels.ravel());image.update()
            nwcs_pack_opaque_jpg(image)
            baked=nwcs_baked_material(image,'NWCS Baked '+ob.name,uv_name)
            ob.data.materials.clear();ob.data.materials.append(baked)
            for poly in ob.data.polygons:poly.material_index=0
            if prepared or image_based:
                fabric_materials[0].use_fake_user=True
                ob['nwcs_fabric_source']=fabric_materials[0].name
            ob['nwcs_baked_image']=image.name
            ob['nwcs_baked_uv']=uv_name
            ob['nwcs_paint_image']=image.name
            for area in (context.screen.areas if context.screen else []):
                if area.type=='IMAGE_EDITOR':area.spaces.active.image=image
                elif area.type=='VIEW_3D':area.spaces.active.shading.type='MATERIAL'
            success=True
            self.report({'INFO'},'Baked and packed '+str(resolution)+' x '+str(resolution)+' opaque JPG with patterned background; ready to export')
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'},'Bake failed: '+str(exc)[:180]);return {'CANCELLED'}
        finally:
            if not success:
                ob.data.materials.clear()
                for material in original_materials:ob.data.materials.append(material)
                for slot,(link,material) in zip(ob.material_slots,slot_info):slot.link=link;slot.material=material
                for poly,index in zip(ob.data.polygons,polygon_slots):poly.material_index=index
            for material in sources:
                if material.users==0:bpy.data.materials.remove(material)
            if not success and image and image.users==0:bpy.data.images.remove(image)
            scene.render.engine=engine;scene.cycles.samples=samples;scene.cycles.device=device
            for modifier,render,viewport in modifier_states:modifier.show_render=render;modifier.show_viewport=viewport
            ob.hide_set(hidden);ob.active_material_index=min(active_material,max(0,len(ob.data.materials)-1))
            bpy.ops.object.select_all(action='DESELECT')
            for selected in selection:
                if selected.name in context.view_layer.objects:selected.select_set(True)
            context.view_layer.objects.active=active;context.view_layer.update()


# Bundled, tileable textile images. All images are original procedural assets.
NWCS_FABRIC_ITEMS = [
    ('NONE','None / External Image','Use the Fabric Image field or plain base color'),
    ('cotton','Cotton','Woven cotton fibers'),('linen','Linen','Slubbed linen weave'),
    ('silk','Silk','Fine silk'),('satin','Satin','Smooth satin sheen'),
    ('velvet','Velvet','Short velvet pile'),('denim','Denim','Diagonal denim twill'),
    ('leather','Leather','Grained leather'),('wool','Wool','Woolen weave'),
    ('tweed','Tweed','Textured tweed'),('ribbed_knit','Ribbed Knit','Ribbed knit fabric'),
    ('gingham','Gingham','Checked cotton'),('tartan','Tartan Plaid','Woven plaid'),
    ('pinstripe','Pinstripe','Fine pinstripes'),('polka_dot','Polka Dots','Dotted fabric'),
    ('floral_jacquard','Floral Jacquard','Subtle floral woven motif'),
    ('herringbone','Herringbone','Herringbone weave')]

class NWCS_OT_texture_prepare(bpy.types.Operator):
    bl_idname = 'nwcs.texture_prepare'
    bl_label = 'Prepare Texture Painting'
    bl_description = 'Create a UV-aligned paint canvas on the selected garment, or use an existing fabric image'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        from pathlib import Path
        ob = context.active_object
        if not ob or ob.type != 'MESH' or not ob.get('nwcs_generated'):
            self.report({'ERROR'}, 'Select a finished Neverworld garment first')
            return {'CANCELLED'}
        if ob.mode != 'OBJECT':
            self.report({'ERROR'}, 'Switch to Object Mode first')
            return {'CANCELLED'}
        if not ob.data.uv_layers.active:
            result = bpy.ops.nwcs.auto_uv()
            if 'FINISHED' not in result or not ob.data.uv_layers.active:
                self.report({'ERROR'}, 'Create / Repair UV first')
                return {'CANCELLED'}
        settings = context.scene.nwcs_texture_settings
        ob.data.uv_layers.active.active_render=True
        img = None
        if settings.fabric_preset != 'NONE':
            import os
            path = os.path.join(os.path.dirname(__file__), 'fabric_library', settings.fabric_preset + '.png')
            if not Path(path).is_file():
                self.report({'ERROR'}, 'Bundled fabric image missing: ' + settings.fabric_preset)
                return {'CANCELLED'}
            try:
                source = bpy.data.images.load(path, check_existing=True)
                img = source.copy()
                img.name = 'NWCS_Paint_' + ob.name
                # Tint a separate copy, never the original library asset. This
                # ensures the existing flat background bake matches the fabric.
                import numpy as np
                pixels = np.empty(len(img.pixels), dtype=np.float32)
                img.pixels.foreach_get(pixels)
                pixels = pixels.reshape((-1,4))
                pixels[:,:3] *= np.asarray(settings.library_tint[:3], dtype=np.float32)
                img.pixels.foreach_set(pixels.ravel())
                img.update()
                img.pack()
            except Exception as exc:
                self.report({'ERROR'}, 'Could not prepare library fabric: ' + str(exc)[:100])
                return {'CANCELLED'}
        elif settings.fabric_path.strip():
            path = bpy.path.abspath(settings.fabric_path)
            if not Path(path).is_file():
                self.report({'ERROR'}, 'Fabric image file does not exist')
                return {'CANCELLED'}
            try:
                source = bpy.data.images.load(path, check_existing=True)
                img = source.copy()
                img.name = 'NWCS_Paint_' + ob.name
                img.pack()
            except Exception as exc:
                self.report({'ERROR'}, 'Could not load fabric image: ' + str(exc)[:100])
                return {'CANCELLED'}
        else:
            img = bpy.data.images.new('NWCS_Paint_' + ob.name, width=int(settings.resolution),
                                      height=int(settings.resolution), alpha=True)
            img.generated_color = tuple(settings.base_color)
            img.pack()
        mat = bpy.data.materials.new('NWCS_Painted_' + ob.name)
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        bsdf = nodes.get('Principled BSDF')
        tex = nodes.new('ShaderNodeTexImage')
        tex.name = 'NWCS_Paint_Image'
        tex.image = img
        tex.interpolation = 'Linear'
        nwcs_prepare_pattern_mapping(mat,tex,settings.pattern_size,ob.data.uv_layers.active.name)
        mat.node_tree.links.new(tex.outputs['Color'], bsdf.inputs['Base Color'])
        nodes.active = tex
        for node in nodes:
            node.select = (node == tex)
        ob.data.materials.clear()
        ob.data.materials.append(mat)
        ob.active_material_index = 0
        for area in (context.screen.areas if context.screen else []):
            if area.type == 'VIEW_3D':
                area.spaces.active.shading.type = 'MATERIAL'
            elif area.type == 'IMAGE_EDITOR':
                area.spaces.active.image = img
        ob['nwcs_paint_image'] = img.name
        if 'nwcs_baked_image' in ob:del ob['nwcs_baked_image']
        self.report({'INFO'}, 'Texture canvas ready. Paint on the garment; save the image in Image Editor > Image > Save As.')
        return {'FINISHED'}


class NWCS_PT_texture(bpy.types.Panel):
    bl_label = '5. Texture Preparation'
    bl_idname = 'NWCS_PT_texture'
    bl_parent_id = 'NWCS_PT_panel'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'

    def draw(self, context):
        layout = self.layout
        p = context.scene.nwcs_texture_settings
        layout.label(text='Select finished garment; create UV first')
        layout.label(text='Seamless Fabric Library')
        layout.prop(p, 'fabric_preset', text='Fabric')
        if p.fabric_preset != 'NONE':
            layout.prop(p, 'library_tint', text='Fabric Color')
            layout.label(text='Press Prepare Texture Space to apply selection')
        else:
            layout.prop(p, 'fabric_path', text='Fabric Image')
        layout.prop(p, 'resolution', text='Bake Resolution')
        layout.prop(p, 'base_color', text='Base Color')
        layout.operator('nwcs.texture_prepare', text='Prepare Texture Space', icon='BRUSH_DATA')
        layout.prop(p,'pattern_size',text='Pattern Size')
        layout.label(text='Larger value = larger pattern on clothing')
        layout.prop(p,'bake_shape_accents')
        if p.bake_shape_accents:layout.prop(p,'accent_strength',slider=True)
        layout.operator('nwcs.bake_pack_texture',icon='RENDER_STILL')
        layout.label(text='Baked output: JPG with full patterned background')
        layout.label(text='Packed texture is included when exporting')
        layout.label(text='Texture Paint: paint or stencil graphics on 3D mesh')
        layout.label(text='Image Editor > Image > Save As to export PNG')


class NWCS_TextureSettings(bpy.types.PropertyGroup):
    fabric_preset: EnumProperty(name='Fabric', items=NWCS_FABRIC_ITEMS, default='NONE',
        description='Choose a bundled seamless textile; overrides external Fabric Image')
    library_tint: bpy.props.FloatVectorProperty(name='Fabric Color', subtype='COLOR', size=4,
        min=0., max=1., default=(1.,1.,1.,1.), description='Multiply fabric colors; white preserves original')
    fabric_path: bpy.props.StringProperty(name='Fabric Image', subtype='FILE_PATH',
        description='Optional seamless fabric image to use as the starting canvas')
    resolution: bpy.props.EnumProperty(name='Resolution', items=[('512','512',''),('1024','1024',''),('2048','2048','')], default='1024')
    bake_shape_accents: BoolProperty(name='Baked Shape Accents',default=True,description='Add very subtle shading along UV island edges only')
    accent_strength: FloatProperty(name='Accent Strength',default=.95,min=0.,max=1.,subtype='FACTOR')
    pattern_size: FloatProperty(name='Pattern Size',default=1.,min=.1,max=10.,update=nwcs_pattern_size_changed,description='Make the prepared fabric pattern larger or smaller before baking')
    base_color: bpy.props.FloatVectorProperty(name='Base Color', subtype='COLOR', size=4,
        min=0.0, max=1.0, default=(0.14,0.14,0.14,1.0))


class NWCS_PT_export(bpy.types.Panel):
    bl_label='Advanced Tools'
    bl_idname='NWCS_PT_export'
    bl_parent_id='NWCS_PT_panel'
    bl_space_type='VIEW_3D'
    bl_region_type='UI'
    bl_options={'DEFAULT_CLOSED'}
    def draw(self,context):
        l=self.layout;p=context.scene.nwcs_props
        if p.preset!='BIKINI':
            box=l.box();box.label(text='Ring Geometry')
            for x in ('rings','ring_thickness','clearance'):
                box.prop(p,x)
            box.operator('nwcs.center_ring_origins',icon='OBJECT_ORIGIN')
            box.prop(p,'body_protection')
            if p.body_protection:
                box.prop(p,'body_min_gap')
                box.operator('nwcs.protect_rings',icon='MOD_SHRINKWRAP')
            if p.preset in {'TANK','SWEATER','DRESS','TSHIRT'}:
                box=l.box();box.label(text='Neckline Fine Tuning')
                for x in ('neckline_front_drop','neckline_tilt','neckline_side_tilt','neckline_rotation'):box.prop(p,x)
            if p.preset in {'SWEATER','TSHIRT','DRESS','CARDIGAN'}:l.prop(p,'mirror_sleeves')
            if p.preset in {'PANTS','BOXER_BRIEFS','BOXER_SHORTS'}:l.prop(p,'mirror_legs')
            box=l.box();box.label(text='Simulation Settings')
            box.prop(p,'pin_strength');box.prop(p,'sim_frames')
        box=l.box();box.label(text='Fabric Thickness')
        box.prop(p,'fabric_thickness')


# Optional fitted-garment generators. These produce editable mesh surfaces;
# no cloth modifier is applied to close-fitting underwear.
def nwcs_fitted_mesh(context, name, verts, faces, thickness=.002):
    me=bpy.data.meshes.new(name+' Mesh')
    me.from_pydata(verts, [], faces)
    me.update()
    ob=bpy.data.objects.new(name,me)
    context.collection.objects.link(ob)
    ob['nwcs_generated']=True
    ob['nwcs_fitted_preset']=True
    for poly in me.polygons:poly.use_smooth=True
    solid=ob.modifiers.new('Fabric Thickness','SOLIDIFY')
    solid.thickness=thickness
    solid.offset=0
    return ob

def nwcs_body_metrics(body,z):
    # Cross-section approximation from actual avatar mesh vertices near height.
    world=body.matrix_world
    coords=[world@v.co for v in body.data.vertices]
    lo=min(v.z for v in coords);hi=max(v.z for v in coords)
    near=[v for v in coords if abs(v.z-z)<max(.025,(hi-lo)*.035)]
    if len(near)<8:
        near=sorted(coords,key=lambda v:abs(v.z-z))[:max(16,len(coords)//40)]
    if not near:raise ValueError('Avatar mesh has no vertices')
    xs=sorted(v.x for v in near);ys=sorted(v.y for v in near)
    left=int((len(xs)-1)*.12);right=int((len(xs)-1)*.88)
    return ((xs[left]+xs[right])*.5,(ys[left]+ys[right])*.5,
            max(.035,(xs[right]-xs[left])*.5),
            max(.025,(ys[right]-ys[left])*.5))

def nwcs_strip(verts,faces,rows,close=False):
    n=len(rows[0]);base=len(verts)
    for row in rows:verts.extend(tuple(v) for v in row)
    for j in range(len(rows)-1):
        for i in range(n if close else n-1):
            k=(i+1)%n
            faces.append((base+j*n+i,base+j*n+k,base+(j+1)*n+k,base+(j+1)*n+i))

def nwcs_ellipse_band(verts,faces,body,zlevels,angle_start=0.,angle_end=2*math.pi,
                       samples=48,fit=1.035):
    rows=[]
    for z in zlevels:
        cx,cy,rx,ry=nwcs_body_metrics(body,z)
        rows.append([(cx+rx*fit*math.cos(angle_start+(angle_end-angle_start)*i/(samples if abs(angle_end-angle_start)>=2*math.pi-1e-5 else samples-1)),
                      cy+ry*fit*math.sin(angle_start+(angle_end-angle_start)*i/(samples if abs(angle_end-angle_start)>=2*math.pi-1e-5 else samples-1)),z)
                     for i in range(samples)])
    nwcs_strip(verts,faces,rows,abs(angle_end-angle_start)>=2*math.pi-1e-5)

def nwcs_tube(verts,faces,center,zlevels,rx,ry,n=24):
    rows=[[(center[0]+rx*math.cos(2*math.pi*i/n),
            center[1]+ry*math.sin(2*math.pi*i/n),z) for i in range(n)] for z in zlevels]
    nwcs_strip(verts,faces,rows,True)

def nwcs_fit_bra_cup_surface(body, vertices, start, end, depth, xcenter, radius_x, center_z, radius_z):
    """Fit cup front surface to actual breast surface, not torso bounding ellipse.

    Only cup vertices [start:end] are changed; underband/straps are untouched.
    Each vertex is raycast in +Y at its existing X/Z position. This preserves
    round projected cup geometry while following the breast contour.
    """
    try:
        dg = bpy.context.evaluated_depsgraph_get()
        bvh = BVHTree.FromObject(body, dg, epsilon=0.0)
    except Exception:
        return 0
    if bvh is None:
        return 0
    to_local = body.matrix_world.inverted_safe()
    to_world = body.matrix_world
    # Front-facing ray begins in front of the avatar's entire bounding box.
    front = min((body.matrix_world @ Vector(c)).y for c in body.bound_box)
    back = max((body.matrix_world @ Vector(c)).y for c in body.bound_box)
    ray_len = max(1., (back-front)*4.)
    hits = 0
    for i in range(start,end):
        x,y,z = vertices[i]
        origin = Vector((x,front-ray_len*.2,z))
        ray_end = Vector((x,back+ray_len*.2,z))
        local_start = to_local @ origin
        local_direction = (to_local @ ray_end)-local_start
        max_dist = local_direction.length
        if max_dist < 1e-8: continue
        hit,normal,face,dist = bvh.ray_cast(local_start,local_direction.normalized(),max_dist)
        if hit is None: continue
        surface_y = (to_world @ hit).y
        # Edge stays close to the breast, center has modest extra cup fullness.
        r2 = ((x-xcenter)/max(radius_x,1e-6))**2 + ((z-center_z)/max(radius_z,1e-6))**2
        bulge = max(0.,1.-min(1.,r2))**.5
        clearance = .006 + min(depth,.035)*.42*bulge
        vertices[i] = (x,surface_y-clearance,z)
        hits += 1
    return hits


def nwcs_import_user_bikini(context, body, p, hip=None, crotch=None):
    """Import the exact user FBX; no fitting, generated geometry or physics."""
    import os
    path=os.path.join(os.path.dirname(__file__), 'panties_user_mesh.fbx')
    if not os.path.isfile(path):
        raise ValueError('The supplied panties FBX is missing from the installed add-on')
    previous=set(bpy.data.objects)
    if context.object and context.object.mode!='OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.import_scene.fbx(filepath=path, use_anim=False)
    added=[ob for ob in bpy.data.objects if ob not in previous]
    meshes=[ob for ob in added if ob.type=='MESH' and len(ob.data.vertices)>0]
    if len(meshes)!=1:
        for ob in added:
            bpy.data.objects.remove(ob,do_unlink=True)
        raise ValueError('Expected one panties mesh in FBX; found %d' % len(meshes))
    ob=meshes[0]
    if len(ob.data.vertices)!=98131:
        for item in added:
            bpy.data.objects.remove(item,do_unlink=True)
        raise ValueError('Unexpected FBX vertex count: %d' % len(ob.data.vertices))
    # Preserve FBX-imported vertex coordinates, object transforms, faces,
    # materials, UVs and original silhouette. No normalization or shrinkwrap.
    # Parent transforms are kept, too, so Blender's import result stays exact.
    ob.name='NWCS Bikini Panties (Original FBX)'
    ob['nwcs_generated']=True
    ob['nwcs_fitted_preset']=True
    ob['nwcs_preset']='BIKINI'
    ob['nwcs_sim_ready']=False
    ob['nwcs_bikini_original_fbx']=True
    ob['nwcs_source_vertices']=98131
    ob['nwcs_bikini_base_scale']=list(ob.scale)
    ob.scale=(ob.scale.x*p.bikini_stretch_x,
              ob.scale.y*p.bikini_stretch_y,
              ob.scale.z*p.bikini_stretch_z)
    for item in added:
        if item != ob and item.type!='EMPTY':
            bpy.data.objects.remove(item,do_unlink=True)
    bpy.ops.object.select_all(action='DESELECT')
    ob.select_set(True)
    context.view_layer.objects.active=ob
    return ob

def nwcs_build_fitted(context,p):
    body=p.reference_body
    if not body or body.type!='MESH':raise ValueError('Choose an Avatar mesh first')
    z0,z1,cx,cy=body_bounds(body)
    h=z1-z0
    if h<=0:raise ValueError('Avatar has zero height')
    v=[];f=[]
    kind=p.preset
    required={'CARDIGAN':['Hem','Waist','Bust','Neckline'],
              'BRA':['Underband','Bust','StrapTop'],
              'CORSET':['Hem','Waist','Bust Support','Bust'],
              'BIKINI':['Crotch','Hip','Waist'],
              'BOXER_BRIEFS':['LegHem','Crotch','Waist'],
              'BOXER_SHORTS':['LegHem','Crotch','Waist']}[kind]
    missing=[label for label in required if bpy.data.objects.get(PREFIX+label) is None] if kind!='BIKINI' else []
    if missing:raise ValueError('Create Control Rings first: '+', '.join(missing))
    def ring_z(label):
        pts=ring_points(bpy.data.objects[PREFIX+label])
        return sum(Vector(v).z for v in pts)/len(pts)
    if kind=='BIKINI':
        return nwcs_import_user_bikini(context,body,p)
    if kind=='CARDIGAN':
        # Separate front edges, connected across the back. Front is -Y.
        zhem=ring_z('Hem')
        ztop=ring_z('Neckline')
        opening=math.radians(p.cardigan_opening)
        # Ellipse from front-right edge around the back to front-left edge.
        nwcs_ellipse_band(v,f,body,[zhem+(ztop-zhem)*j/18 for j in range(19)],
                          -math.pi/2+opening,3*math.pi/2-opening,64,1.085)
        # Two open sleeves. Shoulder positions follow the body at upper chest.
        zs=z0+h*.79
        bx,by,brx,bry=nwcs_body_metrics(body,zs)
        for sign in (-1,1):
            center=(bx+sign*brx*.91,by)
            nwcs_tube(v,f,center,[zs-h*.23,zs-h*.20,zs-h*.08,zs],
                      max(.025,brx*.33),max(.025,bry*.57),24)
    elif kind=='CORSET':
        # Fitted corset with an open center-front seam. The front is -Y.
        # All body surface points are evaluated independently; no cup scaling.
        zhem=ring_z('Hem'); zwaist=ring_z('Waist'); ztop=ring_z('Bust')
        zsupport=ring_z('Bust Support')
        if not (zwaist < zsupport < ztop):
            raise ValueError('Bust Support ring must be between Waist and Bust rings')
        if not (zhem < zwaist < ztop):
            raise ValueError('Corset rings must be ordered Hem, Waist, Bust')
        gap=p.corset_lace_gap
        # Two edges at the front, connected continuously around the back.
        # A narrow opening is retained between the two front panels.
        # At bust height the avatar's outstretched arms can contaminate the
        # cross-section measurement. Limit the corset's side radius to the
        # torso width derived below the armpits, never the arm span.
        _,_,waist_rx,waist_ry=nwcs_body_metrics(body,zwaist)
        _,_,lower_rx,_=nwcs_body_metrics(body,zhem)
        torso_side_limit=max(waist_rx,lower_rx)*1.08
        # Build a corset neckline from a torso-only guide, not a bust-height
        # cross section. At the underarms the avatar's arms contaminate the
        # width measurement, producing the outward horizontal flanges.
        samples=64; rows=[]
        zref=zwaist+(ztop-zwaist)*.42
        ref_bx,ref_by,ref_rx,ref_ry=nwcs_body_metrics(body,zref)
        # Side silhouette is interpolated from the waist and lower rib cage.
        # It must not flare wider than the torso as it approaches the armpit.
        safe_side_rx=min(torso_side_limit, max(waist_rx,ref_rx)*1.025)
        # Front of corset is -Y. Add smooth bust clearance in the front ONLY;
        # unlike a global ellipse enlargement this cannot create side wings.
        _,_,_,bust_ry=nwcs_body_metrics(body,ztop)
        safe_front_ry=max(ref_ry*1.12, min(bust_ry*1.12,ref_ry*1.50))
        edge_angle=math.asin(min(.65,gap/(2*max(safe_side_rx,.035))))
        # Extra bust-support ring between the waist and neckline. The band
        # must bulge over each breast, not simply project the center front.
        # More rings near the bust improve the curvature without changing
        # the side silhouette or the pointed lower hem.
        ring_t=[j/24 for j in range(25)]
        support_t=(zsupport-zhem)/(ztop-zhem)
        ring_t=sorted(set(ring_t+[.68,.73,.78,.83,.88,.93,.97,support_t]))
        support_pts=ring_points(bpy.data.objects[PREFIX+'Bust Support'])
        support_front=min(pt[1] for pt in support_pts)
        # Use the visible ring's frontmost point as a minimum bust projection.
        # Its shape and position can now be adjusted before Build Garment.
        for t in ring_t:
            z=zhem+(ztop-zhem)*t
            bx,by,rx,ry=nwcs_body_metrics(body,z)
            blend=max(0.,min(1.,(t-.48)/.52))
            blend=blend*blend*(3.-2.*blend)
            # Ignore arm-derived X extents in the upper torso completely.
            rx=rx*(1.-blend)+safe_side_rx*blend
            by=by*(1.-blend)+ref_by*blend
            bx=bx*(1.-blend)+ref_bx*blend
            ry=ry*(1.-blend)+ref_ry*blend
            row=[]
            for i in range(samples+1):
                a=-math.pi/2+edge_angle+(2*math.pi-2*edge_angle)*i/samples
                side=abs(math.cos(a))
                front=max(0.,-math.sin(a))
                # Underarm scoop: lower the edge, never push it outward.
                neckline=max(0.,(t-.70)/.30)
                neckline=neckline*neckline*(3.-2.*neckline)
                side_drop=min(.075,max(.022,(ztop-zwaist)*.36))*(side**6)*neckline
                # At the upper rows the breast allowance is a frontward
                # displacement only, smoothly disappearing at either side.
                bust_blend=max(0.,min(1.,(t-.50)/.50))
                bust_blend=bust_blend*bust_blend*(3.-2.*bust_blend)
                x=bx+(rx+p.corset_fit_offset)*math.cos(a)
                y=by+(ry+p.corset_fit_offset)*math.sin(a)
                # Two independent bust lobes. The old front**4 allowance
                # peaked at the lacing gap and left the breasts exposed.
                # Each breast receives its own forward dome, fading out at
                # the center lacing and at the underarm edges.
                lateral=abs(math.cos(a))
                breast_lobe=math.exp(-((lateral-.49)/.26)**2)
                breast_height=math.exp(-((t-.87)/.20)**2)
                bust_projection=max(.025, safe_front_ry-ref_ry)*1.55
                y-=bust_projection*breast_lobe*breast_height*(front**.65)
                support_weight=math.exp(-((t-support_t)/.12)**2)*breast_lobe*(front**.65)
                y-=max(0.,y-support_front)*support_weight
                # A modest central allowance keeps the lace edges from
                # cutting into the sternum, without pulling the side panels.
                y-=max(0.,safe_front_ry-ref_ry)*.25*bust_blend*(front**4)
                point=max(0.,(front-.45)/.55)**3
                zz=z-p.corset_v_depth*point*(1.-t)**3-side_drop
                row.append((x,y,zz))
            rows.append(row)
        # Gentle fairing of the top rim, keeping the front lacing ends fixed.
        # Do not smooth x positions into the side flanges or modify the waist.
        for j in range(max(0,len(rows)-5),len(rows)):
            for _ in range(2):
                old=[Vector(q) for q in rows[j]]
                for i in range(2,samples-1):
                    mid=(old[i-1]+old[i+1])*.5
                    rows[j][i]=tuple(old[i]*.85+mid*.15)
        nwcs_strip(v,f,rows,False)
        # The front panels stay open for lacing. Lace is separate material geometry,
        # arranged in alternating diagonal strips between the two front edges.
        lace_base=len(f)
        eyelet_count=9
        left=[];right=[]
        for k in range(eyelet_count):
            t=.12+.78*k/(eyelet_count-1)
            j=min(range(len(ring_t)),key=lambda idx:abs(ring_t[idx]-t))
            left.append(Vector(rows[j][0]));right.append(Vector(rows[j][-1]))
        def ribbon(a,b,width):
            d=b-a
            if d.length<1e-6:return
            side=Vector((0,0,1)).cross(d).normalized()*width*.5
            # Place cord just ahead of corset front to avoid z-fighting.
            off=Vector((0,-.005,0))
            k=len(v)
            v.extend([tuple(a+side+off),tuple(a-side+off),tuple(b-side+off),tuple(b+side+off)])
            f.append((k,k+1,k+2,k+3))
        for k in range(eyelet_count-1):
            ribbon(left[k],right[k+1],.003)
            ribbon(right[k],left[k+1],.003)
        # Narrow reinforced edges along the lacing opening.
        for side in (left,right):
            for k in range(len(side)-1):ribbon(side[k],side[k+1],.006)
        # Distinct material for laces, assigned after object creation.
        corset_lace_start=lace_base
    elif kind=='BRA':
        zband=ring_z('Underband')
        zcup=ring_z('Bust')
        zstrap=ring_z('StrapTop')
        bx,by,rx,ry=nwcs_body_metrics(body,zcup)
        # The band is generated independently. Cup Coverage NEVER scales the band.
        # Use a fixed band profile, and create each cup as a separate circular
        # patch with its own width/height/depth. This avoids the former stretched
        # horizontal half-ellipse and its pointed, oblong end rows.
        band_top=min(zband+h*.033, zcup-h*.012)
        if band_top<=zband+h*.006:band_top=zband+h*.012
        nwcs_ellipse_band(v,f,body,[zband-h*.014,zband,band_top],
                          0,2*math.pi,64,1.035)
        # Fit cup aspect ratio to the avatar, not to full avatar height.
        # A mild ellipse (rather than a flattened strip) gives rounded cups.
        available_height=max(.035,zstrap-band_top)
        cup_radius_x=max(.025,rx*.46)
        cup_radius_z=min(cup_radius_x*1.08,available_height*.76)
        cup_radius_z=max(cup_radius_x*.75,cup_radius_z)
        cup_radius_x*=p.cup_coverage
        cup_radius_z*=p.cup_coverage
        cup_center_z=max(band_top+cup_radius_z*.80, zcup)
        cup_center_z=min(cup_center_z,zstrap-cup_radius_z*.45)
        depth=max(.012,min(ry*.32,cup_radius_x*.48))
        for sign in (-1,1):
            xcenter=bx+sign*rx*.50
            # Front-facing rounded dome with 6 radial bands and 32 sectors.
            # Perimeter lies near the body; center bulges outwards (-Y).
            # No collapsed tip rows and no triangles of near-zero area.
            sectors=32
            rings=7
            cup_start=len(v)
            center_idx=len(v)
            v.append((xcenter,by-ry*1.045-depth,cup_center_z))
            perimeter=[]
            for j in range(1,rings+1):
                r=j/rings
                row=[]
                for i in range(sectors):
                    angle=2*math.pi*i/sectors
                    x=xcenter+cup_radius_x*r*math.cos(angle)
                    z=cup_center_z+cup_radius_z*r*math.sin(angle)
                    # Rounded projected dome: outer ring sits near the torso.
                    y=by-ry*1.045-depth*math.sqrt(max(0.,1-r*r))
                    row.append(len(v));v.append((x,y,z))
                perimeter.append(row)
            for i in range(sectors):
                f.append((center_idx,perimeter[0][i],perimeter[0][(i+1)%sectors]))
            for j in range(rings-1):
                inner=perimeter[j];outer=perimeter[j+1]
                for i in range(sectors):
                    k=(i+1)%sectors
                    f.append((inner[i],outer[i],outer[k],inner[k]))
            # Fit ONLY the cup patch against the actual breast surface.
            # Do not shrinkwrap the band, and do not add a live modifier.
            cup_hits=nwcs_fit_bra_cup_surface(body,v,cup_start,len(v),depth,
                                               xcenter,cup_radius_x,cup_center_z,cup_radius_z)
            # Strap width is independent of cup coverage and underband fit.
            width=max(.006,rx*.075*p.strap_width)
            x=xcenter
            pts=[(x,by-ry*1.045,cup_center_z+cup_radius_z*.90),
                 (x,by-ry*.73,zstrap),
                 (x,by+ry*.58,zstrap),
                 (x,by+ry*1.035,band_top)]
            nwcs_strip(v,f,[[(px-width/2,py,pz),(px+width/2,py,pz)]
                            for px,py,pz in pts])
    elif kind in {'BOXER_BRIEFS','BOXER_SHORTS'}:
        waist=ring_z('Waist')
        crotch=ring_z('Crotch')
        nwcs_ellipse_band(v,f,body,[crotch,waist-h*.02,waist],0,2*math.pi,64,
                          1.04 if kind=='BOXER_BRIEFS' else 1.14)
        bx,by,rx,ry=nwcs_body_metrics(body,crotch)
        for sign in (-1,1):
            leg_obj=bpy.data.objects.get(PREFIX+('L' if sign>0 else 'R')+'_LegHem')
            if leg_obj is None:raise ValueError('Create both boxer leg rings first')
            leg_pts=[Vector(pt) for pt in ring_points(leg_obj)]
            c=(sum(pt.x for pt in leg_pts)/len(leg_pts),sum(pt.y for pt in leg_pts)/len(leg_pts))
            leg_r=max(abs(pt.x-c[0]) for pt in leg_pts)
            nwcs_tube(v,f,c,[sum(pt.z for pt in leg_pts)/len(leg_pts),
                              crotch-h*.02,crotch],leg_r,ry*(.82 if kind=='BOXER_BRIEFS' else .94),32)
    else:raise ValueError('Unknown fitted garment')
    ob=nwcs_fitted_mesh(context,'NWCS '+dict(CARDIGAN='Open Cardigan',BRA='Classic Bra',CORSET='V-Front Laced Corset',
                          BIKINI='Bikini Panties',BOXER_BRIEFS='Boxer Briefs',
                          BOXER_SHORTS='Boxer Shorts')[kind],v,f)
    if kind=='CORSET':
        # The upper neckline is formed directly by smooth torso-only rings.
        # Do not shrinkwrap this rim to the avatar: near the armpits the
        # nearest surface may be an arm, creating spikes and breast dimples.
        ob.data.update()
        # Assign a contrasting dark lace material to the lacing strips.
        mat=bpy.data.materials.get('NWCS Corset Lacing')
        if mat is None:
            mat=bpy.data.materials.new('NWCS Corset Lacing')
            mat.diffuse_color=(.045,.025,.025,1)
        ob.data.materials.append(mat)
        for poly in ob.data.polygons:
            if poly.index>=corset_lace_start:poly.material_index=len(ob.data.materials)-1
    for o in context.selected_objects:o.select_set(False)
    ob.select_set(True);context.view_layer.objects.active=ob
    # UV unwrapping is deliberately deferred until the user invokes
    # Repair Garment UV after construction (or freezing a cloth garment).
    # Never run a UV operator in a garment-building code path.
    nwcs_finish_garment_transform(context,ob)
    return ob

class NWCS_OT_build_fitted(bpy.types.Operator):
    bl_idname='nwcs.build_fitted'
    bl_label='Create Fitted Garment'
    bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        try:
            obj=nwcs_build_fitted(context,context.scene.nwcs_props)
            self.report({'INFO'},'Created '+obj.name+' — adjust fit on your avatar')
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'},'Fitted garment: '+str(exc))
            return {'CANCELLED'}


def nwcs_accessory_target(context):
    obj=context.active_object
    if obj and obj.type=='MESH' and (obj.get('nwcs_generated') or obj.name.startswith('NWCS')):
        return obj
    candidates=[o for o in context.scene.objects if o.type=='MESH' and o.get('nwcs_generated')]
    if not candidates:raise ValueError('Select a finished NWCS garment first')
    return candidates[-1]

def nwcs_accessory_object(context,name,vertices,faces,target,p):
    mesh=bpy.data.meshes.new(name+' Mesh')
    mesh.from_pydata(vertices,[],faces);mesh.update()
    obj=bpy.data.objects.new(name,mesh)
    context.collection.objects.link(obj)
    obj['nwcs_accessory']=True
    for polygon in mesh.polygons:polygon.use_smooth=True
    if p.accessory_attach:
        obj.parent=target
        obj.matrix_parent_inverse=target.matrix_world.inverted_safe()
    return obj

def nwcs_accessory_strip(vertices,faces,points,width):
    start=len(vertices)
    for x,y,z in points:
        vertices.extend(((x-width*.5,y,z),(x+width*.5,y,z)))
    for i in range(len(points)-1):
        a=start+2*i;faces.append((a,a+1,a+3,a+2))



def nwcs_create_fitted_buttons(context,target,p):
    """Four real through-holes; orient each button to evaluated garment normals."""
    from mathutils.bvhtree import BVHTree
    depsgraph=context.evaluated_depsgraph_get()
    bvh=BVHTree.FromObject(target,depsgraph)
    if bvh is None:
        raise ValueError('Cannot sample garment surface; freeze/apply garment first')
    inv=target.matrix_world.inverted_safe()
    bounds=[Vector(c) for c in target.bound_box]
    minx,maxx=min(v.x for v in bounds),max(v.x for v in bounds)
    miny,maxy=min(v.y for v in bounds),max(v.y for v in bounds)
    minz,maxz=min(v.z for v in bounds),max(v.z for v in bounds)
    zmid=minz+(maxz-minz)*p.accessory_height
    length=min(maxz-minz,p.accessory_length)
    top=min(maxz,zmid+length*.5)
    bottom=max(minz,zmid-length*.5)
    count=p.accessory_count
    radius=p.accessory_size*.5
    thickness=max(radius*.23,.0007)
    created=[]
    for j in range(count):
        z=top if count==1 else top+(bottom-top)*j/(count-1)
        # The garment is modeled with its front toward -Y.
        origin=Vector(((minx+maxx)*.5,miny-max(.12,maxy-miny),z))
        location,normal,face,distance=bvh.ray_cast(origin,Vector((0,1,0)),max(.5,(maxy-miny)*3))
        if location is None:
            # Skip a gap (e.g. open cardigan) instead of placing a floating button.
            continue
        normal=normal.normalized()
        if normal.y>0:normal.negate()
        # Button local Z faces outward; local Y tracks the garment's vertical.
        vertical=Vector((0,0,1))
        vertical=(vertical-normal*vertical.dot(normal)).normalized()
        if vertical.length<.1:vertical=Vector((0,1,0))
        horizontal=vertical.cross(normal).normalized()
        vertical=normal.cross(horizontal).normalized()
        from mathutils import Matrix
        rotation=Matrix(((horizontal.x,vertical.x,normal.x),
                         (horizontal.y,vertical.y,normal.y),
                         (horizontal.z,vertical.z,normal.z))).to_4x4()
        # Build in garment local coordinates so parenting tracks garment transforms.
        center=location+normal*(p.accessory_offset+thickness*.5)
        matrix=Matrix.Translation(center) @ rotation
        # Cylinder with bevelled outer edge.
        bpy.ops.mesh.primitive_cylinder_add(vertices=32,radius=radius,depth=thickness,location=(0,0,0))
        button=context.object
        button.name='NWCS Button %02d'%(j+1)
        button.matrix_world=target.matrix_world @ matrix
        bevel=button.modifiers.new('Raised rounded edge','BEVEL')
        bevel.width=min(thickness*.45,radius*.16)
        bevel.segments=3
        bpy.ops.object.modifier_apply(modifier=bevel.name)
        # Four actual holes drilled with a single Boolean operation.
        hole_r=radius*.105
        pitch=radius*.32
        cutters=[]
        for hx in (-pitch,pitch):
            for hy in (-pitch,pitch):
                bpy.ops.mesh.primitive_cylinder_add(vertices=12,radius=hole_r,
                    depth=thickness*5,location=(0,0,0))
                cutter=context.object
                cutter.matrix_world=button.matrix_world @ Matrix.Translation(Vector((hx,hy,0)))
                cutters.append(cutter)
        bpy.ops.object.select_all(action='DESELECT')
        for cutter in cutters:cutter.select_set(True)
        context.view_layer.objects.active=cutters[0]
        bpy.ops.object.join()
        cutter=cutters[0]
        bpy.ops.object.select_all(action='DESELECT')
        button.select_set(True)
        context.view_layer.objects.active=button
        drill=button.modifiers.new('Four thread holes','BOOLEAN')
        drill.operation='DIFFERENCE'
        drill.solver='EXACT'
        drill.object=cutter
        try:
            bpy.ops.object.modifier_apply(modifier=drill.name)
        finally:
            bpy.data.objects.remove(cutter,do_unlink=True)
        button['nwcs_accessory']=True
        button['nwcs_button_holes']=4
        if p.accessory_attach:
            # Preserve the fitted world pose, then follow garment object movement.
            world_matrix=button.matrix_world.copy()
            button.parent=target
            button.matrix_world=world_matrix
        created.append(button)
    if not created:
        raise ValueError('No front-facing garment surface at button positions; adjust vertical position')
    bpy.ops.object.select_all(action='DESELECT')
    for obj in created:obj.select_set(True)
    context.view_layer.objects.active=created[0]
    return created[0]

def nwcs_create_fitted_zipper(context,target,p):
    """Surface-following dual tape with alternating interlocking 3D teeth.

    Geometry is generated in the garment's LOCAL space, so parent transforms
    remain correct. Each vertical station is projected to evaluated mesh.
    """
    from mathutils.bvhtree import BVHTree
    dg=context.evaluated_depsgraph_get()
    bvh=BVHTree.FromObject(target,dg)
    if bvh is None:
        raise ValueError('Garment has no evaluated surface; finish garment first')
    bounds=[Vector(v) for v in target.bound_box]
    minx,maxx=min(v.x for v in bounds),max(v.x for v in bounds)
    miny,maxy=min(v.y for v in bounds),max(v.y for v in bounds)
    minz,maxz=min(v.z for v in bounds),max(v.z for v in bounds)
    cx=(minx+maxx)*.5
    zcenter=minz+(maxz-minz)*p.accessory_height
    length=min(p.accessory_length,maxz-minz)
    top=min(maxz,zcenter+length*.5)
    bottom=max(minz,top-length)
    if top-bottom<.01:raise ValueError('Zipper too short for garment')
    width=p.accessory_width
    offset=p.accessory_offset
    n=max(12,min(240,int((top-bottom)/max(.0025,width*.27))))
    stations=[]
    for i in range(n+1):
        z=bottom+(top-bottom)*i/n
        origin=Vector((cx,miny-max(.12,(maxy-miny)*1.5),z))
        hit,normal,face,distance=bvh.ray_cast(origin,Vector((0,1,0)),max(1.,(maxy-miny)*5))
        if hit is None:
            raise ValueError('Front surface missing at zipper height; reposition or freeze garment')
        normal=normal.normalized()
        if normal.y>0:normal.negate()
        stations.append((hit,normal))
    # Tangent and binormal recomputed along the zipper for each surface sample.
    frames=[]
    for i,(hit,normal) in enumerate(stations):
        prev=stations[max(0,i-1)][0]
        nxt=stations[min(n,i+1)][0]
        vertical=nxt-prev
        vertical=vertical-normal*vertical.dot(normal)
        if vertical.length<1e-7:vertical=Vector((0,0,1))
        vertical.normalize()
        across=vertical.cross(normal)
        if across.length<1e-7:across=Vector((1,0,0))
        across.normalize()
        if across.x<0:across.negate()
        frames.append((hit,normal,across,vertical))
    verts=[];faces=[]
    def vtx(point):
        verts.append(tuple(point));return len(verts)-1
    def quad(a,b,c,d):faces.append((a,b,c,d))
    def cuboid(center,right,up,out,halfwidth,halfheight,halfdepth):
        ids=[]
        for depth in (-1,1):
            for vv in (-1,1):
                for hh in (-1,1):
                    ids.append(vtx(center+right*(hh*halfwidth)+up*(vv*halfheight)+out*(depth*halfdepth)))
        # bottom, top, and four side faces
        quad(ids[0],ids[2],ids[3],ids[1]);quad(ids[4],ids[5],ids[7],ids[6])
        quad(ids[0],ids[1],ids[5],ids[4]);quad(ids[2],ids[6],ids[7],ids[3])
        quad(ids[0],ids[4],ids[6],ids[2]);quad(ids[1],ids[3],ids[7],ids[5])
    # Two separate fabric tapes, laid on the fitted surface at every station.
    tape_half=width*.23
    gap=width*.065
    for side in (-1,1):
        strips=[]
        for hit,normal,across,up in frames:
            near=hit+across*(side*gap)+normal*offset
            far=hit+across*(side*(gap+2*tape_half))+normal*offset
            strips.append((vtx(near),vtx(far)))
        for i in range(n):
            a,b=strips[i];c,d=strips[i+1]
            quad(a,b,d,c) if side==1 else quad(b,a,c,d)
    # Alternating staggered zipper teeth. Teeth are 3D blocks with inner
    # hooked heads that reach toward the opposite side, not flat rectangles.
    tooth_count=max(8,min(160,int((top-bottom)/max(.0028,width*.33))))
    for i in range(tooth_count):
        t=(i+.5)/tooth_count
        j=max(0,min(n,round(t*n)))
        hit,normal,across,up=frames[j]
        side=-1 if i%2==0 else 1
        h=(top-bottom)/tooth_count*.37
        tooth_w=width*.17
        base=hit+across*(side*width*.14)+normal*(offset+width*.065)
        cuboid(base,across,up,normal,tooth_w,h,width*.06)
        # Interlocking head crosses the central gap; offset along the zipper
        # to make the alternating teeth visually distinct.
        head=hit+across*(side*width*.025)+up*(h*.18)+normal*(offset+width*.085)
        cuboid(head,across,up,normal,width*.095,h*.55,width*.075)
    # Top and bottom zipper stops, plus a dimensional slider and pull tab.
    for idx in (0,n):
        hit,normal,across,up=frames[idx]
        cuboid(hit+normal*(offset+width*.075),across,up,normal,width*.22,width*.09,width*.075)
    hit,normal,across,up=frames[n]
    cuboid(hit+normal*(offset+width*.14)-up*width*.17,across,up,normal,width*.25,width*.24,width*.13)
    # Raised hanging pull tab, with a recessed center indicated by its rim.
    pull_center=hit+normal*(offset+width*.27)+up*width*.26
    cuboid(pull_center,across,up,normal,width*.15,width*.29,width*.04)
    mesh=bpy.data.meshes.new('NWCS Detailed Zipper Mesh')
    mesh.from_pydata(verts,[],faces);mesh.update()
    obj=bpy.data.objects.new('NWCS Fitted Interlocking Zipper',mesh)
    context.collection.objects.link(obj)
    obj['nwcs_accessory']=True
    obj['nwcs_zipper_surface_fitted']=True
    if p.accessory_attach:
        # Mesh is in target-local coordinates, so identity parent matrix
        # makes it follow garment translations/rotations without double transforms.
        obj.parent=target
        obj.matrix_parent_inverse.identity()
        obj.matrix_basis.identity()
    else:
        obj.matrix_world=target.matrix_world.copy()
    # Normals are flat on the tooth blocks; fabric strips can be smoothed later.
    for selected in context.selected_objects:selected.select_set(False)
    obj.select_set(True);context.view_layer.objects.active=obj
    return obj

def nwcs_add_accessory(context,p):
    target=nwcs_accessory_target(context)
    world=[target.matrix_world @ Vector(corner) for corner in target.bound_box]
    minx,maxx=min(v.x for v in world),max(v.x for v in world)
    miny,maxy=min(v.y for v in world),max(v.y for v in world)
    minz,maxz=min(v.z for v in world),max(v.z for v in world)
    z=minz+(maxz-minz)*p.accessory_height
    # Accessories are built as separate editable geometry. Apply simulation
    # before adding them; object parenting does not deform with cloth vertices.
    verts=[];faces=[]
    off=p.accessory_offset
    if p.accessory_kind=='BELT':
        cx=(minx+maxx)*.5;cy=(miny+maxy)*.5
        rx=(maxx-minx)*.5+off;ry=(maxy-miny)*.5+off
        n=64
        for j in range(n):
            a=2*math.pi*j/n
            x=cx+rx*math.cos(a);y=cy+ry*math.sin(a)
            verts.extend(((x,y,z-p.accessory_width*.5),(x,y,z+p.accessory_width*.5)))
        for j in range(n):
            k=(j+1)%n;faces.append((j*2,k*2,k*2+1,j*2+1))
        # Buckle sits at center front of the belt.
        x=cx;y=miny-off*1.5;w=p.accessory_width*.8;h=p.accessory_width*.65
        a=len(verts);verts.extend([(x-w,y,z-h),(x+w,y,z-h),(x+w,y,z+h),(x-w,y,z+h)])
        faces.append((a,a+1,a+2,a+3))
    elif p.accessory_kind=='BUTTONS':
        return nwcs_create_fitted_buttons(context,target,p)
    elif p.accessory_kind=='ZIPPER':
        return nwcs_create_fitted_zipper(context,target,p)
    else:
        cx=(minx+maxx)*.5;by=miny-off
        length=min(p.accessory_length,maxz-minz)
        top=min(maxz,z+length*.5);bottom=max(minz,top-length)
        top=bottom+length
        nwcs_accessory_strip(verts,faces,[(cx,by,bottom),(cx,by,top)],p.accessory_width)
        # Individual teeth across the center of the zipper tape.
        teeth=max(3,min(100,int(length/max(.003,p.accessory_width*.28))))
        for j in range(teeth):
            tz=bottom+(j+.5)*length/teeth
            a=len(verts);tw=p.accessory_width*.30;th=min(length/teeth*.7,p.accessory_width*.17)
            verts.extend([(cx-tw,by-off*.25,tz-th),(cx+tw,by-off*.25,tz-th),
                          (cx+tw,by-off*.25,tz+th),(cx-tw,by-off*.25,tz+th)])
            faces.append((a,a+1,a+2,a+3))
        # Zipper pull tab
        a=len(verts);tw=p.accessory_width*.25
        verts.extend([(cx-tw,by-off*.4,top),(cx+tw,by-off*.4,top),
                      (cx+tw,by-off*.4,top+p.accessory_width*.8),
                      (cx-tw,by-off*.4,top+p.accessory_width*.8)])
        faces.append((a,a+1,a+2,a+3))
    return nwcs_accessory_object(context,'NWCS '+p.accessory_kind.title(),verts,faces,target,p)

class NWCS_OT_add_accessory(bpy.types.Operator):
    bl_idname='nwcs.add_accessory'
    bl_label='Create Accessory'
    bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        try:
            obj=nwcs_add_accessory(context,context.scene.nwcs_props)
            self.report({'INFO'},'Created '+obj.name)
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'},'Accessory: '+str(exc))
            return {'CANCELLED'}

class NWCS_PT_accessories(bpy.types.Panel):
    bl_label='Garment Accessories'
    bl_idname='NWCS_PT_accessories'
    bl_parent_id='NWCS_PT_panel'
    bl_space_type='VIEW_3D'
    bl_region_type='UI'
    bl_options={'DEFAULT_CLOSED'}
    def draw(self,context):
        l=self.layout;p=context.scene.nwcs_props
        l.label(text='Select finished garment first')
        l.prop(p,'accessory_kind')
        l.prop(p,'accessory_height')
        l.prop(p,'accessory_offset')
        if p.accessory_kind=='BELT':l.prop(p,'accessory_width')
        elif p.accessory_kind=='BUTTONS':
            l.prop(p,'accessory_count');l.prop(p,'accessory_size');l.prop(p,'accessory_length',text='Row Length')
        else:
            l.prop(p,'accessory_width');l.prop(p,'accessory_length')
        l.prop(p,'accessory_attach')
        l.operator('nwcs.add_accessory',icon='MOD_SOLIDIFY')
        l.label(text='Apply cloth before attaching')
        if p.accessory_kind=='BUTTONS':l.label(text='Four real holes; follows garment surface')


# Non-destructive stitched trim for finished garments.
class NWCS_StitchSettings(bpy.types.PropertyGroup):
    top: BoolProperty(name="Top hem", default=True)
    bottom: BoolProperty(name="Bottom hem", default=True)
    sleeves: BoolProperty(name="Sleeves / armholes", default=False)
    style: EnumProperty(name="Stitch Style", items=[
        ('SINGLE','Single','One stitch row'),('DOUBLE','Double','Two stitch rows'),
        ('ZIGZAG','Zigzag','Alternating thread path')], default='DOUBLE')
    width: FloatProperty(name="Stitch Width (mm)", default=2.0, min=0.5, max=5.0)
    prominence: FloatProperty(name="Stitch Prominence", default=0.45, min=0, max=1, subtype='FACTOR')
    height: FloatProperty(name="Stitch Height (mm)", default=2.0, min=0.5, max=8.0, description="Length of each visible stitch")
    top_placement_inout: FloatProperty(name="Top In / Out (mm)", default=2.0, min=-15.0, max=15.0)
    top_placement_updown: FloatProperty(name="Top Up / Down (mm)", default=0.0, min=-15.0, max=15.0)
    bottom_placement_inout: FloatProperty(name="Hem In / Out (mm)", default=2.0, min=-15.0, max=15.0)
    bottom_placement_updown: FloatProperty(name="Hem Up / Down (mm)", default=0.0, min=-15.0, max=15.0)

def nwcs_stitch_loops(obj):
    """Trace connected actual mesh edges; never sort arbitrary vertices by angle."""
    import bmesh
    from collections import defaultdict
    bm=bmesh.new()
    bm.from_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    bm.verts.index_update()
    bm.normal_update()
    zs=[v.co.z for v in bm.verts]
    if not zs:
        bm.free()
        return []
    lo,hi=min(zs),max(zs)
    span=max(hi-lo,1.e-6)
    # Prefer true boundaries. Solidified meshes have none, so detect rim
    # edges where surface normals change sharply near garment openings.
    edges=[e for e in bm.edges if e.is_boundary]
    if not edges:
        edges=[e for e in bm.edges if len(e.link_faces)==2 and
               e.calc_face_angle(0)<3.13 and e.calc_face_angle(0)>.55 and
               (max(v.co.z for v in e.verts)<lo+span*.18 or
                min(v.co.z for v in e.verts)>hi-span*.18)]
    adj=defaultdict(list)
    for e in edges:
        a,b=[v.index for v in e.verts]
        adj[a].append(b)
        adj[b].append(a)
    coords={v.index:v.co.copy() for v in bm.verts}
    visited=set()
    paths=[]
    # Follow only nonbranching connected edge chains. Never jump across
    # disconnected legs or openings.
    for start in list(adj):
        if len(adj[start])!=2:
            continue
        for first in adj[start]:
            if frozenset((start,first)) in visited:
                continue
            path=[start]
            prev,cur=start,first
            visited.add(frozenset((start,first)))
            for _ in range(len(adj)+1):
                path.append(cur)
                if cur==start:break
                neighbors=adj.get(cur,[])
                if len(neighbors)!=2:break
                nxt=neighbors[0] if neighbors[1]==prev else neighbors[1]
                edge=frozenset((cur,nxt))
                if edge in visited:break
                visited.add(edge)
                prev,cur=cur,nxt
            if len(path)>=8 and path[-1]==start:
                paths.append([coords[i] for i in path])
    bm.free()
    return paths

class NWCS_OT_remove_stitching(bpy.types.Operator):
    bl_idname='nwcs.remove_stitching'
    bl_label='Remove Stitching'
    bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        obj=context.active_object
        if not obj or obj.type!='MESH':
            self.report({'ERROR'},'Select the finished garment')
            return {'CANCELLED'}
        removed=0
        for child in list(bpy.data.objects):
            if child.get('nwcs_stitch_source')==obj.name and child.get('nwcs_stitch_overlay'):
                data=child.data
                bpy.data.objects.remove(child,do_unlink=True)
                if data and data.users==0:
                    if isinstance(data,bpy.types.Mesh):bpy.data.meshes.remove(data)
                    elif isinstance(data,bpy.types.Curve):bpy.data.curves.remove(data)
                removed+=1
        self.report({'INFO'},f'Removed {removed} stitch overlays')
        return {'FINISHED'}

class NWCS_OT_apply_stitching(bpy.types.Operator):
    bl_idname='nwcs.apply_stitching'
    bl_label='Apply Stitching'
    bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        obj=context.active_object
        if not obj or obj.type!='MESH' or not obj.get('nwcs_generated'):
            self.report({'ERROR'},'Select a finished Neverworld garment')
            return {'CANCELLED'}
        if any(mod.type=='CLOTH' for mod in obj.modifiers):
            self.report({'ERROR'},'Finish the cloth simulation before stitching')
            return {'CANCELLED'}
        settings=context.scene.nwcs_stitch_settings
        bpy.ops.nwcs.remove_stitching()
        paths=nwcs_stitch_loops(obj)
        if not paths:
            self.report({'WARNING'},'No continuous hem edge loops found; mesh needs identifiable hem edges')
            return {'CANCELLED'}
        zmin=min(v.co.z for v in obj.data.vertices)
        zmax=max(v.co.z for v in obj.data.vertices)
        height=max(zmax-zmin,0.001)
        # Classify loops using their vertical position and extent, not ring heights.
        selected=[]
        for path in paths:
            zs=[v.z for v in path]
            avg=sum(zs)/len(zs)
            extent=max(zs)-min(zs)
            if avg>zmin+height*.72 and settings.top:
                selected.append((path, 'TOP'))
            elif avg<zmin+height*.28 and settings.bottom:
                selected.append((path, 'BOTTOM'))
            elif settings.sleeves and extent<height*.45:
                selected.append((path, 'BOTTOM'))
        if not selected:
            self.report({'WARNING'},'No boundaries match the selected hem options')
            return {'CANCELLED'}
        curve=bpy.data.curves.new('NWCS Stitch Threads','CURVE')
        curve.dimensions='3D'
        curve.resolution_u=1
        curve.bevel_resolution=2
        curve.bevel_depth=(.00025+.00065*settings.prominence)
        # Individual short stitches, never a line connecting unrelated edges.
        # Resample the actual connected edge path at even arc-length intervals.
        import math
        stitch_len=settings.height*.001
        gap=max(stitch_len*.55,.0005)
        pitch=stitch_len+gap
        total_stitches=0
        for path, hem_section in selected:
            if len(path)<5 or (path[0]-path[-1]).length>1.e-4:
                continue
            segments=[]
            distance=0.0
            for a,b in zip(path,path[1:]):
                length=(b-a).length
                if length>1.e-8:
                    segments.append((distance,distance+length,a,b))
                    distance+=length
            if distance<.01:continue
            def point_at(t):
                t=t%distance
                for begin,end,a,b in segments:
                    if t<=end:
                        return a+(b-a)*((t-begin)/(end-begin))
                return segments[-1][3].copy()
            loop_center=sum((v for v in path[:-1]),Vector())/max(1,len(path)-1)
            rows=2 if settings.style=='DOUBLE' else 1
            for row in range(rows):
                count=max(1,int(distance/pitch))
                if count>6000:
                    count=6000
                for i in range(count):
                    t=i*distance/count
                    a=point_at(t)
                    b=point_at(t+min(stitch_len,distance/count*.7))
                    # Move slightly outward from surface to prevent z-fighting.
                    # Row separation is independent from visible stitch height.
                    mid=(a+b)*.5
                    radial=Vector((mid.x,mid.y,0))
                    if radial.length>1.e-6:radial.normalize()
                    else:radial=Vector((0,1,0))
                    lift=radial*(.0005+settings.prominence*.001)
                    # Placement is separate from stitch height and thread thickness.
                    # Positive in/out offsets point toward the garment's horizontal center.
                    # Use the loop center rather than world origin for translated bodies.
                    inset=Vector((loop_center.x-mid.x,loop_center.y-mid.y,0))
                    if inset.length>1.e-6:inset.normalize()
                    else:inset=-radial
                    lift+=inset*((settings.top_placement_inout if hem_section=='TOP' else settings.bottom_placement_inout)*.001)
                    lift.z+=(settings.top_placement_updown if hem_section=='TOP' else settings.bottom_placement_updown)*.001
                    if settings.style=='ZIGZAG':
                        lift+=Vector((0,0,(1 if i%2 else -1)*settings.width*.0004))
                    row_offset=Vector((0,0,row*settings.width*.001))
                    spline=curve.splines.new('POLY')
                    spline.points.add(1)
                    spline.points[0].co=(*(a+lift+row_offset),1)
                    spline.points[1].co=(*(b+lift+row_offset),1)
                    total_stitches+=1
        if not curve.splines:
            bpy.data.curves.remove(curve)
            return {'CANCELLED'}
        thread=bpy.data.objects.new('NWCS Stitching - '+obj.name,curve)
        context.collection.objects.link(thread)
        thread.parent=obj
        thread.matrix_parent_inverse=obj.matrix_world.inverted()
        thread.matrix_world=obj.matrix_world.copy()
        thread['nwcs_stitch_source']=obj.name
        thread['nwcs_stitch_overlay']=True
        material=bpy.data.materials.get('NWCS Stitch Thread')
        if material is None:
            material=bpy.data.materials.new('NWCS Stitch Thread')
            material.diffuse_color=(.72,.68,.59,1)
        curve.materials.append(material)
        # Bake the bevelled threads to mesh without changing garment selection.
        context.view_layer.update()
        depsgraph=context.evaluated_depsgraph_get()
        mesh=bpy.data.meshes.new_from_object(thread.evaluated_get(depsgraph),depsgraph=depsgraph)
        mesh.name='NWCS Stitch Threads'
        mesh_thread=bpy.data.objects.new(thread.name,mesh)
        context.collection.objects.link(mesh_thread)
        mesh_thread.parent=thread.parent
        mesh_thread.matrix_parent_inverse=thread.matrix_parent_inverse.copy()
        mesh_thread.matrix_world=thread.matrix_world.copy()
        for key in thread.keys():mesh_thread[key]=thread[key]
        thread_name=thread.name
        bpy.data.objects.remove(thread,do_unlink=True)
        mesh_thread.name=thread_name
        if curve.users==0:bpy.data.curves.remove(curve)
        self.report({'INFO'},f'Stitching added along {len(selected)} garment boundaries')
        return {'FINISHED'}

class NWCS_PT_stitching(bpy.types.Panel):
    bl_label='Stitching & Hems'
    bl_idname='NWCS_PT_stitching'
    bl_parent_id='NWCS_PT_panel'
    bl_space_type='VIEW_3D'
    bl_region_type='UI'
    bl_options={'DEFAULT_CLOSED'}
    def draw(self,context):
        l=self.layout
        p=context.scene.nwcs_stitch_settings
        l.prop(p,'top')
        l.prop(p,'bottom')
        l.prop(p,'sleeves')
        l.prop(p,'style')
        l.prop(p,'width')
        l.prop(p,'prominence')
        l.prop(p,'height')
        top_box=l.box()
        top_box.label(text='Top Stitch Placement')
        top_box.prop(p,'top_placement_inout')
        top_box.prop(p,'top_placement_updown')
        hem_box=l.box()
        hem_box.label(text='Bottom Hem Placement (also sleeves / armholes)')
        hem_box.prop(p,'bottom_placement_inout')
        hem_box.prop(p,'bottom_placement_updown')
        l.operator('nwcs.apply_stitching',icon='MOD_CURVE')
        l.operator('nwcs.remove_stitching',icon='X')
        l.label(text='Finish garment before stitching')
# Rigging stage 1: choose existing weighted body, garment and SL armature.
def nwcs_rig_mesh_poll(self, ob):
    return ob.type == 'MESH'

def nwcs_rig_armature_poll(self, ob):
    return ob.type == 'ARMATURE'

class NWCS_RigSettings(bpy.types.PropertyGroup):
    source_body: PointerProperty(name='Weights From', type=bpy.types.Object, poll=nwcs_rig_mesh_poll,
        description='An already weighted body matching the clothing fit')
    garment: PointerProperty(name='Clothing To Rig', type=bpy.types.Object, poll=nwcs_rig_mesh_poll)
    include_baked_texture: BoolProperty(name='Include Baked Texture',default=True,description='Embed the packed baked JPG in GLB; DAE exports become a ZIP with the JPG')
    export_optimize: BoolProperty(name='Optimize Export Copy (Under 10 MB)',default=True,description='Clean evaluated geometry and reduce only the export copy to fit the 10 MB upload limit')
    smooth_iterations: IntProperty(name='Smooth Iterations',default=50,min=1,max=500)
    smooth_factor: FloatProperty(name='Smooth Factor',default=.5,min=0.,max=1.)
    test_pose: EnumProperty(name='Test Pose',items=[('ARMS','Arms / Elbows','Lower the arms and bend elbows'),('LEGS','Legs / Knees','Bend hips and knees'),('TORSO','Torso','Bend the torso')],default='ARMS')
    armature: PointerProperty(name='Second Life Rig', type=bpy.types.Object, poll=nwcs_rig_armature_poll,
        description='Existing Second Life / OpenSim armature, such as your Avastar rig')

def nwcs_rig_setup_issues(settings):
    body, garment, rig = settings.source_body, settings.garment, settings.armature
    issues=[]
    if body is None: issues.append('Choose a weighted source body')
    if garment is None: issues.append('Choose the clothing mesh')
    if rig is None: issues.append('Choose an existing Second Life armature')
    if issues: return issues
    if body == garment: issues.append('Source body and clothing must be different objects')
    if not body.data.vertices: issues.append('Source body has no vertices')
    if not garment.data.vertices: issues.append('Clothing has no vertices')
    if any(mod.type=='CLOTH' for mod in garment.modifiers):
        issues.append('Finish the clothing simulation before rigging')
    # This is a core compatibility check, not a full Bento/export certification.
    parents={'mTorso':'mPelvis','mChest':'mTorso','mNeck':'mChest',
        'mCollarLeft':'mChest','mCollarRight':'mChest',
        'mHipLeft':'mPelvis','mKneeLeft':'mHipLeft','mAnkleLeft':'mKneeLeft',
        'mHipRight':'mPelvis','mKneeRight':'mHipRight','mAnkleRight':'mKneeRight',
        'mShoulderLeft':'mCollarLeft','mElbowLeft':'mShoulderLeft','mWristLeft':'mElbowLeft',
        'mShoulderRight':'mCollarRight','mElbowRight':'mShoulderRight','mWristRight':'mElbowRight'}
    required=set(parents)|set(parents.values())
    bones=rig.data.bones
    missing=sorted(required-set(bones.keys()))
    if missing: issues.append('Missing SL bones: '+', '.join(missing))
    elif any(parent not in {b.name for b in bones[child].parent_recursive} for child,parent in parents.items()):
        issues.append('Core SL bone parenting does not match the expected hierarchy')
    source_rigs=[mod.object for mod in body.modifiers if mod.type=='ARMATURE' and mod.object]
    if rig not in source_rigs: issues.append('Source body needs an Armature modifier using the selected rig')
    other_rigs=[mod.object for mod in garment.modifiers if mod.type=='ARMATURE' and mod.object and mod.object!=rig]
    if other_rigs: issues.append('Clothing already uses a different armature')
    bone_groups={g.index for g in body.vertex_groups if g.name in bones and bones[g.name].use_deform}
    if not any(g.group in bone_groups and g.weight>0 for v in body.data.vertices for g in v.groups):
        issues.append('Source body has no positive weights for deform bones on this rig')
    return issues

class NWCS_OT_load_weighted_female(bpy.types.Operator):
    bl_idname='nwcs.load_weighted_female'
    bl_label='Load Included Weighted Female + SL Skeleton'
    bl_description='Load the original female body weights and SL skeleton recovered from the bundled Collada; no automatic weight guessing'
    bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        import os
        if context.mode!='OBJECT':
            self.report({'ERROR'},'Switch to Object Mode first')
            return {'CANCELLED'}
        settings=context.scene.nwcs_rig_settings
        garment=context.active_object
        if not garment or garment.type!='MESH' or garment==context.scene.nwcs_props.reference_body or garment.get('nwcs_weight_source'):
            garment=settings.garment
        # Reuse the included pair when it is already loaded.
        body=next((o for o in context.scene.objects if o.get('nwcs_weight_source') and o.find_armature()),None)
        if body is None:
            path=os.path.join(os.path.dirname(__file__),'female_weighted_rig.blend')
            if not os.path.isfile(path):
                self.report({'ERROR'},'Included weighted female asset is missing')
                return {'CANCELLED'}
            with bpy.data.libraries.load(path,link=False) as (source,target):
                target.objects=list(source.objects)
            for ob in target.objects:
                if ob and not context.scene.objects.get(ob.name):context.collection.objects.link(ob)
            body=next((o for o in target.objects if o and o.get('nwcs_weight_source')),None)
        if body is None or body.find_armature() is None:
            self.report({'ERROR'},'Could not load the included weighted body and skeleton')
            return {'CANCELLED'}
        settings.source_body=body;settings.armature=body.find_armature()
        if garment and garment!=body:settings.garment=garment
        # Keep the source available for transfer without overlapping the design body.
        body.hide_set(True);body.hide_render=True
        settings.armature.hide_set(False)
        self.report({'INFO'},'Weighted female and original SL skeleton loaded. Source body hidden to avoid overlap.')
        return {'FINISHED'}

class NWCS_OT_rig_use_reference(bpy.types.Operator):
    bl_idname='nwcs.rig_use_reference'
    bl_label='Use Selected Clothing / Detect Source'
    bl_description='Use the reference avatar, selected clothing mesh, and the avatar armature when available'
    bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        settings=context.scene.nwcs_rig_settings
        body=context.scene.nwcs_props.reference_body
        detected=body.find_armature() if body else None
        if detected:
            settings.source_body=body
            settings.armature=detected
        elif not settings.source_body or not settings.armature:
            settings.source_body=body
            settings.armature=None
        ob=context.active_object
        settings.garment=ob if ob and ob.type=='MESH' and ob!=body else None
        self.report({'INFO'},'Review the three rigging selections below')
        return {'FINISHED'}

class NWCS_OT_rig_check(bpy.types.Operator):
    bl_idname='nwcs.rig_check'
    bl_label='Check Rigging Setup'
    bl_description='Check core SL bones, parenting, source weights and garment readiness without changing meshes'
    def execute(self,context):
        issues=nwcs_rig_setup_issues(context.scene.nwcs_rig_settings)
        if issues:
            for issue in issues: self.report({'WARNING'},issue)
            return {'CANCELLED'}
        self.report({'INFO'},'Setup passed core checks. Ready for the next weight-transfer stage.')
        return {'FINISHED'}

def nwcs_transfer_weight_rows(body,garment,rig):
    # Compute every weight before changing the garment. Triangles and queries
    # use world space, so object scale/orientation do not change correspondence.
    mesh=body.data;mesh.calc_loop_triangles()
    triangles=[tuple(t.vertices) for t in mesh.loop_triangles]
    if not triangles:raise ValueError('Source body has no faces')
    coords=[body.matrix_world@v.co for v in mesh.vertices]
    tree=BVHTree.FromPolygons(coords,triangles,all_triangles=True)
    names={g.index:g.name for g in body.vertex_groups
           if g.name in rig.data.bones and rig.data.bones[g.name].use_deform}
    source=[{names[g.group]:g.weight for g in v.groups if g.group in names and g.weight>0}
            for v in mesh.vertices]
    result=[]
    for v in garment.data.vertices:
        hit,normal,index,distance=tree.find_nearest(garment.matrix_world@v.co)
        if index is None:raise ValueError('Could not find source surface for clothing')
        ids=triangles[index];a,b,c=[coords[i] for i in ids]
        u=b-a;w=c-a;q=hit-a
        aa=u.dot(u);bb=u.dot(w);cc=w.dot(w);d=u.dot(q);e=w.dot(q)
        denom=aa*cc-bb*bb
        if abs(denom)<1e-16:
            nearest=min(range(3),key=lambda j:(coords[ids[j]]-hit).length_squared)
            bary=[1.0 if j==nearest else 0.0 for j in range(3)]
        else:
            y=(cc*d-bb*e)/denom;z=(aa*e-bb*d)/denom
            bary=[max(0.,min(1.,t)) for t in (1-y-z,y,z)]
        weights={}
        for vi,factor in zip(ids,bary):
            for name,weight in source[vi].items():weights[name]=weights.get(name,0.)+weight*factor
        best=sorted(((name,weight) for name,weight in weights.items() if weight>1e-8),key=lambda x:(-x[1],x[0]))[:4]
        total=sum(weight for _,weight in best)
        if total<1e-8:raise ValueError('Source surface has unweighted vertices near the clothing')
        result.append([(name,weight/total) for name,weight in best])
    return result

class NWCS_OT_rig_clothing(bpy.types.Operator):
    bl_idname='nwcs.rig_clothing'
    bl_label='Rig Clothing'
    bl_description='Transfer nearest-surface body weights, normalize to at most four bones per vertex and bind to the selected SL rig'
    bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        if context.mode!='OBJECT':
            self.report({'ERROR'},'Switch to Object Mode first');return {'CANCELLED'}
        s=context.scene.nwcs_rig_settings
        issues=nwcs_rig_setup_issues(s)
        if issues:
            self.report({'ERROR'},issues[0]);return {'CANCELLED'}
        rig=s.armature;garment=s.garment
        if rig.get('nwcs_pose_backup') or any(any(abs(b.matrix_basis[i][j]-(1. if i==j else 0.))>1e-5 for i in range(4) for j in range(4)) for b in rig.pose.bones):
            self.report({'ERROR'},'Restore the rig to its rest pose before transferring weights');return {'CANCELLED'}
        if garment.data.users>1:
            self.report({'ERROR'},'Make the clothing mesh single-user before rigging');return {'CANCELLED'}
        if any(g.lock_weight for g in garment.vertex_groups if g.name in rig.data.bones):
            self.report({'ERROR'},'Unlock clothing bone groups before replacing weights');return {'CANCELLED'}
        try:rows=nwcs_transfer_weight_rows(s.source_body,garment,rig)
        except Exception as exc:
            self.report({'ERROR'},str(exc)[:200]);return {'CANCELLED'}
        # Replace bone weights only. Preserve UVs, geometry and unrelated groups.
        for g in list(garment.vertex_groups):
            if g.name in rig.data.bones:garment.vertex_groups.remove(g)
        groups={name:garment.vertex_groups.new(name=name) for name in sorted({n for row in rows for n,w in row})}
        for index,row in enumerate(rows):
            for name,weight in row:groups[name].add([index],weight,'REPLACE')
        armatures=[mod for mod in garment.modifiers if mod.type=='ARMATURE' and mod.object==rig]
        modifier=armatures[0] if armatures else garment.modifiers.new('NWCS Clothing Rig','ARMATURE')
        modifier.object=rig;modifier.use_vertex_groups=True;modifier.use_bone_envelopes=False
        modifier.show_viewport=True;modifier.show_render=True
        for duplicate in armatures[1:]:garment.modifiers.remove(duplicate)
        garment.hide_set(False)
        bpy.ops.object.select_all(action='DESELECT');garment.select_set(True);context.view_layer.objects.active=garment
        # Deform the base fabric before subdivision/solidify so generated faces
        # follow the same deformation without extra weight layers.
        with context.temp_override(object=garment,active_object=garment):
            while garment.modifiers.find(modifier.name)>0:
                bpy.ops.object.modifier_move_up(modifier=modifier.name)
        garment['nwcs_rigged']=True
        self.report({'INFO'},'Clothing rigged: '+str(len(rows))+' vertices, normalized to at most 4 bone weights each')
        return {'FINISHED'}

class NWCS_OT_test_rig_pose(bpy.types.Operator):
    bl_idname='nwcs.test_rig_pose'
    bl_label='Test Clothing Pose'
    bl_description='Preview deformation; save the original pose for Restore Pose'
    bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        import json
        s=context.scene.nwcs_rig_settings;rig=s.armature;garment=s.garment
        if context.mode!='OBJECT':
            self.report({'ERROR'},'Switch to Object Mode first');return {'CANCELLED'}
        if not rig or not garment or not any(m.type=='ARMATURE' and m.object==rig for m in garment.modifiers):
            self.report({'ERROR'},'Rig the clothing first');return {'CANCELLED'}
        if rig.animation_data and (rig.animation_data.action or rig.animation_data.nla_tracks):
            self.report({'ERROR'},'Use a rig without active animation for the static pose test');return {'CANCELLED'}
        if any(b.constraints for b in rig.pose.bones):
            self.report({'ERROR'},'This rig uses constraints; test it with its own pose controls');return {'CANCELLED'}
        if not rig.get('nwcs_pose_backup'):
            rig['nwcs_pose_backup']=json.dumps({b.name:[list(row) for row in b.matrix_basis] for b in rig.pose.bones})
            rig['nwcs_pose_position']=rig.data.pose_position
            reference=context.scene.nwcs_props.reference_body
            visible_objects=[o for o in (rig,s.source_body,reference) if o and o.name in context.view_layer.objects]
            rig['nwcs_pose_visibility']=json.dumps({o.name:o.hide_get() for o in visible_objects})
        original=json.loads(rig['nwcs_pose_backup'])
        for b in rig.pose.bones:
            if b.name in original:b.matrix_basis=Matrix(original[b.name])
        rotations={'ARMS':{'mShoulderLeft':-.35,'mShoulderRight':.35,'mElbowLeft':-.6,'mElbowRight':.6},
                   'LEGS':{'mHipLeft':.25,'mHipRight':-.15,'mKneeLeft':.5,'mKneeRight':.25},
                   'TORSO':{'mTorso':.25,'mChest':.15}}[s.test_pose]
        for name,angle in rotations.items():
            bone=rig.pose.bones.get(name)
            if bone:bone.matrix_basis=Matrix(original[name])@Matrix.Rotation(angle,4,'Z' if s.test_pose=='ARMS' else 'X')
        reference=context.scene.nwcs_props.reference_body
        if reference and reference!=s.source_body and reference.name in context.view_layer.objects:reference.hide_set(True)
        if s.source_body and s.source_body.name in context.view_layer.objects:s.source_body.hide_set(False)
        rig.data.pose_position='POSE';rig.hide_set(False);context.view_layer.update()
        self.report({'INFO'},'Test pose applied. Restore Pose returns the rig to its saved pose.')
        return {'FINISHED'}

class NWCS_OT_restore_rig_pose(bpy.types.Operator):
    bl_idname='nwcs.restore_rig_pose'
    bl_label='Restore Pose'
    bl_description='Restore the exact pose saved before testing'
    bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        import json
        rig=context.scene.nwcs_rig_settings.armature
        if not rig or not rig.get('nwcs_pose_backup'):
            self.report({'WARNING'},'No saved test pose to restore');return {'CANCELLED'}
        original=json.loads(rig['nwcs_pose_backup'])
        for b in rig.pose.bones:
            if b.name in original:b.matrix_basis=Matrix(original[b.name])
        rig.data.pose_position=rig.get('nwcs_pose_position','POSE')
        for name,hidden in json.loads(rig.get('nwcs_pose_visibility','{}')).items():
            ob=context.view_layer.objects.get(name)
            if ob:ob.hide_set(hidden)
        if 'nwcs_pose_visibility' in rig:del rig['nwcs_pose_visibility']
        del rig['nwcs_pose_backup']
        if 'nwcs_pose_position' in rig:del rig['nwcs_pose_position']
        context.view_layer.update()
        self.report({'INFO'},'Original pose restored')
        return {'FINISHED'}

def nwcs_bound_clothing(context):
    s=context.scene.nwcs_rig_settings
    if context.mode!='OBJECT':raise ValueError('Switch to Object Mode first')
    if not s.garment or not s.armature:raise ValueError('Choose clothing and its rig first')
    if not any(m.type=='ARMATURE' and m.object==s.armature for m in s.garment.modifiers):
        raise ValueError('Rig the clothing first')
    if any(m.type=='CLOTH' for m in s.garment.modifiers):raise ValueError('Finish the cloth simulation first')
    return s.garment,s.armature

def nwcs_bone_weight_rows(ob,rig,mesh=None):
    names={g.index:g.name for g in ob.vertex_groups if g.name in rig.data.bones and rig.data.bones[g.name].use_deform}
    rows=[]
    for v in (mesh or ob.data).vertices:
        weights=sorted(((names[g.group],g.weight) for g in v.groups if g.group in names and g.weight>1e-8),key=lambda x:(-x[1],x[0]))[:4]
        total=sum(w for _,w in weights)
        if total<1e-8:raise ValueError('Clothing has unweighted vertices; rig it before exporting or smoothing')
        rows.append({name:w/total for name,w in weights})
    return rows

class NWCS_OT_smooth_clothing_weights(bpy.types.Operator):
    bl_idname='nwcs.smooth_clothing_weights'
    bl_label='Smooth Clothing Weights'
    bl_description='Smooth all deform bone groups across connected vertices; normalize and limit to four influences'
    bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        try:
            ob,rig=nwcs_bound_clothing(context)
            if ob.data.users>1:raise ValueError('Make the clothing mesh single-user first')
            if any(g.lock_weight for g in ob.vertex_groups if g.name in rig.data.bones and rig.data.bones[g.name].use_deform):
                raise ValueError('Unlock deform bone groups before smoothing')
            rows=nwcs_bone_weight_rows(ob,rig)
            neighbors=[set() for v in ob.data.vertices]
            for edge in ob.data.edges:
                a,b=edge.vertices;neighbors[a].add(b);neighbors[b].add(a)
            settings=context.scene.nwcs_rig_settings;factor=settings.smooth_factor
            for iteration in range(settings.smooth_iterations):
                following=[]
                for index,adj in enumerate(neighbors):
                    if not adj:following.append(rows[index].copy());continue
                    blended={n:w*(1-factor) for n,w in rows[index].items()}
                    for other in adj:
                        for n,w in rows[other].items():blended[n]=blended.get(n,0.)+w*factor/len(adj)
                    following.append(blended)
                rows=following
            for index,row in enumerate(rows):
                best=sorted(((n,w) for n,w in row.items() if w>1e-8),key=lambda x:(-x[1],x[0]))[:4]
                total=sum(w for _,w in best);rows[index]={n:w/total for n,w in best}
        except Exception as exc:
            self.report({'ERROR'},str(exc)[:200]);return {'CANCELLED'}
        groups={g.name:g for g in ob.vertex_groups if g.name in rig.data.bones and rig.data.bones[g.name].use_deform}
        indices=list(range(len(ob.data.vertices)))
        for group in groups.values():group.remove(indices)
        for name in sorted({n for row in rows for n in row}):
            if name not in groups:groups[name]=ob.vertex_groups.new(name=name)
        for index,row in enumerate(rows):
            for name,weight in row.items():groups[name].add([index],weight,'REPLACE')
        self.report({'INFO'},'Smoothed all deform groups: '+str(settings.smooth_iterations)+' iterations')
        return {'FINISHED'}

def nwcs_write_weighted_dae(context,ob,rig,path,texture_filename=None):
    import xml.etree.ElementTree as ET
    from datetime import datetime,timezone
    ns='http://www.collada.org/2005/11/COLLADASchema';ET.register_namespace('',ns)
    def node(parent,tag,text=None,**attrs):
        el=ET.SubElement(parent,'{'+ns+'}'+tag,{k:str(v) for k,v in attrs.items()})
        if text is not None:el.text=str(text)
        return el
    def nums(values):return ' '.join(format(float(v),'.7g') for v in values)
    def matrix_text(mat):return nums(v for row in mat for v in row)
    root=ET.Element('{'+ns+'}COLLADA',version='1.4.1')
    asset=node(root,'asset');contributor=node(asset,'contributor');node(contributor,'authoring_tool','Neverworld Clothing Creator')
    now=datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ');node(asset,'created',now);node(asset,'modified',now);node(asset,'unit',name='meter',meter=1);node(asset,'up_axis','Z_UP')
    if texture_filename:
        images=node(root,'library_images');image=node(images,'image',id='BakedImage',name='Baked garment texture');node(image,'init_from',texture_filename)
        effect=node(node(root,'library_effects'),'effect',id='BakedEffect')
        profile=node(effect,'profile_COMMON')
        surface=node(node(profile,'newparam',sid='BakedSurface'),'surface',type='2D');node(surface,'init_from','BakedImage')
        sampler=node(node(profile,'newparam',sid='BakedSampler'),'sampler2D');node(sampler,'source','BakedSurface')
        lambert=node(node(profile,'technique',sid='common'),'lambert')
        node(node(lambert,'diffuse'),'texture',texture='BakedSampler',texcoord='UVMap')
        material=node(node(root,'library_materials'),'material',id='BakedMaterial',name='Baked garment texture');node(material,'instance_effect',url='#BakedEffect')
    # Evaluate finishing modifiers in rest pose while retaining deform layers.
    pose=rig.data.pose_position;states=[(m,m.show_viewport) for m in ob.modifiers if m.type=='ARMATURE']
    evaluated=None;mesh=None
    try:
        rig.data.pose_position='REST'
        for mod,state in states:mod.show_viewport=False
        context.view_layer.update();deps=context.evaluated_depsgraph_get();evaluated=ob.evaluated_get(deps)
        mesh=evaluated.to_mesh(preserve_all_data_layers=True,depsgraph=deps)
        rows=nwcs_bone_weight_rows(ob,rig,mesh);mesh.calc_loop_triangles()
        if not mesh.loop_triangles:raise ValueError('Clothing has no faces to export')
        unit=context.scene.unit_settings.scale_length if context.scene.unit_settings.system!='NONE' else 1.
        if unit<=0:raise ValueError('Scene unit scale must be positive')
        verts=[(ob.matrix_world@v.co)*unit for v in mesh.vertices]
        normal_matrix=ob.matrix_world.to_3x3().inverted_safe().transposed()
        normals=[(normal_matrix@c.vector).normalized() for c in mesh.corner_normals]
        uv=mesh.uv_layers.active
        unique_normals=[];normal_ids=[];normal_lookup={}
        for value in normals:
            key=tuple(round(c,6) for c in value)
            if key not in normal_lookup:normal_lookup[key]=len(unique_normals);unique_normals.append(key)
            normal_ids.append(normal_lookup[key])
        unique_uv=[];uv_ids=[];uv_lookup={}
        if uv:
            for loop in uv.data:
                key=tuple(round(c,7) for c in loop.uv)
                if key not in uv_lookup:uv_lookup[key]=len(unique_uv);unique_uv.append(key)
                uv_ids.append(uv_lookup[key])
        def source(parent,id,values,stride,params,kind='float'):
            el=node(parent,'source',id=id);arrayid=id+'-array'
            if kind=='Name':node(el,'Name_array',' '.join(values),id=arrayid,count=len(values))
            else:node(el,'float_array',nums(values),id=arrayid,count=len(values))
            acc=node(node(el,'technique_common'),'accessor',source='#'+arrayid,count=len(values)//stride,stride=stride)
            for param,ptype in params:node(acc,'param',name=param,type=ptype)
            return id
        geos=node(root,'library_geometries');geo=node(geos,'geometry',id='ClothingGeometry',name=ob.name);gm=node(geo,'mesh')
        source(gm,'Positions',[x for v in verts for x in v],3,[('X','float'),('Y','float'),('Z','float')])
        source(gm,'Normals',[x for v in unique_normals for x in v],3,[('X','float'),('Y','float'),('Z','float')])
        if uv:source(gm,'UV',[x for value in unique_uv for x in value],2,[('S','float'),('T','float')])
        vertices=node(gm,'vertices',id='Vertices');node(vertices,'input',semantic='POSITION',source='#Positions')
        material_indices=sorted({t.material_index for t in mesh.loop_triangles})
        for index in material_indices:
            tris=[t for t in mesh.loop_triangles if t.material_index==index]
            triangles=node(gm,'triangles',count=len(tris),**({'material':'BakedMaterial'} if texture_filename else {}))
            node(triangles,'input',semantic='VERTEX',source='#Vertices',offset=0);node(triangles,'input',semantic='NORMAL',source='#Normals',offset=1)
            if uv:node(triangles,'input',semantic='TEXCOORD',source='#UV',offset=2,set=0)
            values=[]
            for tri in tris:
                # Mirrored object transforms need reversed winding.
                order=(0,2,1) if ob.matrix_world.to_3x3().determinant()<0 else (0,1,2)
                for j in order:
                    vi,li=tri.vertices[j],tri.loops[j];values.extend([vi,normal_ids[li]]+([uv_ids[li]] if uv else []))
            node(triangles,'p',' '.join(map(str,values)))
        selected={b.name for b in rig.data.bones if b.use_deform}
        for name in list(selected):selected.update(b.name for b in rig.data.bones[name].parent_recursive)
        bones=[b for b in rig.data.bones if b.name in selected];bone_index={b.name:i for i,b in enumerate(bones)}
        def joint_world(b):
            mat=rig.matrix_world@b.matrix_local;mat.translation*=unit;return mat
        worlds={b.name:joint_world(b) for b in bones}
        controllers=node(root,'library_controllers');skin=node(node(controllers,'controller',id='ClothingSkin'),'skin',source='#ClothingGeometry')
        node(skin,'bind_shape_matrix',matrix_text(Matrix.Identity(4)))
        source(skin,'Joints',[b.name for b in bones],1,[('JOINT','Name')],kind='Name')
        source(skin,'BindPoses',[v for b in bones for row in worlds[b.name].inverted() for v in row],16,[('TRANSFORM','float4x4')])
        weights=[];pairs=[];counts=[]
        for row in rows:
            counts.append(len(row))
            for name,weight in row.items():pairs.extend([bone_index[name],len(weights)]);weights.append(weight)
        source(skin,'Weights',weights,1,[('WEIGHT','float')])
        joints=node(skin,'joints');node(joints,'input',semantic='JOINT',source='#Joints');node(joints,'input',semantic='INV_BIND_MATRIX',source='#BindPoses')
        vw=node(skin,'vertex_weights',count=len(rows));node(vw,'input',semantic='JOINT',source='#Joints',offset=0);node(vw,'input',semantic='WEIGHT',source='#Weights',offset=1)
        node(vw,'vcount',' '.join(map(str,counts)));node(vw,'v',' '.join(map(str,pairs)))
        scene=node(node(root,'library_visual_scenes'),'visual_scene',id='Scene',name='Scene')
        made={}
        def make_joint(b):
            if b.name in made:return made[b.name]
            parent=make_joint(b.parent) if b.parent and b.parent.name in selected else scene
            el=node(parent,'node',id='Joint'+str(bone_index[b.name]),sid=b.name,name=b.name,type='JOINT');made[b.name]=el
            local=worlds[b.parent.name].inverted()@worlds[b.name] if b.parent and b.parent.name in selected else worlds[b.name]
            node(el,'matrix',matrix_text(local),sid='transform');return el
        for b in bones:make_joint(b)
        objnode=node(scene,'node',id='Clothing',name=ob.name,type='NODE');instance=node(objnode,'instance_controller',url='#ClothingSkin')
        for b in bones:
            if not b.parent or b.parent.name not in selected:node(instance,'skeleton','#Joint'+str(bone_index[b.name]))
        if texture_filename:
            binding=node(node(instance,'bind_material'),'technique_common')
            bound=node(binding,'instance_material',symbol='BakedMaterial',target='#BakedMaterial')
            node(bound,'bind_vertex_input',semantic='UVMap',input_semantic='TEXCOORD',input_set=0)
        node(node(root,'scene'),'instance_visual_scene',url='#Scene')
        # Schema library order is flexible in COLLADA 1.4; all refs are local.
        ET.ElementTree(root).write(path,encoding='utf-8',xml_declaration=True)
    finally:
        if evaluated and mesh:evaluated.to_mesh_clear()
        rig.data.pose_position=pose
        for mod,state in states:mod.show_viewport=state
        context.view_layer.update()

def nwcs_clean_export_mesh(mesh):
    """Remove loose/invalid export geometry while preserving UV seams and weights."""
    import bmesh
    mesh.validate(clean_customdata=False)
    used={i for poly in mesh.polygons for i in poly.vertices}
    seen=set();bad=[]
    for poly in mesh.polygons:
        key=tuple(sorted(poly.vertices))
        if poly.area<=1e-14 or key in seen:bad.append(poly.index)
        seen.add(key)
    if len(used)<len(mesh.vertices) or bad or any(e.is_loose for e in mesh.edges):
        bm=bmesh.new()
        try:
            bm.from_mesh(mesh);bm.faces.ensure_lookup_table()
            bmesh.ops.delete(bm,geom=[bm.faces[i] for i in bad],context='FACES_ONLY')
            wires=[e for e in bm.edges if not e.link_faces]
            if wires:bmesh.ops.delete(bm,geom=wires,context='EDGES')
            loose=[v for v in bm.verts if not v.link_faces]
            if loose:bmesh.ops.delete(bm,geom=loose,context='VERTS')
            bm.to_mesh(mesh)
        finally:bm.free()
    mesh.update()
    if not mesh.polygons:raise ValueError('No usable garment faces remain after export cleanup')

def nwcs_check_glb_contents(path,allow_texture=False):
    import json,struct
    with open(path,'rb') as file:
        magic,version,size=struct.unpack('<4sII',file.read(12))
        length,kind=struct.unpack('<II',file.read(8));data=json.loads(file.read(length))
    if magic!=b'glTF' or version!=2 or kind!=0x4e4f534a:raise ValueError('Invalid GLB export')
    if len(data.get('meshes',[]))!=1 or len(data.get('skins',[]))!=1:
        raise ValueError('GLB must contain exactly one clothing mesh and one skin')
    forbidden=('cameras','animations') if allow_texture else ('cameras','animations','materials','images','textures')
    if any(data.get(key) for key in forbidden):
        raise ValueError('GLB contains unwanted scene or material data')
    if allow_texture:
        images=data.get('images',[])
        if len(images)!=1 or 'bufferView' not in images[0] or images[0].get('uri'):
            raise ValueError('GLB must contain exactly one embedded baked texture')
        if not data.get('materials') or not data.get('textures'):raise ValueError('GLB is missing its baked texture material')
    mesh_nodes={i for i,n in enumerate(data.get('nodes',[])) if 'mesh' in n}
    if len(mesh_nodes)!=1:raise ValueError('GLB contains extra mesh instances')
    if data['nodes'][next(iter(mesh_nodes))].get('skin')!=0:raise ValueError('GLB weights are not bound to the garment')
    allowed=set(data['skins'][0]['joints'])|mesh_nodes
    parents={child:i for i,n in enumerate(data['nodes']) for child in n.get('children',[])}
    for i in list(allowed):
        while i in parents:i=parents[i];allowed.add(i)
    if allowed!=set(range(len(data['nodes']))):raise ValueError('GLB contains objects outside the garment skeleton')
    for primitive in data['meshes'][0]['primitives']:
        if 'JOINTS_0' not in primitive['attributes'] or 'WEIGHTS_0' not in primitive['attributes']:
            raise ValueError('GLB is missing clothing skin weights')
    return data

def nwcs_export_baked_image(context,ob):
    if ob is None:raise ValueError('Select the garment before exporting')
    name=ob.get('nwcs_baked_image')
    image=bpy.data.images.get(name) if name else None
    if image is None:
        # Recover a baked material when object metadata was lost during import/copy.
        candidates=[]
        for material in ob.data.materials:
            if not material or not material.use_nodes:continue
            for node in material.node_tree.nodes:
                if node.type=='TEX_IMAGE' and node.image and (node.image.name.startswith('NWCS_Baked') or material.name.startswith('NWCS Baked') or material.name.startswith('NWCS Export Baked')):
                    if node.image not in candidates:candidates.append(node.image)
        if len(candidates)==1:image=candidates[0]
    if image is None:
        raise ValueError('No baked texture found on this garment. Click Bake & Pack Texture before exporting; no file was exported.')
    if not image.size[0] or not image.size[1]:raise ValueError('Baked texture has no image data. Bake & Pack Texture before exporting.')
    return image

def nwcs_save_texture_jpg(image,path):
    previous=image.filepath_raw;format=image.file_format
    try:
        image.filepath_raw=path;image.file_format='JPEG';image.save()
    finally:image.filepath_raw=previous;image.file_format=format

def nwcs_export_stem(ob):
    import re
    return re.sub(r'[^A-Za-z0-9_-]+','_',ob.name).strip('_') or 'Garment'

def nwcs_write_textured_dae_zip(context,ob,rig,image,path):
    import tempfile,zipfile,os
    with tempfile.TemporaryDirectory(prefix='nwcs_textured_dae_') as directory:
        stem=nwcs_export_stem(ob);texture_path=os.path.join(directory,stem+'_Texture.jpg');dae_path=os.path.join(directory,stem+'.dae')
        nwcs_save_texture_jpg(image,texture_path)
        nwcs_write_weighted_dae(context,ob,rig,dae_path,texture_filename=stem+'_Texture.jpg')
        with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as archive:
            archive.write(dae_path,stem+'.dae');archive.write(texture_path,stem+'_Texture.jpg')

def nwcs_write_glb_zip(glb_path,image,path,stem):
    """Bundle linked glTF/BIN/JPG files and an optional GLB alternative."""
    import tempfile,zipfile,os
    with tempfile.TemporaryDirectory(prefix='nwcs_upload_package_') as directory:
        names=nwcs_write_opensim_files(glb_path,os.path.join(directory,stem+'.gltf'))
        with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as archive:
            for name in names:archive.write(os.path.join(directory,name),name)
            archive.write(glb_path,stem+'.glb')

def nwcs_write_opensim_files(glb_path,gltf_path):
    """Save linked model/data/JPG files directly, with no ZIP step."""
    import json,struct,os,re,tempfile
    with open(glb_path,'rb') as file:
        magic,version,total=struct.unpack('<4sII',file.read(12));chunks=[]
        while True:
            header=file.read(8)
            if not header:break
            length,kind=struct.unpack('<II',header);chunks.append((kind,file.read(length)))
    if magic!=b'glTF' or version!=2:raise ValueError('Invalid staged glTF data')
    data=json.loads(next(value for kind,value in chunks if kind==0x4e4f534a))
    binary=next(value for kind,value in chunks if kind==0x004e4942)
    folder=os.path.dirname(os.path.abspath(gltf_path))
    stem=re.sub(r'[^A-Za-z0-9_-]+','_',os.path.splitext(os.path.basename(gltf_path))[0]).strip('_') or 'Garment'
    assets={};image_views=set()
    for index,image in enumerate(data.get('images',[])):
        view_index=image.get('bufferView')
        if view_index is None:raise ValueError('Expected a packed texture before OpenSim export')
        view=data['bufferViews'][view_index];offset=view.get('byteOffset',0)
        extension='.jpg' if image.get('mimeType')=='image/jpeg' else '.png'
        name=stem+'_Texture'+('' if index==0 else '_'+str(index+1))+extension
        assets[name]=binary[offset:offset+view['byteLength']]
        image_views.add(view_index);image.pop('bufferView');image['uri']=name
    used=set()
    for accessor in data.get('accessors',[]):
        if 'bufferView' in accessor:used.add(accessor['bufferView'])
        for part in ('indices','values'):
            entry=accessor.get('sparse',{}).get(part)
            if entry and 'bufferView' in entry:used.add(entry['bufferView'])
    rebuilt=bytearray();views=[];remap={}
    for index,view in enumerate(data.get('bufferViews',[])):
        if index in image_views and index not in used:continue
        rebuilt.extend(b'\x00'*((-len(rebuilt))%4))
        old_offset=view.get('byteOffset',0);new_view=dict(view)
        new_view['buffer']=0;new_view['byteOffset']=len(rebuilt)
        rebuilt.extend(binary[old_offset:old_offset+view['byteLength']])
        remap[index]=len(views);views.append(new_view)
    for accessor in data.get('accessors',[]):
        if 'bufferView' in accessor:accessor['bufferView']=remap[accessor['bufferView']]
        for part in ('indices','values'):
            entry=accessor.get('sparse',{}).get(part)
            if entry and 'bufferView' in entry:entry['bufferView']=remap[entry['bufferView']]
    data['bufferViews']=views
    bin_name=stem+'.bin';assets[bin_name]=bytes(rebuilt)
    data['buffers']=[{'uri':bin_name,'byteLength':len(rebuilt)}]
    model_name=os.path.basename(gltf_path)
    assets[model_name]=json.dumps(data,separators=(',',':')).encode('utf-8')
    if sum(len(value) for value in assets.values())>10000000:raise ValueError('OpenSim export exceeds the 10 MB limit')
    with tempfile.TemporaryDirectory(prefix='.nwcs_opensim_',dir=folder) as staging:
        for name,value in assets.items():
            with open(os.path.join(staging,name),'wb') as file:file.write(value)
        # Commit the model last, after every file it references is available.
        for name in [name for name in assets if name!=model_name]+[model_name]:
            os.replace(os.path.join(staging,name),os.path.join(folder,name))
    return list(assets)

class NWCS_OT_export_weighted(bpy.types.Operator,ExportHelper):
    bl_idname='nwcs.export_weighted'
    bl_label='Export with Weights'
    bl_description='Export only the rigged clothing and its skeleton, with skin weights and UVs'
    filename_ext='.glb'
    filter_glob: bpy.props.StringProperty(default='*.glb',options={'HIDDEN'})
    export_format: EnumProperty(items=[('OPENSIM','OpenSim','Linked glTF, BIN and JPG saved directly to a folder'),('GLB','GLB','Clean weighted garment with evaluated modifiers'),('DAE','Collada DAE','Weighted Collada')],default='GLB',options={'HIDDEN'})
    def invoke(self,context,event):
        ob=context.scene.nwcs_rig_settings.garment
        try:image=nwcs_export_baked_image(context,ob)
        except ValueError as exc:
            self.report({'ERROR'},str(exc));return {'CANCELLED'}
        self.filename_ext='.gltf' if self.export_format=='OPENSIM' else (('.zip' if image else '.dae') if self.export_format=='DAE' else '.zip')
        self.filter_glob='*'+self.filename_ext
        ob=context.scene.nwcs_rig_settings.garment
        self.filepath=bpy.path.clean_name(ob.name if ob else 'Clothing')+self.filename_ext
        return ExportHelper.invoke(self,context,event)
    def execute(self,context):
        import os,tempfile
        selection=list(context.selected_objects);active=context.view_layer.objects.active
        temporary=None;export_rig=None;export_rig_data=None;export_path=None;texture_copy=None;texture_material=None
        temporary_meshes=[];arm_states=[];rig=None;pose=None;hidden={}
        try:
            ob,rig=nwcs_bound_clothing(context)
            if rig.get('nwcs_pose_backup'):raise ValueError('Click Restore Pose before exporting')
            baked_image=nwcs_export_baked_image(context,ob)
            if baked_image:
                import numpy as np
                width,height=baked_image.size
                if not width or not height:raise ValueError('Baked texture has no image data; Bake & Pack Texture again')
                pixels=np.empty(width*height*4,dtype=np.float32);baked_image.pixels.foreach_get(pixels)
                texture_copy=bpy.data.images.new(nwcs_export_stem(ob)+'_Texture',width=width,height=height,alpha=True)
                texture_copy.colorspace_settings.name=baked_image.colorspace_settings.name
                texture_copy.pixels.foreach_set(pixels);texture_copy.update();texture_copy.file_format='JPEG';texture_copy.pack()
                texture_material=nwcs_baked_material(texture_copy,'NWCS Export Baked Material',ob.get('nwcs_baked_uv',ob.data.uv_layers.active.name if ob.data.uv_layers.active else ''))
            extension='.gltf' if self.export_format=='OPENSIM' else (('.zip' if texture_copy else '.dae') if self.export_format=='DAE' else '.zip')
            self.filepath=bpy.path.ensure_ext(self.filepath,extension)
            directory=os.path.dirname(os.path.abspath(self.filepath))
            if not os.path.isdir(directory):raise ValueError('Choose an existing export folder')
            hidden={o:o.hide_get() for o in (ob,rig)};pose=rig.data.pose_position
            arm_states=[(mod,mod.show_viewport) for mod in ob.modifiers if mod.type=='ARMATURE']
            for o in (ob,rig):o.hide_set(False)
            rig.data.pose_position='REST'
            for mod,state in arm_states:mod.show_viewport=False
            context.view_layer.update();deps=context.evaluated_depsgraph_get()
            mesh=bpy.data.meshes.new_from_object(ob.evaluated_get(deps),preserve_all_data_layers=True,depsgraph=deps)
            temporary_meshes.append(mesh)
            temporary=ob.copy();temporary.data=mesh;temporary.name=ob.name;mesh.name=ob.name
            baked_uv=mesh.uv_layers.get(ob.get('nwcs_baked_uv',''))
            if texture_copy and baked_uv:
                mesh.uv_layers.active=baked_uv;baked_uv.active_render=True
            if mesh.uv_layers.active:
                correct_uv=mesh.uv_layers.active
                for extra_uv in list(mesh.uv_layers):
                    if extra_uv!=correct_uv:mesh.uv_layers.remove(extra_uv)
                mesh.uv_layers.active=correct_uv;correct_uv.active_render=True
            context.collection.objects.link(temporary)
            world=ob.matrix_world.copy();temporary.parent=None;temporary.matrix_world=world
            temporary.modifiers.clear();temporary.hide_viewport=False;temporary.hide_set(False)
            nwcs_clean_export_mesh(mesh)
            export_rig=rig.copy();export_rig_data=rig.data.copy();export_rig.data=export_rig_data
            export_rig.name='NWCS Export Skeleton';context.collection.objects.link(export_rig)
            rig_world=rig.matrix_world.copy();export_rig.parent=None;export_rig.matrix_world=rig_world
            export_rig.animation_data_clear();export_rig.constraints.clear();export_rig.hide_viewport=False;export_rig.hide_set(False)
            export_rig.data.pose_position='REST'
            temporary.parent=export_rig;temporary.matrix_world=world
            optimize=context.scene.nwcs_rig_settings.export_optimize
            before=len(mesh.vertices)
            if optimize and before>NWCS_MAX_EXPORT_VERTS:
                nwcs_reduce_mesh_to_budget(context,temporary)
                if temporary.data not in temporary_meshes:temporary_meshes.append(temporary.data)
            fd,export_path=tempfile.mkstemp(prefix='.nwcs_export_',suffix='.glb' if self.export_format in {'OPENSIM','GLB'} else extension,dir=directory);os.close(fd)
            for attempt in range(9):
                for modifier in list(temporary.modifiers):temporary.modifiers.remove(modifier)
                mesh=temporary.data;nwcs_clean_export_mesh(mesh)
                rows=nwcs_bone_weight_rows(temporary,export_rig)
                temporary.vertex_groups.clear()
                groups={name:temporary.vertex_groups.new(name=name) for name in sorted({name for row in rows for name in row})}
                for index,row in enumerate(rows):
                    for name,weight in row.items():groups[name].add([index],weight,'REPLACE')
                mesh.materials.clear()
                if texture_material:mesh.materials.append(texture_material)
                for poly in mesh.polygons:poly.material_index=0
                arm=temporary.modifiers.new('Export Rig','ARMATURE');arm.object=export_rig
                bpy.ops.object.select_all(action='DESELECT');temporary.select_set(True);export_rig.select_set(True);context.view_layer.objects.active=temporary
                context.view_layer.update()
                if self.export_format=='DAE':
                    if texture_copy:nwcs_write_textured_dae_zip(context,temporary,export_rig,texture_copy,export_path)
                    else:nwcs_write_weighted_dae(context,temporary,export_rig,export_path)
                else:
                    bpy.ops.export_scene.gltf(filepath=export_path,export_format='GLB',use_selection=True,
                        export_apply=False,export_animations=False,export_skins=True,export_def_bones=True,
                        export_all_influences=False,export_morph=False,export_cameras=False,export_lights=False,
                        export_materials='EXPORT' if texture_copy else 'NONE',export_image_format='JPEG' if texture_copy else 'AUTO',export_jpeg_quality=95,export_extras=False,export_attributes=False,
                        use_mesh_edges=False,use_mesh_vertices=False,export_texcoords=True,export_normals=True,
                        export_rest_position_armature=True,will_save_settings=False)
                    nwcs_check_glb_contents(export_path,allow_texture=bool(texture_copy))
                size=os.path.getsize(export_path)
                if size<=9900000:break
                if not optimize:raise ValueError('Export exceeds 10 MB. Enable Optimize Export Copy and export again')
                if texture_copy and max(texture_copy.size)>512:
                    texture_copy.scale(max(512,texture_copy.size[0]//2),max(512,texture_copy.size[1]//2));texture_copy.pack()
                    continue
                target=max(100,int(len(mesh.vertices)*min(.8,9000000/size)*.9))
                if target>=len(mesh.vertices):raise ValueError('Cannot fit this garment below 10 MB')
                temporary.modifiers.remove(arm)
                nwcs_reduce_mesh_to_budget(context,temporary,limit=target)
                if temporary.data not in temporary_meshes:temporary_meshes.append(temporary.data)
            else:raise ValueError('Cannot fit this garment below 10 MB after optimization')
            if size>10000000:raise ValueError('Export exceeds the 10 MB upload limit')
            if self.export_format=='OPENSIM':
                nwcs_write_opensim_files(export_path,self.filepath)
                os.unlink(export_path)
            elif self.export_format=='GLB':
                nwcs_write_glb_zip(export_path,texture_copy,self.filepath,nwcs_export_stem(ob))
                os.unlink(export_path)
            else:os.replace(export_path,self.filepath)
            export_path=None
            self.report({'INFO'},'Exported clean weighted garment: '+format(size/1000000,'.2f')+' MB; '+str(before)+' to '+str(len(temporary.data.vertices))+' vertices')
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'},str(exc)[:200]);return {'CANCELLED'}
        finally:
            if temporary:bpy.data.objects.remove(temporary,do_unlink=True)
            for mesh in temporary_meshes:
                if mesh.users==0:bpy.data.meshes.remove(mesh)
            if export_rig:bpy.data.objects.remove(export_rig,do_unlink=True)
            if export_rig_data and export_rig_data.users==0:bpy.data.armatures.remove(export_rig_data)
            if texture_material and texture_material.users==0:bpy.data.materials.remove(texture_material)
            if texture_copy and texture_copy.users==0:bpy.data.images.remove(texture_copy)
            if rig and pose is not None:rig.data.pose_position=pose
            for mod,state in arm_states:mod.show_viewport=state
            for obj,state in hidden.items():obj.hide_set(state)
            if context.mode=='OBJECT':
                bpy.ops.object.select_all(action='DESELECT')
                for obj in selection:
                    if obj.name in context.view_layer.objects:obj.select_set(True)
                context.view_layer.objects.active=active
            context.view_layer.update()
            if export_path and os.path.exists(export_path):os.unlink(export_path)


class NWCS_PT_rig_setup(bpy.types.Panel):
    bl_label='6. Rigging'
    bl_idname='NWCS_PT_rig_setup'
    bl_parent_id='NWCS_PT_panel'
    bl_space_type='VIEW_3D'
    bl_region_type='UI'
    bl_options={'DEFAULT_CLOSED'}
    def draw(self,context):
        l=self.layout;p=context.scene.nwcs_rig_settings
        l.operator('nwcs.load_weighted_female',icon='ARMATURE_DATA')
        l.label(text='Included source matches the bundled female body')
        l.label(text='Use your own weighted body for other body shapes')
        l.operator('nwcs.rig_use_reference',icon='EYEDROPPER')
        l.prop(p,'source_body')
        l.prop(p,'garment')
        l.prop(p,'armature')
        l.label(text='Body and clothing must already fit in rest pose')
        l.operator('nwcs.rig_check',icon='CHECKMARK')
        l.separator()
        l.operator('nwcs.rig_clothing',icon='MOD_ARMATURE')
        l.label(text='Transfers weights and binds clothing to the rig')
        l.prop(p,'smooth_iterations')
        l.prop(p,'smooth_factor')
        l.operator('nwcs.smooth_clothing_weights',icon='MOD_SMOOTH')
        l.prop(p,'test_pose')
        l.operator('nwcs.test_rig_pose',icon='POSE_HLT')
        l.operator('nwcs.restore_rig_pose',icon='LOOP_BACK')
        l.separator()
        l.label(text='Baked texture included in export')
        l.prop(p,'export_optimize')
        l.operator('nwcs.export_weighted',text='Export glTF + BIN + JPG (.zip)',icon='EXPORT').export_format='GLB'
        l.label(text='Extract ZIP; keep glTF, BIN and JPG together')

classes=(NWCS_RigSettings,NWCS_StitchSettings,NWCS_OT_remove_stitching,NWCS_OT_apply_stitching,NWCS_TextureSettings,NWCS_OT_texture_prepare,NWCS_OT_bake_pack_texture,NWCS_OT_load_reference_avatar,NWCS_OT_use_selected_avatar,NWCS_OT_toggle_reference_avatar,NWCS_Props,NWCS_OT_optimize_export,NWCS_OT_add_accessory,NWCS_OT_build_fitted,NWCS_OT_protect_rings,NWCS_OT_make_rings,NWCS_OT_center_ring_origins,NWCS_OT_fit_waist,NWCS_OT_conform_waist,NWCS_OT_conform_waist_any,NWCS_OT_corset_gentle_fit,NWCS_OT_build,NWCS_OT_grab_pull,NWCS_OT_smooth_fabric,NWCS_OT_end_sculpt,NWCS_OT_pin_selection,NWCS_OT_add_body_collision,NWCS_OT_validate_cloth,NWCS_OT_start_sim,NWCS_OT_click_to_stop,NWCS_OT_stop_sim,NWCS_OT_remove_drafts,NWCS_OT_clear_garment_only,NWCS_OT_reset_sim,NWCS_OT_show_rings,NWCS_OT_freeze,NWCS_OT_repair_frozen_spikes,NWCS_OT_auto_uv,NWCS_OT_finish_or_freeze,NWCS_OT_finish,NWCS_OT_clear,NWCS_PT_panel,NWCS_PT_setup,NWCS_PT_production,NWCS_PT_simulation,NWCS_OT_rename_garment,NWCS_PT_finishing,NWCS_PT_texture,NWCS_PT_export,NWCS_PT_accessories,NWCS_PT_stitching,NWCS_OT_load_weighted_female,NWCS_OT_rig_use_reference,NWCS_OT_rig_check,NWCS_OT_rig_clothing,NWCS_OT_test_rig_pose,NWCS_OT_restore_rig_pose,NWCS_OT_smooth_clothing_weights,NWCS_OT_export_weighted,NWCS_PT_rig_setup)
def register():
    for cls in classes:bpy.utils.register_class(cls)
    bpy.types.Scene.nwcs_rig_settings=PointerProperty(type=NWCS_RigSettings)
    bpy.types.Scene.nwcs_props=PointerProperty(type=NWCS_Props)
    bpy.types.Scene.nwcs_stitch_settings=PointerProperty(type=NWCS_StitchSettings)
    bpy.types.Scene.nwcs_texture_settings=PointerProperty(type=NWCS_TextureSettings)
    # Do not access bpy.data during add-on registration: Blender uses
    # _RestrictData while enabling extensions. Ring creation initializes
    # the mirror baseline; the handler initializes lazily for saved scenes.
    _nwcs_mirror_state.clear()
    if nwcs_mirror_ring_handler not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(nwcs_mirror_ring_handler)
def unregister():
    if nwcs_mirror_ring_handler in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(nwcs_mirror_ring_handler)
    _nwcs_mirror_state.clear()
    del bpy.types.Scene.nwcs_rig_settings
    del bpy.types.Scene.nwcs_texture_settings
    del bpy.types.Scene.nwcs_stitch_settings
    del bpy.types.Scene.nwcs_props
    for cls in reversed(classes):bpy.utils.unregister_class(cls)
if __name__=='__main__':register()
