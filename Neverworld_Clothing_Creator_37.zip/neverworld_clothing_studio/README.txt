NEVERWORLD CLOTHING CREATOR V1.0 — QUICK START

1. Install this ZIP in Blender 4.5 using Edit > Preferences > Add-ons > Install from Disk.
2. Open the Neverworld Clothing Creator tab in the 3D View sidebar (press N).
3. Click Female or Male to load an included body. Or import your own OBJ/DAE/FBX, select its mesh, and click Use Selected Mesh as Avatar.
4. Choose a garment and its options.
5. Click Make Rings. Adjust the rings around your reference body.
6. Click Build Garment, then Simulate.
7. Click Stop Simulation when satisfied, then Finish and use Auto UV.

The design references are mesh-only. The female FBX retains the supplied
orientation; the male OBJ retains its existing A-pose. Custom mesh support
is unchanged.

RIGGING (section 6)
1. Finish the clothing simulation. Select the finished clothing in Object Mode.
2. Click Load Included Weighted Female + SL Skeleton for the bundled female
   reference, or choose your own weighted body and its existing SL armature.
   The included weighted source is recovered from the original female DAE.
   It does not supply male weights or fit arbitrary body shapes automatically.
3. Check Weights From, Clothing To Rig and Second Life Rig. The source and
   clothing must already fit together in the rig's rest pose.
4. Click Check Rigging Setup, then Rig Clothing. This copies interpolated
   nearest-surface weights, normalizes to at most four bone influences per
   vertex and adds the armature binding before the fabric modifiers.
   Re-rigging replaces bone groups while preserving UVs and non-bone groups.
5. Choose Arms / Elbows, Legs / Knees or Torso, then Test Clothing Pose.
   The weighted source body is shown and the static design reference hidden
   during the test so the preview displays the deforming body with clothing.
6. Click Restore Pose before re-rigging. It restores the saved bone transforms
   and prior visibility. Tests do not add animation keyframes.

The included rig supports the static test buttons. For rigs with constraints
or active animation, use their own posing controls. Single-user clothing
meshes and unlocked bone groups are required for weight replacement.
SMOOTH WEIGHTS AND EXPORT
7. Smooth Iterations defaults to 50. Smooth Clothing Weights processes ALL
   deform-bone groups using connected mesh neighbors; Smooth Factor is a
   separate blend-strength setting. The final weights are normalized and
   capped at four bone influences. Mesh shape, UVs and non-bone groups stay
   unchanged. Inspect the result with the pose tests.
8. Restore Pose, then choose Export Clean Garment with Weights (.glb) or
   Export with Weights (.dae). FBX export has been removed.
9. Both formats evaluate the garment's enabled finishing modifiers in rest
   pose on a temporary copy. Cleanup removes loose and invalid geometry,
   normalizes skin weights and caps them at four bone influences. The export
   contains only one garment mesh and its skin/skeleton, with normals and UVs.
   It always excludes the source avatar, animation, cameras, lights and
   unrelated scene objects. Version 15 can include the garment baked color
   texture/material when Include Baked Texture is enabled.
10. Optimize Export Copy defaults ON. A garment above 99,999 evaluated
    vertices is first reduced toward the existing 80,000-vertex target.
    The actual serialized file is then checked against a conservative
    9.9 MB cap. If needed, only the export copy is reduced further and
    exported again. Successful files stay below the 10 MB upload limit.
    Optimization can change the exported surface; the editable original,
    its weights, UVs and modifier stack remain unchanged.
11. With optimization disabled, an oversized export is refused. Existing
    files are replaced only after a valid file below the limit is ready.

Checks include a GLB round trip with evaluated Solidify/Subdivision, skin
weights, UVs and dimensions; DAE skin data and bind matrices; large-garment
size limits; and preservation of the editable scene. Actual Second Life /
OpenSim upload remains untested.
Runtime checks were performed in Blender 4.3.2; Blender 4.5 is untested here.

TEXTURE PREPARATION (section 5)
1. Finish garment and select the garment mesh in Object Mode.
2. Click Create / Repair UV in section 4 if the garment has no UVs.
3. In section 5, optionally choose a fabric image (PNG/JPG) or leave blank
   for a plain paint canvas. Choose 1024 or 2048 pixels.
4. Click Prepare Paint Canvas. It assigns a UV-mapped image material and
   switches the viewport to Material Preview.
5. Switch Blender to Texture Paint mode. Paint directly on the garment.
   For graphics, use Blender's Texture Paint stencil brush and position the
   stencil on the 3D garment. This avoids guessing 2D texture rotations.
6. Open the image in Blender's Image Editor and use Image > Save As to
   export a PNG. Save the image or Bake & Pack Texture before closing Blender.

NOTE: This feature creates an editable UV-aligned image and material, not an
automatic seam or wrinkle baker. Texture painting is a Blender interactive
workflow; final appearance depends on the garment UV and painting work.

RENAME GARMENT
Select the garment, open 4. Finish, and click Rename Garment. Enter the
new name and confirm. The object name changes; geometry, UVs, weights,
materials and rigging selections stay intact. The action supports Undo.

VERSION 14 FITTING UPDATE
UV-related messages now use finished garment terminology. Initial neck
guides are located from the actual open neck rim, with rig/geometry
fallbacks for other bodies. This corrects headless reference proportions.
Tank guides locate the actual waist and fullest bust, use a curved torso
profile and fit front/back coverage to the reference body. Armhole edges
are rounded. Re-create rings and build a new tank to use these changes;
existing garments are not reshaped.
Validation: neck guides on both included bodies for five top presets;
female tank topology and initial simulation; Finish, UV, rename, rig,
50 smoothing iterations, pose/reset, GLB and DAE exports under 10 MB.
Checks ran in Blender 4.3.2; Blender 4.5 and inworld upload are untested here.

VERSION 15 - BAKE, RESIZE AND PACK TEXTURES
1. Finish the garment and create its UVs.
2. In 5. Texture Preparation, choose Fabric Image and Prepare Paint Canvas.
3. Adjust Pattern Size: higher values make the fabric design larger on the
   garment; lower values repeat it more. Preview changes before baking.
4. Choose Bake Resolution: 512, 1024 or 2048 pixels. This controls the output
   image size separately from the pattern scale.
5. Click Bake & Pack Texture. It bakes the material's diffuse colors to one
   PNG atlas and packs that image into the garment material. This is a color
   bake, not a lighting, AO, normal, metallic or roughness bake.
6. Under Rigging, leave Include Baked Texture enabled. GLB embeds the baked
   PNG in the single GLB file. Textured DAE exports instead produce a ZIP
   containing Garment.dae and the correctly linked Garment_Texture.png.
   Extract both files together before using a DAE package.
7. Turn Include Baked Texture off for the previous garment/weights-only
   export. Upload-size checks include the image/package. Optimization can
   downsize only the export texture copy if required to fit under 10 MB.
   The original baked image retains its chosen resolution.

Checks: real CPU bake from a loaded image after pattern scaling, packed
PNG, UV/geometry/weight preservation, GLB embedded image and skin, DAE ZIP
image linkage, texture-free fallback and export-copy size optimization.
Tested in Blender 4.3.2; Blender 4.5 and actual inworld uploads untested here.

VERSION 16 - CONSISTENT UVS FOR BAKING
Create / Repair UV now makes its UV layer active for rendering as well as
editing. Prepared fabric and baked materials use explicit named UV nodes.
Baking and export use that same UV layer, avoiding older map selection.
Finishing modifiers are disabled only during the color bake and restored
afterward; exports still evaluate the enabled finishing modifiers.

For a garment already textured with version 15: select the finished garment,
click Create / Repair UV, choose the original Fabric Image and Prepare Paint
Canvas again, set Pattern Size, then Bake & Pack Texture. This replaces the
bad bake; no garment rebuild is required. The changes are shared by all
garment types.

Checks: actual finished 3D tank with multiple UV layers and floral image;
before/after rendered color agreement, no new black patches; packed PNG,
textured GLB, DAE+PNG ZIP, untextured fallback and scene-state preservation.
Blender 4.3.2 tested; Blender 4.5 and inworld uploads untested here.

VERSION 17 - PATTERNED BAKE BACKGROUND
Bake & Pack now fills the entire output image with the same fabric pattern
before baking. The background uses the prepared fabric mapping scale and
the chosen 512/1024/2048 output resolution. Baking no longer clears unused
atlas space to a blank/transparent background. UVs and geometry stay intact.
This shared change applies to every garment using Bake & Pack.
Reapply the original fabric and bake again to replace a blank-background
bake. Checked consistent pattern scale inside and outside UV islands,
full-canvas coverage, embedded GLB and DAE+PNG ZIP in Blender 4.3.2.

VERSION 18 - OPAQUE JPG WITH FLAT FABRIC BACKGROUND
Bake & Pack produces an opaque JPG, with the flat fabric pattern filling
the entire square image at the selected scale and resolution. Prepared UV
fabric is flattened directly from its image/mapping, preserving the exact
color pattern without shell faces overwriting it. Other materials are color
baked and composited over the flat background. No transparent background.
GLB embeds the JPG; textured DAE ZIP contains Garment.dae plus the linked
Garment_Texture.jpg. This output change does not claim to repair UV layout.
Reapply the original fabric using Prepare Paint Canvas, adjust Pattern Size,
then Bake & Pack again. The Texture panel identifies the JPG output.
Checked packed JPEG file data, opaque full-pattern coverage, matching scale
inside/outside UV islands, embedded JPEG in GLB and linked JPG in DAE ZIP.
Blender 4.3.2 tested; Blender 4.5 and inworld upload remain untested.

VERSION 19 - DIRECT EXPORT FOR OPENSIM
Use 6. Rigging > Export for OpenSim (.gltf). Choose a folder and model name
in the save dialog. The add-on writes the .gltf model, matching .bin data
and baked .jpg directly into that folder. No ZIP extraction is needed.
Open the .gltf in the viewer uploader with Include Textures enabled. The
uploader reads the other files automatically; keep them in the same folder.
The export keeps only the correct UV map as UV0 on the export copy; all
original garment UV layers remain intact in Blender.
Cleanup, modifier evaluation, skin weights and the 10 MB check still apply.
Checked direct three-file output, relative references, UV0, weighted reload
and a loaded JPG in Blender 4.3.2. This uses the external-resource glTF
workflow you confirmed works inworld; this exact release is not tested in
your viewer here. Blender 4.5 remains untested in this environment.

VERSION 20 - BAKED SHAPE ACCENTS
5. Texture Preparation includes Baked Shape Accents (on by default) and
Accent Strength. Bake & Pack can add local crease occlusion and soft shape
shading derived from garment geometry to the fabric color texture. It
does not invent folds or create PBR normal/roughness maps. The flat pattern
background remains intact outside mapped garment areas.

For your test: reapply the original fabric with Prepare Paint Canvas,
enable Baked Shape Accents, set Accent Strength and Bake & Pack again.
Then use Export for OpenSim (.gltf); model/BIN/JPG save directly with no ZIP.
Repeat bakes reuse the original prepared fabric to avoid stacking shadows.
Turn the accents off for a flat color-only texture.

Checked geometry-driven shading variation, unchanged background, packed JPG,
repeat-bake consistency, clean resource restoration, and direct OpenSim
folder export/reload. Blender 4.3.2 tested; Blender 4.5 and this exact build's
inworld upload remain untested here.

VERSION 21 - CLEAN SHAPE SHADING
The noisy self-occlusion/AO contribution from version 20 is disabled.
Baked Shape Accents now adds only gently bounded, smoothed shape shading.
Default strength is reduced to .35. Full patterned JPG background, skin
weights and direct Export for OpenSim stay in place.
Reapply the original fabric with Prepare Paint Canvas before baking again
to replace the bad shaded image. Turn Baked Shape Accents off for the
completely flat original fabric.
Checked on the actual uploaded tank mesh, with its UV map and floral image
in Blender 4.3.2. This is not an AO bake and is not an inworld verification.
